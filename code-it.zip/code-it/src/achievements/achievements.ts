import { ApiClient } from '../api/client';
import { PlayerStore, type PlayerProfile } from '../player/store';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'hello-world', title: 'Hello, World', description: 'Run code for the first time.', icon: '▶' },
  { id: 'new-bug', title: 'You Invented a New Bug', description: 'Cause your first JavaScript error. Breaking things is how you learn.', icon: '🐛' },
  { id: 'bug-squasher', title: 'Bug Squasher', description: 'Fix code that was throwing errors.', icon: '🔨' },
  { id: 'first-job', title: 'Hired!', description: 'Complete your first job.', icon: '💼' },
  { id: 'no-hints', title: 'Didn’t Need Help', description: 'Complete a job without hints.', icon: '🧠' },
  { id: 'first-try', title: 'No Errors. Suspicious.', description: 'Pass a job on the very first run.', icon: '🎯' },
  { id: 'experimenter', title: 'Mad Scientist', description: 'Run your code 10 times in one job.', icon: '🧪' },
  { id: 'speedrun', title: 'Deployment Approved', description: 'Beat a job’s deadline.', icon: '⚡' },
  { id: 'a11y', title: 'Accessibility Ally', description: 'Earn an accessibility bonus.', icon: '♿' },
  { id: 'change-request', title: 'Survived the Client', description: 'Handle a last-minute requirement change.', icon: '📞' },
  { id: 'debugger', title: 'Previous Developer Who?', description: 'Complete every debugging job.', icon: '🕵' },
  { id: 'launch-day', title: 'Shipped It', description: 'Complete the final job.', icon: '🚀' },
];

const byId = new Map(ACHIEVEMENTS.map((a) => [a.id, a]));

type Unlocked = (a: Achievement) => void;
const listeners = new Set<Unlocked>();

export const Achievements = {
  onUnlock(fn: Unlocked): () => void {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
  has(p: PlayerProfile, id: string): boolean {
    return p.achievements.includes(id);
  },
  /** While true, unlocks are collected silently (the results screen shows them instead of toasts). */
  quiet: false,
  /** Idempotent: unlocking twice does nothing, locally or on the server. */
  unlock(id: string): boolean {
    const a = byId.get(id);
    if (!a || PlayerStore.get().achievements.includes(id)) return false;
    PlayerStore.update((p) => p.achievements.push(id), true);
    ApiClient.enqueue('POST', '/api/achievements', { playerId: PlayerStore.get().id, achievementId: id }, `ach:${id}`);
    listeners.forEach((l) => l(a));
    return true;
  },
};
