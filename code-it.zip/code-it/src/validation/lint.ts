/**
 * Static checks on player source. Pure functions, no execution, fast (<5ms for
 * level-sized files). Results become editor diagnostics and feed SourceRules.
 */
export interface LintIssue {
  line: number;
  message: string;
  severity: 'error' | 'warning';
}

const VOID = new Set([
  'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr',
]);
// Elements whose closing tag the HTML spec lets you omit; don't nag beginners about these.
const OPTIONAL_CLOSE = new Set(['li', 'p', 'td', 'th', 'tr', 'option', 'dt', 'dd', 'thead', 'tbody', 'html', 'head', 'body']);

const lineAt = (src: string, index: number) => src.slice(0, index).split('\n').length;

export function lintHtml(src: string): LintIssue[] {
  const issues: LintIssue[] = [];
  const stack: { tag: string; line: number }[] = [];
  // Strip comments, and script/style bodies, while keeping offsets stable.
  const blank = (m: string) => m.replace(/[^\n]/g, ' ');
  const clean = src
    .replace(/<!--[\s\S]*?-->/g, blank)
    .replace(/(<script\b[^>]*>)([\s\S]*?)(<\/script>)/gi, (_m, a, b, c) => a + blank(b) + c)
    .replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi, (_m, a, b, c) => a + blank(b) + c);

  const tagRe = /<\/?([a-zA-Z][a-zA-Z0-9-]*)\b([^<>]*?)(\/?)>|<\/?([a-zA-Z][a-zA-Z0-9-]*)\b[^<>]*(?=<|$)/g;
  let m: RegExpExecArray | null;
  while ((m = tagRe.exec(clean))) {
    const line = lineAt(clean, m.index);
    if (m[4]) {
      issues.push({ line, message: `The <${m[4]}> tag is missing its closing ">"`, severity: 'error' });
      continue;
    }
    const tag = m[1].toLowerCase();
    const closing = m[0].startsWith('</');
    const selfClosing = m[3] === '/';
    const attrs = m[2] || '';
    const quotes = (attrs.match(/"/g) || []).length;
    if (!closing && quotes % 2 === 1) {
      issues.push({ line, message: `An attribute on <${tag}> is missing a closing quote (")`, severity: 'error' });
    }
    if (tag === '!doctype') continue;
    if (VOID.has(tag)) {
      if (closing) issues.push({ line, message: `<${tag}> never needs a closing tag`, severity: 'warning' });
      continue;
    }
    if (!closing) {
      if (!selfClosing) stack.push({ tag, line });
      continue;
    }
    // Closing tag: find its opener, reporting anything left open in between.
    let idx = stack.length - 1;
    while (idx >= 0 && stack[idx].tag !== tag) idx--;
    if (idx === -1) {
      issues.push({ line, message: `</${tag}> closes a tag that was never opened`, severity: 'error' });
      continue;
    }
    for (let k = stack.length - 1; k > idx; k--) {
      const open = stack[k];
      if (!OPTIONAL_CLOSE.has(open.tag)) {
        issues.push({ line: open.line, message: `<${open.tag}> is never closed. Add </${open.tag}>`, severity: 'error' });
      }
    }
    stack.length = idx;
  }
  for (const open of stack) {
    if (!OPTIONAL_CLOSE.has(open.tag)) {
      issues.push({ line: open.line, message: `<${open.tag}> is never closed. Add </${open.tag}>`, severity: 'error' });
    }
  }
  return issues;
}

/**
 * CSS checks: brace balance, missing semicolons, and declarations the browser would
 * silently drop. `supports` is injected so this stays testable outside a browser.
 */
export function lintCss(src: string, supports?: (prop: string, value: string) => boolean): LintIssue[] {
  const issues: LintIssue[] = [];
  const clean = src.replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, ' '));
  let depth = 0;
  const opens: number[] = [];
  for (let i = 0; i < clean.length; i++) {
    if (clean[i] === '{') { depth++; opens.push(i); }
    if (clean[i] === '}') {
      depth--;
      opens.pop();
      if (depth < 0) {
        issues.push({ line: lineAt(clean, i), message: 'Extra "}" with no matching "{"', severity: 'error' });
        depth = 0;
      }
    }
  }
  for (const o of opens) issues.push({ line: lineAt(clean, o), message: 'This "{" is never closed with "}"', severity: 'error' });

  // Declarations inside simple blocks (not @media headers).
  const blockRe = /\{([^{}]*)\}/g;
  let b: RegExpExecArray | null;
  while ((b = blockRe.exec(clean))) {
    const body = b[1];
    const bodyStart = b.index + 1;
    const decls = body.split(';');
    let offset = 0;
    decls.forEach((raw, idx) => {
      const declStart = bodyStart + offset + (raw.length - raw.trimStart().length);
      offset += raw.length + 1;
      const d = raw.trim();
      if (!d) return;
      const line = lineAt(clean, declStart);
      const colon = d.indexOf(':');
      if (colon === -1) {
        issues.push({ line, message: `"${d.slice(0, 30)}" is missing a ":" between property and value`, severity: 'error' });
        return;
      }
      const prop = d.slice(0, colon).trim().toLowerCase();
      const value = d.slice(colon + 1).trim();
      // Two declarations glued together because a ";" is missing.
      if (/\n\s*[a-z-]+\s*:/.test(d.slice(colon + 1)) && idx < decls.length) {
        issues.push({ line, message: `Missing ";" after "${prop}: ${value.split('\n')[0].trim()}"`, severity: 'error' });
        return;
      }
      if (!value) {
        issues.push({ line, message: `"${prop}" has no value`, severity: 'error' });
        return;
      }
      if (supports && !prop.startsWith('--') && !supports(prop, value.replace(/!important$/i, '').trim())) {
        issues.push({ line, message: `The browser ignores "${prop}: ${value}" (unknown property or value)`, severity: 'warning' });
      }
    });
  }
  return issues;
}

/** Finds the first line in CSS that uses a selector, to point unmatched-selector warnings at it. */
export function findSelectorLine(css: string, selector: string): number | null {
  const lines = css.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    const idx = l.indexOf(selector);
    if (idx !== -1 && !/[\w-]/.test(l[idx + selector.length] || '')) return i + 1;
  }
  return null;
}
