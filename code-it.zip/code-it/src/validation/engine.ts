/**
 * Validation engine: turns a level's machine-readable requirements into a report.
 * Source rules run here (pure string checks); DOM rules run in the sandbox.
 */
import type { DomRule, Requirement, SourceRule } from '../levels/types';
import { validateInSandbox, type PlayerCode, type RuntimeError } from '../sandbox/sandbox';
import { lintCss, lintHtml, type LintIssue } from './lint';

export interface CheckResult {
  id: string;
  label: string;
  pass: boolean;
  fail: string;
  tip?: string;
  detail?: string;
  bonus?: Requirement['bonus'];
}

export interface ValidationReport {
  passed: boolean;
  checks: CheckResult[];
  bonus: CheckResult[];
  runtimeErrors: RuntimeError[];
  lint: { html: LintIssue[]; css: LintIssue[] };
  timedOut: boolean;
  timings: { totalMs: number; executionMs: number; sandboxValidationMs: number };
}

const isSourceRule = (r: Requirement['rule']): r is SourceRule => r.type === 'source' || r.type === 'htmlBalanced';

export function cssSupports(prop: string, value: string): boolean {
  try {
    return typeof CSS !== 'undefined' && CSS.supports(prop, value);
  } catch {
    return true;
  }
}

export function evaluateSourceRule(rule: SourceRule, code: PlayerCode, htmlLint: LintIssue[]): { pass: boolean; detail?: string } {
  if (rule.type === 'htmlBalanced') {
    const errs = htmlLint.filter((i) => i.severity === 'error');
    return { pass: errs.length === 0, detail: errs[0] ? `line ${errs[0].line}: ${errs[0].message}` : undefined };
  }
  // Strip comments so commented-out code doesn't count.
  const src = rule.lang === 'html'
    ? code.html.replace(/<!--[\s\S]*?-->/g, '')
    : (rule.lang === 'css' ? code.css : code.js).replace(/\/\*[\s\S]*?\*\//g, '').replace(rule.lang === 'js' ? /(^|[^:])\/\/.*$/gm : /$^/, '$1');
  const found = new RegExp(rule.pattern, rule.flags ?? 'i').test(src);
  return { pass: rule.negate ? !found : found };
}

export async function validate(code: PlayerCode, requirements: Requirement[], signal?: AbortSignal): Promise<ValidationReport> {
  const t0 = performance.now();
  const htmlLint = lintHtml(code.html);
  const cssLint = lintCss(code.css, cssSupports);

  const dom = requirements
    .filter((r) => !isSourceRule(r.rule))
    .map((r) => ({ id: r.id, rule: r.rule as DomRule, viewport: r.viewport }));
  // Always run at least one frame so runtime errors are captured.
  const run = await validateInSandbox(code, dom, signal);
  const domResults = new Map(run.results.map((r) => [r.id, r]));

  const all: CheckResult[] = requirements.map((req) => {
    const res = isSourceRule(req.rule)
      ? evaluateSourceRule(req.rule, code, htmlLint)
      : domResults.get(req.id) ?? { pass: false, detail: 'not evaluated' };
    return { id: req.id, label: req.label, pass: res.pass, fail: req.fail, tip: req.tip, detail: res.detail, bonus: req.bonus };
  });

  const checks = all.filter((c) => !c.bonus);
  const bonus = all.filter((c) => c.bonus);
  return {
    passed: checks.every((c) => c.pass) && !run.timedOut,
    checks,
    bonus,
    runtimeErrors: run.errors,
    lint: { html: htmlLint, css: cssLint },
    timedOut: run.timedOut,
    timings: { totalMs: performance.now() - t0, executionMs: run.executionTimeMs, sandboxValidationMs: run.validationTimeMs },
  };
}
