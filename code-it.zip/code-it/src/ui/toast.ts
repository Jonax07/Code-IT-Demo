import { esc } from './dom';

let region: HTMLElement | null = null;
let captionEl: HTMLElement | null = null;
let captionTimer: number | undefined;

function ensure(): HTMLElement {
  if (region) return region;
  region = document.createElement('div');
  region.className = 'toasts';
  region.setAttribute('role', 'status');
  region.setAttribute('aria-live', 'polite');
  document.body.appendChild(region);
  return region;
}

export function toast(html: string, opts: { kind?: 'info' | 'achievement' | 'good' | 'bad'; ms?: number } = {}): void {
  const t = document.createElement('div');
  t.className = `toast toast-${opts.kind ?? 'info'}`;
  t.innerHTML = html;
  ensure().appendChild(t);
  window.setTimeout(() => {
    t.classList.add('out');
    window.setTimeout(() => t.remove(), 300);
  }, opts.ms ?? 3200);
}

/** Visual captions for sound effects: sound is never the only signal. */
export function caption(text: string): void {
  if (!captionEl) {
    captionEl = document.createElement('div');
    captionEl.className = 'caption';
    captionEl.setAttribute('aria-hidden', 'true'); // Results are announced separately.
    document.body.appendChild(captionEl);
  }
  captionEl.innerHTML = esc(text);
  captionEl.classList.add('show');
  clearTimeout(captionTimer);
  captionTimer = window.setTimeout(() => captionEl?.classList.remove('show'), 1800);
}

/** Screen-reader-only announcement. */
export function announce(text: string): void {
  let live = document.getElementById('sr-live');
  if (!live) {
    live = document.createElement('div');
    live.id = 'sr-live';
    live.className = 'sr-only';
    live.setAttribute('aria-live', 'assertive');
    document.body.appendChild(live);
  }
  live.textContent = '';
  window.setTimeout(() => (live!.textContent = text), 30);
}
