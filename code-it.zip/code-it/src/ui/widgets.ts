import { rankFor } from '../progression/scoring';

export function rankBar(xp: number): string {
  const r = rankFor(xp);
  const pct = Math.round((r.into / r.needed) * 100);
  return `<div class="rank" title="${xp} XP total">
    <span class="rank-no mono" aria-hidden="true">LV${r.rank}</span>
    <div class="rank-text"><span class="rank-title">${r.title}</span>
      <span class="rank-track" role="progressbar" aria-label="XP to next rank" aria-valuemin="0" aria-valuemax="${r.needed}" aria-valuenow="${r.into}"><span class="rank-fill" style="width:${pct}%"></span></span>
    </div>
    <span class="rank-xp mono">${xp} XP</span>
  </div>`;
}

export const stars = (n: number, max = 3) =>
  `<span class="stars" aria-label="${n} of ${max} stars">${Array.from({ length: max }, (_, i) => `<span class="star${i < n ? ' on' : ''}" aria-hidden="true">★</span>`).join('')}</span>`;
