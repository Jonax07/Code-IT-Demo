/**
 * The cast. Small inline-SVG portraits with swappable expressions, plus reaction lines.
 */
import type { CharacterId } from '../levels/types';

export type Mood = 'neutral' | 'happy' | 'sad' | 'shocked' | 'smug';

export interface Character {
  id: CharacterId;
  name: string;
  role: string;
  color: string;
}

export const CAST: Record<Exclude<CharacterId, 'client'>, Character> = {
  byte: { id: 'byte', name: 'BYTE', role: 'Your computer. Emotionally invested.', color: '#3ddc84' },
  dex: { id: 'dex', name: 'Dex', role: 'Senior Developer. Has seen things.', color: '#8b5cf6' },
  tina: { id: 'tina', name: 'QA Tina', role: 'QA Tester. Breaks everything.', color: '#14b8a6' },
};

const mouth = (m: Mood) =>
  ({
    neutral: '<path d="M38 66 h24" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>',
    happy: '<path d="M34 62 q16 18 32 0" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>',
    sad: '<path d="M36 72 q14 -14 28 0" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>',
    shocked: '<ellipse cx="50" cy="68" rx="7" ry="9" fill="currentColor"/>',
    smug: '<path d="M38 66 q14 6 26 -6" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>',
  })[m];

const eyes = (m: Mood) => {
  if (m === 'happy') return '<path d="M30 46 q6 -8 12 0 M58 46 q6 -8 12 0" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>';
  if (m === 'sad') return '<path d="M30 42 l12 4 M70 42 l-12 4" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="36" cy="50" r="4" fill="currentColor"/><circle cx="64" cy="50" r="4" fill="currentColor"/>';
  if (m === 'shocked') return '<circle cx="36" cy="46" r="7" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="64" cy="46" r="7" fill="none" stroke="currentColor" stroke-width="4"/>';
  if (m === 'smug') return '<path d="M30 46 h12 M58 46 h12" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>';
  return '<circle cx="36" cy="46" r="5" fill="currentColor"/><circle cx="64" cy="46" r="5" fill="currentColor"/>';
};

/** Returns an SVG string. `color` tints the character; features use currentColor. */
export function portrait(id: CharacterId, mood: Mood, color?: string): string {
  const c = color ?? (id === 'client' ? '#6c7cff' : CAST[id].color);
  const face = eyes(mood) + mouth(mood);
  if (id === 'byte') {
    // A small CRT monitor with a terminal face.
    return `<svg viewBox="0 0 100 100" aria-hidden="true" class="portrait" style="color:${c}">
      <rect x="8" y="12" width="84" height="68" rx="10" fill="#10141b" stroke="${c}" stroke-width="4"/>
      <rect x="16" y="20" width="68" height="52" rx="4" fill="#0b0f14"/>
      <g transform="translate(0,-4)"><g class="byte-face">${face}</g></g>
      <rect class="byte-scan" x="16" y="20" width="68" height="6" fill="${c}" opacity=".08"/>
      <rect x="38" y="80" width="24" height="8" fill="${c}"/><rect x="28" y="88" width="44" height="6" rx="3" fill="${c}"/>
    </svg>`;
  }
  const hair =
    id === 'dex'
      ? '<path d="M22 36 q4 -26 30 -24 q26 0 28 26 q-10 -10 -28 -10 q-18 0 -30 8z" fill="#2a1f3d"/><rect x="26" y="40" width="20" height="13" rx="4" fill="none" stroke="#1a1a1a" stroke-width="3"/><rect x="54" y="40" width="20" height="13" rx="4" fill="none" stroke="#1a1a1a" stroke-width="3"/><path d="M46 46 h8" stroke="#1a1a1a" stroke-width="3"/>'
      : id === 'tina'
        ? '<path d="M18 50 q0 -40 32 -40 q32 0 32 40 l-6 0 q0 -30 -26 -30 q-26 0 -26 30z" fill="#0f3d38"/><rect x="12" y="44" width="10" height="18" rx="4" fill="#1a1a1a"/><rect x="78" y="44" width="10" height="18" rx="4" fill="#1a1a1a"/><path d="M84 62 q0 16 -18 18" stroke="#1a1a1a" stroke-width="3" fill="none"/>'
        : '<path d="M24 34 q26 -22 52 0 v-6 q-26 -18 -52 0z" fill="#1a1a1a"/>';
  return `<svg viewBox="0 0 100 100" aria-hidden="true" class="portrait" style="color:#1a1a1a">
    <circle cx="50" cy="54" r="38" fill="${c}"/>
    <circle cx="50" cy="52" r="30" fill="#ffe2c8"/>
    ${hair}
    ${face}
  </svg>`;
}

const pick = <T,>(xs: T[]) => xs[Math.floor(Math.random() * xs.length)];

export const LINES = {
  success: [
    'IT WORKS!',
    'WHO GAVE YOU PERMISSION TO BE THIS GOOD?',
    'THE WEBSITE LIVES!',
    'NO ERRORS. SUSPICIOUS.',
    'DEPLOYMENT APPROVED.',
    'YOU ACTUALLY FIXED IT.',
  ],
  failure: [
    'Well... the website has chosen violence.',
    'Close! The browser disagrees on a few things.',
    '404: Your idea was found. Your implementation was not.',
    'Not yet. But you’re closer than you were.',
    'The website says: “almost”.',
  ],
  jsError: [
    'JavaScript says: absolutely not.',
    'Congratulations. You invented a new bug.',
    'The console is screaming. Let’s read what it says.',
  ],
  cssBroken: ['CSS has entered another dimension.', 'Your CSS is having a little moment.'],
  timeout: ['Your code got stuck in a loop forever. I pulled the plug.', 'That code ran... and ran... and ran. Infinite loop?'],
  partial: ['Getting there! Look at those green checks.', 'Progress! A few more to go.'],
  hint: ['Psst. Here’s a clue.', 'Okay, a little help. Don’t tell the client.'],
  idle: ['Try something. Run it. See what happens.', 'Breaking things is allowed. Encouraged, even.', 'Press RUN whenever you like. There’s no penalty.'],
  dexStart: ['Remember: read the error message. It’s trying to help.', 'Everyone breaks things. The pros just fix them faster.'],
  tinaStart: ['I’ll be testing this. On everything. Good luck.'],
};

export const say = (k: keyof typeof LINES) => pick(LINES[k]);
