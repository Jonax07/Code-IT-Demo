import { ACHIEVEMENTS } from '../achievements/achievements';
import { FX } from '../animation/fx';
import { AudioManager } from '../audio/AudioManager';
import type { Level } from '../levels/types';
import { PlayerStore, type Settings } from '../player/store';
import { rankFor, type XpLine } from '../progression/scoring';
import { portrait, say } from './characters';
import { $, el, esc, openDialog } from './dom';
import { stars } from './widgets';

const THANKS = ['It’s perfect. I’m crying a little.', 'You are hired. Again. Forever.', 'This is exactly what I imagined. Probably.', 'I will tell everyone about you. Everyone.'];

export function showEventDialog(level: Level, onAccept: () => void): void {
  const ev = level.event!;
  const d = el('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'ev-title', 'data-dismissable': 'false' });
  d.innerHTML = `
    <div class="modal event-modal">
      <div class="ringing mono" aria-hidden="true">📞 INCOMING CHANGE REQUEST</div>
      <h2 id="ev-title" class="event-title">${esc(ev.title)}</h2>
      <div class="event-from">
        <div class="avatar">${portrait('client', 'shocked', level.client.avatarColor)}</div>
        <blockquote><p>${esc(ev.message)}</p><cite>${esc(level.client.name)}</cite></blockquote>
      </div>
      <div class="group-label mono">NEW REQUIREMENT</div>
      <ul class="checks">${ev.requirements.map((r) => `<li class="check pending"><span class="mark" aria-hidden="true">+</span><span class="label">${esc(r.label)}</span></li>`).join('')}</ul>
      <p class="fine">Real clients do this constantly. Your code still works. You just need to change it a little.</p>
      <div class="modal-actions"><button class="btn-primary" type="button" autofocus data-ok>Ugh. Fine. On it.</button></div>
    </div>`;
  const close = openDialog(d, onAccept);
  FX.shake($('.modal', d), 'big');
  $('[data-ok]', d).addEventListener('click', () => {
    AudioManager.play('button');
    close();
  });
}

export interface ResultsOptions {
  level: Level;
  xp: { lines: XpLine[]; total: number; stars: number };
  prevXp: number;
  achievements: string[];
  durationMs: number;
  next?: Level;
  onNext: (l: Level) => void;
  onStay: () => void;
  onBoard: () => void;
}

export function showResultsDialog(o: ResultsOptions): void {
  const mins = Math.floor(o.durationMs / 60000);
  const secs = Math.round((o.durationMs % 60000) / 1000);
  const newXp = PlayerStore.get().xp;
  const before = rankFor(o.prevXp);
  const after = rankFor(newXp);
  const unlocked = ACHIEVEMENTS.filter((a) => o.achievements.includes(a.id));
  const d = el('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'res-title' });
  d.innerHTML = `
    <div class="modal results-modal">
      <div class="stamp mono" aria-hidden="true">${esc(say('success'))}</div>
      <h2 id="res-title">Job #${String(o.level.number).padStart(2, '0')} complete</h2>
      <div class="res-client">
        <div class="avatar">${portrait('client', 'happy', o.level.client.avatarColor)}</div>
        <blockquote><p>${esc(THANKS[o.level.number % THANKS.length])}</p><cite>${esc(o.level.client.name)}</cite></blockquote>
      </div>
      <div class="res-grid">
        <div class="res-stars">${stars(o.xp.stars)}<span class="mono muted">${mins}:${String(secs).padStart(2, '0')}</span></div>
        <ul class="xp-lines">${o.xp.lines.map((l, i) => `<li style="--i:${i}"><span>${esc(l.label)}</span><span class="mono">+${l.xp}</span></li>`).join('')}</ul>
        <div class="xp-total"><span class="mono muted">TOTAL</span><span class="mono big">+<span data-count>0</span> XP</span></div>
      </div>
      ${after.rank > before.rank ? `<div class="rank-up"><span class="mono">RANK UP</span> You are now a <strong>${esc(after.title)}</strong>.</div>` : ''}
      ${unlocked.length ? `<div class="group-label mono">ACHIEVEMENTS UNLOCKED</div><ul class="ach-row">${unlocked.map((a) => `<li class="ach on"><span class="ach-icon" aria-hidden="true">${a.icon}</span><span><strong>${esc(a.title)}</strong><small>${esc(a.description)}</small></span></li>`).join('')}</ul>` : ''}
      <div class="learned"><span class="mono muted">YOU PRACTISED</span> ${o.level.concepts.map((c) => `<span class="chip">${esc(c)}</span>`).join('')}</div>
      <div class="modal-actions">
        ${o.next ? `<button class="btn-primary" type="button" data-next autofocus>Next job: ${esc(o.next.title)} <span aria-hidden="true">→</span></button><p class="next-teaser">Unlocked: ${esc(o.level.unlocks)}</p>` : `<button class="btn-primary" type="button" data-board autofocus>Back to the job board</button><p class="next-teaser">That was the last job. You built, broke, and fixed a whole website.</p>`}
        <div class="secondary-actions"><button class="btn-ghost" type="button" data-stay>Keep tinkering</button>${o.next ? '<button class="btn-ghost" type="button" data-board>Job board</button>' : ''}</div>
      </div>
    </div>`;
  const close = openDialog(d);
  FX.pop($('.modal', d));
  void FX.countUp($('[data-count]', d), 0, o.xp.total, 1100, () => AudioManager.play('xp_tick'));
  if (unlocked.length) window.setTimeout(() => AudioManager.play('achievement'), 1200);
  d.querySelector('[data-next]')?.addEventListener('click', () => {
    close();
    o.onNext(o.next!);
  });
  d.querySelectorAll('[data-board]').forEach((b) => b.addEventListener('click', () => { close(); o.onBoard(); }));
  $('[data-stay]', d).addEventListener('click', () => {
    close();
    o.onStay();
  });
}

export function showSettingsDialog(onChange: (s: Settings) => void, onResetProgress: () => void): void {
  const s = PlayerStore.get().settings;
  const d = el('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'set-title' });
  const slider = (key: keyof Settings, label: string) =>
    `<label class="field"><span>${label}</span><input type="range" min="0" max="100" step="5" data-key="${key}" value="${Math.round((s[key] as number) * 100)}" aria-label="${label}"></label>`;
  const toggle = (key: keyof Settings, label: string, help = '') =>
    `<label class="toggle"><input type="checkbox" data-key="${key}" ${s[key] ? 'checked' : ''}><span class="switch" aria-hidden="true"></span><span class="t-label">${label}${help ? `<small>${help}</small>` : ''}</span></label>`;
  d.innerHTML = `
    <div class="modal settings-modal">
      <div class="modal-head"><h2 id="set-title">Settings</h2><button class="icon-btn" type="button" data-close aria-label="Close settings">✕</button></div>
      <div class="group-label mono">SOUND</div>
      ${toggle('soundEffects', 'Sound effects')}
      ${toggle('music', 'Background music', 'A quiet little loop.')}
      ${slider('masterVolume', 'Master volume')}
      ${slider('effectsVolume', 'Effects volume')}
      ${slider('musicVolume', 'Music volume')}
      ${toggle('captions', 'Sound captions', 'Shows text like [sad trombone] for every sound.')}
      <div class="group-label mono">DISPLAY</div>
      ${toggle('reducedMotion', 'Reduce motion', 'No confetti, shaking or bouncing.')}
      <label class="field"><span>Theme</span>
        <select data-key="theme"><option value="dark" ${s.theme === 'dark' ? 'selected' : ''}>Dark</option><option value="light" ${s.theme === 'light' ? 'selected' : ''}>Light</option></select>
      </label>
      <div class="group-label mono">PROGRESS</div>
      <button class="btn-danger" type="button" data-reset>Reset all progress</button>
    </div>`;
  const close = openDialog(d);
  d.addEventListener('input', (e) => {
    const input = e.target as HTMLInputElement | HTMLSelectElement;
    const key = input.dataset.key as keyof Settings | undefined;
    if (!key) return;
    PlayerStore.update((p) => {
      const settings = p.settings as unknown as Record<string, unknown>;
      if (input instanceof HTMLInputElement && input.type === 'checkbox') settings[key] = input.checked;
      else if (input instanceof HTMLInputElement && input.type === 'range') settings[key] = Number(input.value) / 100;
      else settings[key] = input.value;
    }, true);
    onChange(PlayerStore.get().settings);
    if (input instanceof HTMLInputElement && input.type === 'checkbox') AudioManager.play('button');
  });
  $('[data-close]', d).addEventListener('click', close);
  d.addEventListener('click', (e) => {
    if (e.target === d) close();
  });
  $('[data-reset]', d).addEventListener('click', (e) => {
    const b = e.currentTarget as HTMLButtonElement;
    if (b.dataset.armed !== '1') {
      b.dataset.armed = '1';
      b.textContent = 'Really? Click again to erase everything.';
      return;
    }
    close();
    onResetProgress();
  });
}

export function showAchievementsDialog(): void {
  const have = new Set(PlayerStore.get().achievements);
  const d = el('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'ach-title' });
  d.innerHTML = `
    <div class="modal ach-modal">
      <div class="modal-head"><h2 id="ach-title">Achievements <span class="mono muted">${have.size}/${ACHIEVEMENTS.length}</span></h2><button class="icon-btn" type="button" data-close aria-label="Close">✕</button></div>
      <ul class="ach-grid">${ACHIEVEMENTS.map((a) => `<li class="ach ${have.has(a.id) ? 'on' : 'off'}"><span class="ach-icon" aria-hidden="true">${have.has(a.id) ? a.icon : '?'}</span><span><strong>${esc(a.title)}</strong><small>${esc(a.description)}</small></span><span class="sr-only">${have.has(a.id) ? 'unlocked' : 'locked'}</span></li>`).join('')}</ul>
    </div>`;
  const close = openDialog(d);
  $('[data-close]', d).addEventListener('click', close);
  d.addEventListener('click', (e) => {
    if (e.target === d) close();
  });
}
