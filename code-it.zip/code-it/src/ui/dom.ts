/** Tiny DOM helpers. Anything interpolated into HTML must go through esc(). */
export const esc = (s: string): string =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

export function el<K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Record<string, string> = {}, html = ''): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  if (html) node.innerHTML = html;
  return node;
}

export const $ = <T extends Element = HTMLElement>(sel: string, root: ParentNode = document): T => {
  const found = root.querySelector<T>(sel);
  if (!found) throw new Error(`Missing element: ${sel}`);
  return found;
};

/** Traps focus inside a dialog and restores it on close. Returns a close function. */
export function openDialog(dialog: HTMLElement, onClose?: () => void): () => void {
  const previous = document.activeElement as HTMLElement | null;
  document.body.appendChild(dialog);
  const focusables = () =>
    Array.from(dialog.querySelectorAll<HTMLElement>('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')).filter(
      (e) => !e.hasAttribute('disabled'),
    );
  const onKey = (e: KeyboardEvent) => {
    if (e.key === 'Escape' && dialog.dataset.dismissable !== 'false') {
      e.preventDefault();
      close();
    }
    if (e.key === 'Tab') {
      const f = focusables();
      if (!f.length) return;
      const first = f[0];
      const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };
  dialog.addEventListener('keydown', onKey);
  requestAnimationFrame(() => (dialog.querySelector<HTMLElement>('[autofocus]') ?? focusables()[0])?.focus());
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    dialog.removeEventListener('keydown', onKey);
    dialog.remove();
    previous?.focus?.();
    onClose?.();
  };
  return close;
}
