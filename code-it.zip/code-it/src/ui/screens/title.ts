import { AudioManager } from '../../audio/AudioManager';
import { PlayerStore } from '../../player/store';
import { portrait } from '../characters';

const TERMINAL = [
  ['cmd', '$ build website'],
  ['ok', '✓ added a button'],
  ['cmd', '$ run'],
  ['bad', '✕ TypeError: button has chosen violence'],
  ['cmd', '$ fix it'],
  ['ok', '✓ IT WORKS!'],
];

const GLYPHS = ['&lt;/&gt;', '{ }', '&lt;div&gt;', '#fff', ';', '=&gt;', '&lt;h1&gt;', '.css', '()', '[ ]']; // HTML-escaped: inserted as markup

/** Logo letters drop in one after another (aria-hidden: the h1 carries the real label). */
const letters = (word: string, offset: number) =>
  [...word].map((ch, i) => `<span class="logo-l" aria-hidden="true" style="--n:${offset + i}">${ch}</span>`).join('');

export function mountTitle(root: HTMLElement, h: { onStart: () => void; onSettings: () => void }): () => void {
  const isNew = PlayerStore.isNew();
  root.innerHTML = `
  <main class="title-screen">
    <div class="title-grid" aria-hidden="true"></div>
    <div class="title-glyphs mono" aria-hidden="true">${GLYPHS.map((g, i) => `<span style="--i:${i}">${g}</span>`).join('')}</div>
    <div class="title-inner">
      <div class="title-left">
        <p class="kicker mono"><span class="kicker-brand">WEB DEVELOPMENT SERVICES</span> PRESENTS</p>
        <h1 class="logo" aria-label="CODE IT!">${letters('CODE', 0)}<span class="logo-bang">&nbsp;${letters('IT!', 4)}</span><span class="caret" aria-hidden="true"></span></h1>
        <p class="tagline"><span>Build it.</span> <span class="break">Break it.</span> <span class="fix">Fix it.</span></p>
        <p class="pitch">You’re the new junior web developer. The clients are ridiculous. The previous developer is gone. Write real HTML, CSS and JavaScript to get the jobs done.</p>
        <div class="title-actions">
          <button class="btn-primary big shine" type="button" data-start autofocus>${isNew ? 'Start your first job' : 'Continue'} <span aria-hidden="true">→</span></button>
          <button class="btn-ghost" type="button" data-settings>Settings</button>
        </div>
        <p class="fine">No sign-up. Progress saves on this device. Works offline.</p>
      </div>
      <div class="title-right" aria-hidden="true">
        <div class="terminal">
          <div class="term-bar"><i></i><i></i><i></i><span class="mono">byte@junior-dev ~</span></div>
          <ol class="term-lines mono">${TERMINAL.map(([k, t], i) => `<li class="t-${k}" style="--d:${i * 0.55 + 0.3}s">${t}</li>`).join('')}</ol>
        </div>
        <div class="title-byte">${portrait('byte', 'happy')}</div>
      </div>
    </div>
    <footer class="title-foot mono">© ${new Date().getFullYear()} Web Development Services</footer>
  </main>`;
  const start = () => {
    AudioManager.unlock();
    AudioManager.play('button');
    h.onStart();
  };
  root.querySelector('[data-start]')!.addEventListener('click', start);
  root.querySelector('[data-settings]')!.addEventListener('click', () => {
    AudioManager.unlock();
    h.onSettings();
  });
  return () => {};
}
