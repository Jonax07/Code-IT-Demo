/**
 * The main gameplay screen: job ticket, editor, live preview, and status/console.
 * Wires UI events to LevelSession (rules) and PreviewSandbox (rendering).
 */
import { Achievements } from '../../achievements/achievements';
import { Analytics } from '../../analytics/analytics';
import { FX } from '../../animation/fx';
import { ApiClient } from '../../api/client';
import { AudioManager } from '../../audio/AudioManager';
import { Diagnostics } from '../../diagnostics/diagnostics';
import { CodeEditor } from '../../editor/editor';
import { LevelSession, type RunOutcome } from '../../engine/session';
import { LevelRepository } from '../../levels/repository';
import type { Lang, Level } from '../../levels/types';
import { PlayerStore } from '../../player/store';
import { PreviewSandbox, type ConsoleEntry, type PlayerCode, type RuntimeError } from '../../sandbox/sandbox';
import { cssSupports } from '../../validation/engine';
import { findSelectorLine, lintCss, lintHtml, type LintIssue } from '../../validation/lint';
import type { CheckResult, ValidationReport } from '../../validation/engine';
import { portrait, say, type Mood } from '../characters';
import { $, esc } from '../dom';
import { announce, toast } from '../toast';
import { showEventDialog, showResultsDialog } from '../dialogs';
import { rankBar } from '../widgets';

const LANG_LABEL: Record<Lang, string> = { html: 'HTML', css: 'CSS', js: 'JS' };
const HINT_LABELS = ['Concept', 'Direction', 'Almost there', 'Example'];

export interface GameScreenHandlers {
  onExit: () => void;
  onNext: (level: Level) => void;
  onSettings: () => void;
}

export function mountGame(root: HTMLElement, level: Level, h: GameScreenHandlers): () => void {
  const record = PlayerStore.level(level.id);
  const session = new LevelSession(level, !record.completed);
  const code: PlayerCode = { ...(record.draft ?? { html: level.starter.html, css: level.starter.css, js: level.starter.js }) };
  const disposers: (() => void)[] = [];
  let consoleEntries: ConsoleEntry[] = [];
  let previewErrors: RuntimeError[] = [];
  let unmatchedSelectors: string[] = [];
  let stale = false;
  let running = false;

  const slug = level.client.name.toLowerCase().replace(/[^a-z]+/g, '-').replace(/^-|-$/g, '');
  root.innerHTML = `
  <div class="game" data-tab="code">
    <header class="topbar">
      <button class="btn-ghost back" type="button" data-action="exit"><span aria-hidden="true">←</span> Jobs</button>
      <div class="job-title"><span class="job-no mono">JOB #${String(level.number).padStart(2, '0')}</span><h1>${esc(level.title)}</h1></div>
      <button class="btn-ghost brief-toggle" type="button" data-action="brief" aria-expanded="false" aria-controls="brief">Ticket</button>
      <div class="topbar-right">${rankBar(PlayerStore.get().xp)}
        <button class="icon-btn" type="button" data-action="settings" aria-label="Settings"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" fill="none" stroke="currentColor" stroke-width="2"/></svg></button>
      </div>
    </header>

    <nav class="mobile-tabs" role="tablist" aria-label="Panels">
      <button role="tab" type="button" data-tab="job" aria-selected="false">Ticket</button>
      <button role="tab" type="button" data-tab="code" aria-selected="true">Code</button>
      <button role="tab" type="button" data-tab="preview" aria-selected="false">Preview</button>
      <button role="tab" type="button" data-tab="status" aria-selected="false">Status <span class="tab-badge" hidden></span></button>
    </nav>

    <aside class="brief panel" id="brief" data-panel="job" aria-label="Job ticket">
      <div class="ticket">
        <div class="ticket-head">
          <div class="avatar" data-client-portrait>${portrait('client', 'neutral', level.client.avatarColor)}</div>
          <div><div class="client-name">${esc(level.client.name)}</div><div class="client-role">${esc(level.client.role)}</div></div>
        </div>
        <p class="brief-text">${esc(level.brief)}</p>
        <div class="ticket-meta">
          <div class="meta-label mono">YOU'LL LEARN</div>
          <p class="objective">${esc(level.objective)}</p>
          <ul class="chips">${level.concepts.map((c) => `<li>${esc(c)}</li>`).join('')}</ul>
        </div>
      </div>
      <section class="hints" aria-labelledby="hints-h">
        <div class="section-head"><h2 id="hints-h">Hints</h2><span class="mono muted" data-hint-count></span></div>
        <ol class="hint-list" data-hints></ol>
        <button class="btn-secondary hint-btn" type="button" data-action="hint"></button>
        <p class="fine">Hints never cost XP. You only miss the small no-hint bonus.</p>
      </section>
    </aside>

    <section class="code panel" data-panel="code" aria-label="Code editor">
      <div class="code-head">
        <div class="file-tabs" role="tablist" aria-label="Files">
          ${level.tabs.map((t, i) => `<button role="tab" type="button" id="tab-${t}" class="file-tab file-${t}" data-lang="${t}" aria-selected="${i === 0}" aria-controls="editor-pane-${t}"><span class="dot" aria-hidden="true"></span>${LANG_LABEL[t]}<span class="err-dot" hidden aria-label="has problems"></span></button>`).join('')}
        </div>
        <div class="tools">
          <button class="icon-btn" type="button" data-action="undo" aria-label="Undo" title="Undo (Ctrl+Z)"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 14 4 9l5-5M4 9h10.5a5.5 5.5 0 0 1 0 11H11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
          <button class="icon-btn" type="button" data-action="redo" aria-label="Redo" title="Redo (Ctrl+Shift+Z)"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 14 5-5-5-5M20 9H9.5a5.5 5.5 0 0 0 0 11H13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
          <button class="btn-ghost small" type="button" data-action="format" title="Tidy up indentation">Format</button>
          <button class="btn-ghost small" type="button" data-action="reset" title="Back to the starter code (you can undo)">Reset</button>
        </div>
      </div>
      <div class="editor-host"></div>
      <div class="run-bar">
        <button class="run-btn" type="button" data-action="run" aria-keyshortcuts="Control+Enter">
          <span class="run-icon" aria-hidden="true">▶</span><span class="run-label">RUN</span><kbd class="run-kbd">Ctrl ↵</kbd>
        </button>
        <div class="run-meta mono"><span data-runs>0 runs</span><span class="sep">·</span><span>Breaking things is allowed</span></div>
      </div>
    </section>

    <section class="preview panel" data-panel="preview" aria-label="Live preview">
      <div class="browser-bar">
        <span class="lights" aria-hidden="true"><i></i><i></i><i></i></span>
        <span class="url mono">${esc(slug)}.site</span>
        <span class="live mono" title="The preview updates as you type"><i aria-hidden="true"></i>LIVE</span>
      </div>
      <div class="preview-host"></div>
    </section>

    <section class="status panel" data-panel="status" aria-label="Job status">
      <div class="status-tabs" role="tablist">
        <button role="tab" type="button" class="status-tab" data-status-tab="check" aria-selected="true">Checklist</button>
        <button role="tab" type="button" class="status-tab" data-status-tab="console" aria-selected="false">Console <span class="count mono" data-console-count>0</span></button>
        <div class="status-pill mono" data-status-pill>NOT RUN YET</div>
      </div>
      <div class="status-body">
        <div class="reaction">
          <div class="avatar byte" data-byte>${portrait('byte', 'neutral')}</div>
          <div class="bubble" data-bubble>${esc(say('idle'))}</div>
        </div>
        <div class="check-area" data-check-area></div>
        <div class="console-area" data-console hidden><ol class="console-list" data-console-list></ol></div>
      </div>
    </section>
  </div>`;

  const game = $('.game', root);
  const byteEl = $('[data-byte]', root);
  const bubble = $('[data-bubble]', root);
  const checkArea = $('[data-check-area]', root);
  const pill = $('[data-status-pill]', root);
  const runBtn = $<HTMLButtonElement>('[data-action="run"]', root);
  const previewHost = $('.preview-host', root);
  const preview = new PreviewSandbox(previewHost);
  disposers.push(() => preview.dispose());

  // ------------------------------------------------------------------ editor
  const editor = new CodeEditor($('.editor-host', root), level.tabs, code, {
    onChange: (lang, value) => {
      code[lang] = value;
      markStale();
      runBtn.classList.add('dirty'); // gentle "you changed something, try it" pulse
      scheduleLint();
      schedulePreview();
      PlayerStore.update((p) => {
        p.levels[level.id] = { ...PlayerStore.level(level.id), draft: { ...code } };
      });
    },
    onRun: () => void run(),
  });
  disposers.push(() => editor.destroy());

  const fileTabs = Array.from(root.querySelectorAll<HTMLButtonElement>('.file-tab'));
  const selectFile = (lang: Lang) => {
    editor.show(lang);
    fileTabs.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.lang === lang)));
  };
  fileTabs.forEach((t) =>
    t.addEventListener('click', () => {
      AudioManager.play('button');
      selectFile(t.dataset.lang as Lang);
    }),
  );
  // Arrow keys move between file tabs (WAI-ARIA tabs pattern).
  $('.file-tabs', root).addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    const i = fileTabs.findIndex((t) => t.dataset.lang === editor.activeLang);
    const next = fileTabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + fileTabs.length) % fileTabs.length];
    selectFile(next.dataset.lang as Lang);
    next.focus();
  });

  // ------------------------------------------------------------------ lint + live preview
  let lintTimer: number | undefined;
  let previewTimer: number | undefined;
  const scheduleLint = () => {
    clearTimeout(lintTimer);
    lintTimer = window.setTimeout(lintNow, 250);
  };
  const schedulePreview = () => {
    clearTimeout(previewTimer);
    previewTimer = window.setTimeout(renderPreview, 450);
  };

  const issuesFor = (): Record<Lang, LintIssue[]> => {
    const css = lintCss(code.css, cssSupports);
    for (const sel of unmatchedSelectors) {
      const line = findSelectorLine(code.css, sel);
      if (line) css.push({ line, message: `"${sel}" doesn’t match anything in your HTML. Typo?`, severity: 'warning' });
    }
    return {
      html: lintHtml(code.html),
      css,
      js: previewErrors.filter((e) => e.kind === 'js' && e.line).map((e) => ({ line: e.line!, message: e.message, severity: 'error' as const })),
    };
  };

  const lintNow = () => {
    const all = issuesFor();
    for (const lang of level.tabs) {
      editor.setIssues(lang, all[lang]);
      const hasErr = all[lang].length > 0;
      const dot = root.querySelector<HTMLElement>(`.file-tab[data-lang="${lang}"] .err-dot`);
      if (dot) {
        dot.hidden = !hasErr;
        dot.classList.toggle('warn', hasErr && all[lang].every((i) => i.severity === 'warning'));
      }
    }
  };

  const renderPreview = () => {
    consoleEntries = [];
    previewErrors = [];
    renderConsole();
    const t0 = performance.now();
    preview.render(code, {
      onConsole: (e) => {
        consoleEntries.push(e);
        renderConsole();
      },
      onError: (e) => {
        previewErrors.push(e);
        consoleEntries.push({ level: 'error', text: e.line ? `Line ${e.line}: ${e.message}` : e.message });
        renderConsole();
        lintNow();
      },
      onSelectors: (u) => {
        unmatchedSelectors = u;
        lintNow();
      },
      onReady: (info) => Diagnostics.record('preview', { renderMs: performance.now() - t0, executionMs: info.executionTimeMs }),
    });
  };

  // ------------------------------------------------------------------ console
  const consoleList = $('[data-console-list]', root);
  const consoleCount = $('[data-console-count]', root);
  const renderConsole = () => {
    consoleCount.textContent = String(consoleEntries.length);
    consoleCount.classList.toggle('has-errors', consoleEntries.some((e) => e.level === 'error'));
    consoleList.innerHTML = consoleEntries.length
      ? consoleEntries
          .slice(-200)
          .map((e) => `<li class="log log-${e.level}"><span class="lvl mono">${e.level === 'alert' ? 'alert' : e.level}</span><span class="msg mono">${esc(e.text)}</span></li>`)
          .join('')
      : `<li class="log empty">Nothing logged yet. Try <code>console.log('hello')</code> in JS.</li>`;
  };

  const statusTabs = Array.from(root.querySelectorAll<HTMLButtonElement>('[data-status-tab]'));
  const showStatusTab = (which: 'check' | 'console') => {
    statusTabs.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.statusTab === which)));
    checkArea.hidden = which !== 'check';
    $('[data-console]', root).hidden = which !== 'console';
  };
  statusTabs.forEach((t) => t.addEventListener('click', () => showStatusTab(t.dataset.statusTab as 'check' | 'console')));

  // ------------------------------------------------------------------ checklist
  const react = (mood: Mood, text: string) => {
    byteEl.innerHTML = portrait('byte', mood);
    bubble.textContent = text;
    FX.pop(bubble);
  };

  const pendingChecklist = () => {
    const reqs = session.requirements();
    checkArea.innerHTML = `
      <div class="feedback-head"><span class="mono muted">REQUIREMENTS</span><span class="mono muted">${reqs.filter((r) => !r.bonus).length} to pass</span></div>
      <ul class="checks">${reqs.map((r) => `<li class="check pending${r.bonus ? ' bonus' : ''}"><span class="mark" aria-hidden="true">○</span><span class="label">${esc(r.label)}${r.bonus ? ' <span class="tag">bonus</span>' : ''}</span></li>`).join('')}</ul>`;
  };

  const errorBlock = (report: ValidationReport) => {
    const items: string[] = [];
    for (const e of report.runtimeErrors.filter((x) => x.kind === 'js').slice(0, 3)) {
      items.push(`<li><button type="button" class="goto" data-goto="js:${e.line ?? 1}"><span class="mono">JS${e.line ? ` line ${e.line}` : ''}</span> ${esc(e.message)}</button></li>`);
    }
    for (const e of report.runtimeErrors.filter((x) => x.kind === 'resource').slice(0, 2)) {
      items.push(`<li><span class="mono">HTML</span> ${esc(e.message)}</li>`);
    }
    for (const lang of ['html', 'css'] as const) {
      if (!level.tabs.includes(lang)) continue;
      for (const i of report.lint[lang].filter((x) => x.severity === 'error').slice(0, 3)) {
        items.push(`<li><button type="button" class="goto" data-goto="${lang}:${i.line}"><span class="mono">${LANG_LABEL[lang]} line ${i.line}</span> ${esc(i.message)}</button></li>`);
      }
    }
    if (report.timedOut) items.unshift('<li><span class="mono">TIMEOUT</span> Your code never finished. Look for a loop that never stops.</li>');
    return items.length ? `<div class="errors"><div class="mono err-title">PROBLEMS SPOTTED</div><ul>${items.join('')}</ul></div>` : '';
  };

  const checkItem = (c: CheckResult) =>
    `<li class="check ${c.pass ? 'pass' : 'fail'}${c.bonus ? ' bonus' : ''}">
      <span class="mark" aria-hidden="true">${c.pass ? '✓' : '✕'}</span>
      <span class="label">${esc(c.label)}${c.bonus ? ' <span class="tag">bonus</span>' : ''}<span class="sr-only">${c.pass ? ' passed' : ' failed'}</span>
      ${!c.pass ? `<span class="why">${esc(c.fail)}${c.detail ? ` <span class="detail mono">(${esc(c.detail)})</span>` : ''}</span>${c.tip ? `<span class="tip">→ ${esc(c.tip)}</span>` : ''}` : ''}</span>
    </li>`;

  const renderReport = (report: ValidationReport, headline: string) => {
    const failed = report.checks.filter((c) => !c.pass);
    const passed = report.checks.filter((c) => c.pass);
    const ok = report.passed;
    checkArea.innerHTML = `
      <div class="feedback-head">
        <span class="result-word ${ok ? 'good' : 'bad'}">${ok ? 'SUCCESS' : 'FAILED'}</span>
        <span class="mono muted">${passed.length}/${report.checks.length} checks · ${Math.round(report.timings.totalMs)}ms</span>
      </div>
      <p class="headline">${esc(headline)}</p>
      ${errorBlock(report)}
      ${failed.length ? `<div class="group-label mono">WHAT FAILED</div><ul class="checks">${failed.map(checkItem).join('')}</ul>` : ''}
      ${passed.length ? `<div class="group-label mono">WHAT WORKED</div><ul class="checks">${passed.map(checkItem).join('')}</ul>` : ''}
      ${report.bonus.length ? `<div class="group-label mono">BONUS</div><ul class="checks">${report.bonus.map(checkItem).join('')}</ul>` : ''}
      ${!ok && session.hintsRevealed < level.hints.length ? `<button type="button" class="btn-secondary small inline-hint" data-action="hint">Stuck? Get hint ${session.hintsRevealed + 1} of ${level.hints.length}</button>` : ''}`;
    pill.textContent = ok ? 'PASSING' : `${failed.length} TO FIX`;
    pill.className = `status-pill mono ${ok ? 'good' : 'bad'}`;
    stale = false;
    checkArea.classList.remove('stale');
  };

  const markStale = () => {
    if (stale || !session.lastReport) return;
    stale = true;
    checkArea.classList.add('stale');
    pill.textContent = 'CHANGED · RUN AGAIN';
    pill.className = 'status-pill mono';
  };

  checkArea.addEventListener('click', (e) => {
    const target = (e.target as HTMLElement).closest<HTMLElement>('[data-goto]');
    if (target) {
      const [lang, line] = target.dataset.goto!.split(':');
      if (window.matchMedia('(max-width: 819px)').matches) setTab('code');
      editor.goToLine(lang as Lang, Number(line));
      fileTabs.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.lang === lang)));
    }
  });

  // ------------------------------------------------------------------ hints
  const hintList = $('[data-hints]', root);
  const hintBtn = $<HTMLButtonElement>('.hint-btn', root);
  const renderHints = () => {
    hintList.innerHTML = level.hints
      .slice(0, session.hintsRevealed)
      .map((t, i) => `<li class="hint"><span class="hint-kind mono">${i + 1} · ${HINT_LABELS[i]}</span>${i === 3 ? `<pre class="mono">${esc(t.replace(/^Example[^:]*:\n?/, ''))}</pre>` : `<p>${esc(t)}</p>`}</li>`)
      .join('');
    const left = level.hints.length - session.hintsRevealed;
    hintBtn.hidden = left === 0;
    hintBtn.textContent = session.hintsRevealed === 0 ? 'Get a hint' : session.hintsRevealed === 3 ? 'Show an example' : 'Next hint';
    $('[data-hint-count]', root).textContent = `${session.hintsRevealed}/${level.hints.length}`;
  };
  const useHint = () => {
    const i = session.revealHint();
    if (i == null) return;
    AudioManager.play('hint');
    renderHints();
    Analytics.track({ event: 'hint_used', levelId: level.id, hintIndex: i });
    react('smug', say('hint'));
    // Hints live in the ticket. Make sure the player can see it.
    if (window.matchMedia('(max-width: 819px)').matches) setTab('job');
    else if (window.matchMedia('(max-width: 1199px)').matches) toggleBrief(true);
    const last = hintList.lastElementChild as HTMLElement | null;
    last?.scrollIntoView({ block: 'nearest', behavior: FX.reduced ? 'auto' : 'smooth' });
    if (last) FX.pop(last);
    announce(`Hint ${i + 1}: ${level.hints[i]}`);
  };

  // ------------------------------------------------------------------ run
  const runsLabel = $('[data-runs]', root);
  const run = async () => {
    if (running) return;
    running = true;
    AudioManager.unlock();
    AudioManager.play('run');
    runBtn.classList.remove('dirty');
    runBtn.classList.add('running');
    runBtn.setAttribute('aria-busy', 'true');
    $('.run-label', runBtn).textContent = 'RUNNING';
    clearTimeout(previewTimer);
    renderPreview();
    PlayerStore.update((p) => p.stats.runs++);
    if (PlayerStore.get().stats.runs === 1) Achievements.unlock('hello-world');

    const prevHadErrors = !!session.lastReport?.runtimeErrors.some((e) => e.kind === 'js');
    let outcome: RunOutcome;
    try {
      outcome = await session.run({ ...code });
    } finally {
      running = false;
      runBtn.classList.remove('running');
      runBtn.removeAttribute('aria-busy');
      $('.run-label', runBtn).textContent = 'RUN';
    }
    if (outcome.kind === 'cancelled') return;
    runsLabel.textContent = `${session.runs} run${session.runs === 1 ? '' : 's'}`;
    const report = outcome.report;
    Diagnostics.record('validation', { ...report.timings, checks: report.checks.length });
    Analytics.track({
      event: 'code_run',
      levelId: level.id,
      passed: report.passed,
      failedChecks: report.checks.filter((c) => !c.pass).map((c) => c.id),
      errorCount: report.runtimeErrors.length,
      validationMs: Math.round(report.timings.totalMs),
    });
    const hasJsErrors = report.runtimeErrors.some((e) => e.kind === 'js');
    if (hasJsErrors) {
      PlayerStore.update((p) => p.stats.errorsSeen++);
      if (!level.isDebug) Achievements.unlock('new-bug');
    }
    if (prevHadErrors && !hasJsErrors) {
      PlayerStore.update((p) => p.stats.bugsFixed++);
      Achievements.unlock('bug-squasher');
    }
    if (session.runs >= 10) Achievements.unlock('experimenter');

    if (outcome.kind === 'fail') {
      const passedCount = report.checks.filter((c) => c.pass).length;
      const headline = report.timedOut ? say('timeout') : hasJsErrors ? say('jsError') : report.lint.css.some((i) => i.severity === 'error') ? say('cssBroken') : passedCount > 0 ? say('partial') : say('failure');
      renderReport(report, headline);
      react(hasJsErrors || report.timedOut ? 'shocked' : 'sad', headline);
      AudioManager.play(hasJsErrors ? 'error' : 'failure');
      FX.shake($('.preview', root));
      setBadge(report.checks.filter((c) => !c.pass).length);
      if (window.matchMedia('(max-width: 819px)').matches) setTab('status');
      showStatusTab('check');
      announce(`Failed. ${passedCount} of ${report.checks.length} checks pass. First problem: ${report.checks.find((c) => !c.pass)?.fail ?? 'code error'}`);
      return;
    }

    if (outcome.kind === 'event' && level.event) {
      renderReport(report, say('success'));
      react('happy', say('success'));
      AudioManager.play('success');
      FX.bounce(byteEl);
      setBadge(0);
      window.setTimeout(() => {
        AudioManager.play('event');
        Analytics.track({ event: 'requirement_changed', levelId: level.id });
        showEventDialog(level, () => {
          pendingChecklist();
          pill.textContent = 'NEW REQUIREMENT';
          pill.className = 'status-pill mono warn';
          react('shocked', 'The client changed the requirements. This is... normal, actually. Welcome to web development.');
          setBadge(level.event!.requirements.length);
          if (window.matchMedia('(max-width: 819px)').matches) setTab('status');
          editor.focus();
        });
      }, FX.reduced ? 300 : 1100);
      return;
    }

    if (outcome.kind === 'complete') complete(outcome);
  };

  const complete = (outcome: Extract<RunOutcome, { kind: 'complete' }>) => {
    const report = outcome.report;
    const line = say('success');
    renderReport(report, line);
    react('happy', line);
    AudioManager.play('level_complete');
    FX.confetti();
    FX.bounce(byteEl);
    setBadge(0);
    $('[data-client-portrait]', root).innerHTML = portrait('client', 'happy', level.client.avatarColor);

    const prevXp = PlayerStore.get().xp;
    const prev = PlayerStore.level(level.id);
    PlayerStore.update((p) => {
      p.xp += outcome.xp.total;
      p.levels[level.id] = {
        ...prev,
        completed: true,
        attempts: prev.attempts + session.runs,
        hintsUsed: Math.max(prev.hintsUsed, session.hintsRevealed),
        bestXp: Math.max(prev.bestXp, outcome.xp.total),
        bestTimeMs: prev.bestTimeMs == null ? outcome.durationMs : Math.min(prev.bestTimeMs, outcome.durationMs),
        stars: Math.max(prev.stars, outcome.xp.stars),
        draft: { ...code },
      };
    }, true);

    // Progress sync: idempotent per level + run count, so retries never duplicate.
    ApiClient.enqueue(
      'POST',
      '/api/progress',
      {
        playerId: PlayerStore.get().id,
        levelId: level.id,
        completed: true,
        attempts: session.runs,
        hintsUsed: session.hintsRevealed,
        timeMs: Math.round(outcome.durationMs),
        score: outcome.xp.stars,
        xp: outcome.xp.total,
      },
      `progress:${level.id}:${PlayerStore.get().levels[level.id].attempts}`,
    );
    Analytics.track(
      { event: 'level_completed', levelId: level.id, attempts: session.runs, hintsUsed: session.hintsRevealed, durationMs: Math.round(outcome.durationMs), xp: outcome.xp.total },
      `complete:${level.id}:${session.startedAt}`,
    );

    const unlocked: string[] = [];
    const off = Achievements.onUnlock((a) => unlocked.push(a.id));
    Achievements.quiet = true;
    Achievements.unlock('first-job');
    if (session.hintsRevealed === 0) Achievements.unlock('no-hints');
    if (session.failedRuns === 0) Achievements.unlock('first-try');
    if (outcome.durationMs <= level.parTimeSec * 1000) Achievements.unlock('speedrun');
    if (report.bonus.some((b) => b.bonus === 'accessibility' && b.pass)) Achievements.unlock('a11y');
    if (level.event) Achievements.unlock('change-request');
    const debugLevels = LevelRepository.all().filter((l) => l.isDebug);
    if (debugLevels.every((l) => PlayerStore.level(l.id).completed)) Achievements.unlock('debugger');
    if (level.id === LevelRepository.all()[LevelRepository.all().length - 1].id) Achievements.unlock('launch-day');
    off();
    Achievements.quiet = false;

    announce(`Success! Job complete. You earned ${outcome.xp.total} XP.`);
    window.setTimeout(
      () =>
        showResultsDialog({
          level,
          xp: outcome.xp,
          prevXp,
          achievements: unlocked,
          durationMs: outcome.durationMs,
          next: LevelRepository.next(level.id),
          onNext: (n) => h.onNext(n),
          onStay: () => editor.focus(),
          onBoard: () => h.onExit(),
        }),
      FX.reduced ? 200 : 900,
    );
  };

  // ------------------------------------------------------------------ layout: tabs & drawer
  const mobileTabs = Array.from(root.querySelectorAll<HTMLButtonElement>('.mobile-tabs [data-tab]'));
  const setTab = (tab: string) => {
    game.dataset.tab = tab;
    mobileTabs.forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === tab)));
    if (tab === 'status') setBadge(0);
  };
  mobileTabs.forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab!)));
  const badge = $('.tab-badge', root);
  const setBadge = (n: number) => {
    badge.hidden = n === 0 || game.dataset.tab === 'status';
    badge.textContent = String(n);
  };

  const briefBtn = $('[data-action="brief"]', root);
  const toggleBrief = (force?: boolean) => {
    const open = force ?? !game.classList.contains('brief-open');
    game.classList.toggle('brief-open', open);
    briefBtn.setAttribute('aria-expanded', String(open));
  };

  // ------------------------------------------------------------------ actions
  root.addEventListener('click', async (e) => {
    const btn = (e.target as HTMLElement).closest<HTMLElement>('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    if (action !== 'run' && action !== 'hint') AudioManager.play('button');
    switch (action) {
      case 'run': return void run();
      case 'hint': return useHint();
      case 'exit': return h.onExit();
      case 'settings': return h.onSettings();
      case 'brief': return toggleBrief();
      case 'undo': editor.undo(); return editor.focus();
      case 'redo': editor.redo(); return editor.focus();
      case 'format': {
        const ok = await editor.format();
        if (!ok) toast('Can’t format code with syntax errors yet. Fix the red marks first.', { kind: 'bad' });
        return editor.focus();
      }
      case 'reset': {
        for (const lang of level.tabs) editor.setValue(lang, level.starter[lang]);
        PlayerStore.update((p) => p.stats.resets++);
        Analytics.track({ event: 'code_reset', levelId: level.id });
        toast('Back to the starter code. Changed your mind? Press Undo.', { kind: 'info' });
        return editor.focus();
      }
    }
  });

  // Close the ticket drawer when clicking outside it on tablet.
  const onDocClick = (e: MouseEvent) => {
    if (!game.classList.contains('brief-open')) return;
    const t = e.target as HTMLElement;
    if (!t.closest('.brief') && !t.closest('[data-action="brief"]') && !t.closest('[data-action="hint"]')) toggleBrief(false);
  };
  document.addEventListener('click', onDocClick);
  disposers.push(() => document.removeEventListener('click', onDocClick));

  const onKey = (e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      void run();
    }
  };
  window.addEventListener('keydown', onKey);
  disposers.push(() => window.removeEventListener('keydown', onKey));

  // ------------------------------------------------------------------ start
  pendingChecklist();
  renderHints();
  renderConsole();
  renderPreview();
  lintNow();
  Analytics.track({ event: 'level_started', levelId: level.id });
  const intro = level.isDebug ? say('dexStart') : level.category === 'layout' && level.difficulty === 3 ? say('tinaStart') : record.draft ? 'Welcome back. Your code is right where you left it.' : say('idle');
  react(level.isDebug ? 'smug' : 'neutral', intro);
  window.setTimeout(() => editor.focus(), 50);

  return () => {
    clearTimeout(lintTimer);
    clearTimeout(previewTimer);
    PlayerStore.flush();
    disposers.forEach((d) => d());
  };
}
