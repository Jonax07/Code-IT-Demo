import { ACHIEVEMENTS } from '../../achievements/achievements';
import { AudioManager } from '../../audio/AudioManager';
import { LevelRepository } from '../../levels/repository';
import type { Level } from '../../levels/types';
import { PlayerStore } from '../../player/store';
import { portrait } from '../characters';
import { esc } from '../dom';
import { rankBar, stars } from '../widgets';

const CATEGORY: Record<Level['category'], string> = {
  html: 'HTML', css: 'CSS', layout: 'LAYOUT', js: 'JAVASCRIPT', debug: 'DEBUG', project: 'PROJECT',
};

export function mountBoard(
  root: HTMLElement,
  h: { onPlay: (l: Level) => void; onSettings: () => void; onAchievements: () => void; onTitle: () => void },
): () => void {
  const p = PlayerStore.get();
  const levels = LevelRepository.all();
  const done = (id: string) => PlayerStore.level(id).completed;
  const nextUp = levels.find((l) => !done(l.id) && LevelRepository.isUnlocked(l.id, done));
  const completedCount = levels.filter((l) => done(l.id)).length;

  root.innerHTML = `
  <div class="board">
    <header class="topbar">
      <button class="btn-ghost brand" type="button" data-title aria-label="Title screen">CODE<span>IT!</span><small class="brand-by mono">by Web Development Services</small></button>
      <div class="topbar-right">
        ${rankBar(p.xp)}
        <button class="btn-ghost" type="button" data-ach>Achievements <span class="mono muted">${p.achievements.length}/${ACHIEVEMENTS.length}</span></button>
        <button class="btn-ghost" type="button" data-settings>Settings</button>
      </div>
    </header>
    <main class="board-main">
      <div class="board-head">
        <div>
          <p class="kicker mono">JOB BOARD · ${completedCount}/${levels.length} SHIPPED</p>
          <h1>${completedCount === 0 ? 'Your first client is waiting.' : completedCount === levels.length ? 'Every job shipped. Legend.' : 'Pick your next job.'}</h1>
        </div>
        <div class="board-dex">
          <div class="avatar">${portrait('dex', completedCount ? 'smug' : 'neutral')}</div>
          <p class="bubble">${completedCount === 0 ? 'I’m Dex, senior dev. Start with Chef Rizzo. And press RUN a lot. It’s free.' : nextUp ? `Next up: ${esc(nextUp.client.name)}. Good luck. You won’t need it. Probably.` : 'You did all of them. I’m... actually impressed.'}</p>
        </div>
      </div>
      <ol class="tickets">
        ${levels
          .map((l, i) => {
            const rec = PlayerStore.level(l.id);
            const unlocked = LevelRepository.isUnlocked(l.id, done);
            const isNext = nextUp?.id === l.id;
            const status = rec.completed ? 'shipped' : unlocked ? (rec.draft ? 'in progress' : 'open') : 'locked';
            return `<li style="--i:${i}">
              <button class="ticket-card cat-${l.category}${isNext ? ' next' : ''}${rec.completed ? ' done' : ''}" type="button" data-level="${l.id}" ${unlocked ? '' : 'disabled aria-disabled="true"'}
                aria-label="Job ${l.number}: ${esc(l.title)}. ${status}.${unlocked ? '' : ` Finish job ${l.number - 1} to unlock.`}">
                <span class="tc-top"><span class="tc-no mono">#${String(l.number).padStart(2, '0')}</span><span class="tc-cat mono">${CATEGORY[l.category]}</span></span>
                <span class="tc-title">${esc(l.title)}</span>
                <span class="tc-tag">${esc(l.tagline)}</span>
                <span class="tc-foot">
                  <span class="tc-client">${esc(l.client.name)}</span>
                  ${rec.completed ? `<span class="tc-done"><span class="tc-stamp mono" aria-hidden="true">SHIPPED</span>${stars(rec.stars)}</span>` : unlocked ? `<span class="tc-status mono">${isNext ? 'START →' : rec.draft ? 'CONTINUE' : 'OPEN'}</span>` : '<span class="tc-status mono locked">🔒 LOCKED</span>'}
                </span>
              </button>
            </li>`;
          })
          .join('')}
      </ol>
    </main>
    <footer class="site-foot mono">CODE IT! · © ${new Date().getFullYear()} Web Development Services</footer>
  </div>`;

  root.querySelectorAll<HTMLButtonElement>('[data-level]').forEach((b) =>
    b.addEventListener('click', () => {
      AudioManager.play('button');
      h.onPlay(LevelRepository.get(b.dataset.level!)!);
    }),
  );
  root.querySelector('[data-settings]')!.addEventListener('click', h.onSettings);
  root.querySelector('[data-ach]')!.addEventListener('click', h.onAchievements);
  root.querySelector('[data-title]')!.addEventListener('click', h.onTitle);
  requestAnimationFrame(() => (root.querySelector<HTMLElement>('.ticket-card.next') ?? root.querySelector<HTMLElement>('.ticket-card:not([disabled])'))?.focus());
  return () => {};
}
