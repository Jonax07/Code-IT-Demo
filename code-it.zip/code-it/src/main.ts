import '@fontsource/bricolage-grotesque/500.css';
import '@fontsource/bricolage-grotesque/700.css';
import '@fontsource/bricolage-grotesque/800.css';
import '@fontsource/jetbrains-mono/400.css';
import '@fontsource/jetbrains-mono/700.css';
import './styles/main.css';

import { Achievements } from './achievements/achievements';
import { FX } from './animation/fx';
import { ApiClient } from './api/client';
import { AudioManager } from './audio/AudioManager';
import { Diagnostics } from './diagnostics/diagnostics';
import { LevelRepository } from './levels/repository';
import type { Level } from './levels/types';
import { PlayerStore, type Settings } from './player/store';
import { showAchievementsDialog, showSettingsDialog } from './ui/dialogs';
import { esc } from './ui/dom';
import { mountBoard } from './ui/screens/board';
import { mountTitle } from './ui/screens/title';
import { caption, toast } from './ui/toast';

const root = document.getElementById('app')!;
let unmount: () => void = () => {};

function applySettings(s: Settings): void {
  document.documentElement.dataset.theme = s.theme;
  FX.setReducedMotion(s.reducedMotion);
  AudioManager.configure({
    master: s.masterVolume,
    effects: s.effectsVolume,
    music: s.musicVolume,
    effectsOn: s.soundEffects,
    musicOn: s.music,
    captions: s.captions,
  });
}

type Route = { screen: 'title' } | { screen: 'board' } | { screen: 'level'; id: string };

function parseRoute(): Route {
  const hash = location.hash.replace(/^#\/?/, '');
  if (hash.startsWith('job/')) {
    const id = hash.slice(4);
    const done = (x: string) => PlayerStore.level(x).completed;
    if (LevelRepository.get(id) && LevelRepository.isUnlocked(id, done)) return { screen: 'level', id };
    return { screen: 'board' };
  }
  if (hash === 'jobs') return { screen: 'board' };
  return { screen: 'title' };
}

function go(hash: string): void {
  if (location.hash === hash) render();
  else location.hash = hash;
}

const openSettings = () =>
  showSettingsDialog(applySettings, () => {
    PlayerStore.reset();
    toast('Progress reset. Fresh start!');
    go('#/');
  });

let renderToken = 0;
const loadGame = () => import('./ui/screens/game');

function render(): void {
  renderToken++;
  unmount();
  window.scrollTo(0, 0);
  const route = parseRoute();
  document.body.dataset.screen = route.screen;
  if (route.screen === 'title') {
    document.title = 'CODE IT! Build it. Break it. Fix it.';
    unmount = mountTitle(root, { onStart: () => go('#/jobs'), onSettings: openSettings });
  } else if (route.screen === 'board') {
    document.title = 'Job board · CODE IT!';
    unmount = mountBoard(root, {
      onPlay: (l) => go(`#/job/${l.id}`),
      onSettings: openSettings,
      onAchievements: showAchievementsDialog,
      onTitle: () => go('#/'),
    });
  } else {
    const level = LevelRepository.get(route.id)!;
    document.title = `#${level.number} ${level.title} · CODE IT!`;
    const token = ++renderToken;
    root.innerHTML = '<div class="loading mono" role="status">Booting editor…</div>';
    unmount = () => {};
    // The editor is the heaviest chunk; title and job board never wait for it.
    void loadGame().then(({ mountGame }) => {
      if (token !== renderToken) return; // Player navigated away meanwhile.
      unmount = mountGame(root, level, {
        onExit: () => go('#/jobs'),
        onNext: (l: Level) => go(`#/job/${l.id}`),
        onSettings: openSettings,
      });
    });
  }
}

applySettings(PlayerStore.get().settings);
AudioManager.onCaption(caption);
Achievements.onUnlock((a) => {
  if (Achievements.quiet) return;
  AudioManager.play('achievement');
  toast(`<span class="ach-icon" aria-hidden="true">${a.icon}</span><span><small class="mono">ACHIEVEMENT UNLOCKED</small><strong>${esc(a.title)}</strong></span>`, { kind: 'achievement', ms: 4000 });
});
// Unlock audio on the first interaction anywhere (browser autoplay rules).
window.addEventListener('pointerdown', () => AudioManager.unlock(), { once: true });
window.addEventListener('keydown', () => AudioManager.unlock(), { once: true });
window.addEventListener('hashchange', render);
Diagnostics.init();
render();

// Non-blocking background work after first paint.
const idle = window.requestIdleCallback ?? ((fn: () => void) => window.setTimeout(fn, 200));
idle(async () => {
  void loadGame(); // Warm the editor chunk while the player reads the title screen.
  if (await ApiClient.detect()) {
    const p = PlayerStore.get();
    ApiClient.enqueue('POST', '/api/player', { playerId: p.id, name: p.name }, `player:${p.id}`);
    void LevelRepository.refresh();
  }
  void ApiClient.flush();
});
