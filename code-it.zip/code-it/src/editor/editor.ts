/**
 * Multi-file code editor built on CodeMirror 6. One EditorView per language tab so
 * each file keeps its own undo history and scroll position.
 */
import { css } from '@codemirror/lang-css';
import { html } from '@codemirror/lang-html';
import { javascript } from '@codemirror/lang-javascript';
import { HighlightStyle, syntaxHighlighting, indentUnit } from '@codemirror/language';
import { lintGutter, setDiagnostics, type Diagnostic } from '@codemirror/lint';
import { EditorState } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { indentWithTab, undo, redo } from '@codemirror/commands';
import { tags as t } from '@lezer/highlight';
import { basicSetup } from 'codemirror';
import type { Lang } from '../levels/types';
import type { LintIssue } from '../validation/lint';

const highlight = HighlightStyle.define([
  { tag: [t.tagName, t.keyword, t.controlKeyword, t.moduleKeyword], color: 'var(--syn-keyword)' },
  { tag: [t.attributeName, t.propertyName], color: 'var(--syn-prop)' },
  { tag: [t.string, t.attributeValue, t.special(t.string)], color: 'var(--syn-string)' },
  { tag: [t.number, t.unit, t.bool, t.atom, t.color], color: 'var(--syn-number)' },
  { tag: [t.comment, t.lineComment, t.blockComment], color: 'var(--syn-comment)', fontStyle: 'italic' },
  { tag: [t.function(t.variableName), t.function(t.propertyName)], color: 'var(--syn-fn)' },
  { tag: [t.className, t.labelName, t.typeName], color: 'var(--syn-class)' },
  { tag: [t.angleBracket, t.bracket, t.punctuation, t.separator], color: 'var(--syn-punct)' },
  { tag: [t.variableName, t.definition(t.variableName)], color: 'var(--syn-var)' },
  { tag: t.operator, color: 'var(--syn-op)' },
]);

const theme = EditorView.theme({
  '&': { height: '100%', fontSize: 'var(--code-size)', backgroundColor: 'var(--editor-bg)', color: 'var(--editor-fg)' },
  '.cm-scroller': { fontFamily: '"JetBrains Mono", ui-monospace, monospace', lineHeight: '1.6' },
  '.cm-content': { caretColor: 'var(--accent)', padding: '12px 0' },
  '.cm-gutters': { backgroundColor: 'var(--editor-bg)', color: 'var(--editor-gutter)', border: 'none' },
  '.cm-activeLine': { backgroundColor: 'var(--editor-active)' },
  '.cm-activeLineGutter': { backgroundColor: 'var(--editor-active)', color: 'var(--editor-fg)' },
  '.cm-selectionBackground, &.cm-focused .cm-selectionBackground, ::selection': { backgroundColor: 'var(--editor-selection) !important' },
  '.cm-cursor': { borderLeftColor: 'var(--accent)', borderLeftWidth: '2px' },
  '&.cm-focused': { outline: 'none' },
  '.cm-matchingBracket': { backgroundColor: 'var(--editor-match)', outline: 'none' },
  '.cm-tooltip': { backgroundColor: 'var(--panel-2)', color: 'var(--fg)', border: '1px solid var(--line)', borderRadius: '6px' },
  '.cm-tooltip-lint': { fontFamily: 'var(--font-ui)' },
  '.cm-diagnostic-error': { borderLeftColor: 'var(--bad)' },
  '.cm-diagnostic-warning': { borderLeftColor: 'var(--warn)' },
  '.cm-lintRange-error': { backgroundImage: 'none', textDecoration: 'underline wavy var(--bad)', textUnderlineOffset: '3px' },
  '.cm-lintRange-warning': { backgroundImage: 'none', textDecoration: 'underline wavy var(--warn)', textUnderlineOffset: '3px' },
  '.cm-panels': { backgroundColor: 'var(--panel-2)', color: 'var(--fg)' },
});

const LANG_EXT = { html: () => html({ autoCloseTags: true }), css: () => css(), js: () => javascript() };

export interface EditorOptions {
  onChange: (lang: Lang, value: string) => void;
  onRun: () => void;
}

export class CodeEditor {
  private views = new Map<Lang, EditorView>();
  private active: Lang;

  constructor(private host: HTMLElement, tabs: Lang[], initial: Record<Lang, string>, private opts: EditorOptions) {
    this.active = tabs[0];
    for (const lang of tabs) {
      const wrap = document.createElement('div');
      wrap.className = 'editor-pane';
      wrap.id = `editor-pane-${lang}`;
      wrap.setAttribute('role', 'tabpanel');
      wrap.setAttribute('aria-labelledby', `tab-${lang}`);
      wrap.hidden = lang !== this.active;
      host.appendChild(wrap);
      const view = new EditorView({
        parent: wrap,
        state: EditorState.create({
          doc: initial[lang],
          extensions: [
            basicSetup,
            keymap.of([
              { key: 'Mod-Enter', run: () => (this.opts.onRun(), true) },
              { key: 'Mod-s', run: () => (this.opts.onRun(), true), preventDefault: true },
              indentWithTab,
            ]),
            indentUnit.of('  '),
            LANG_EXT[lang](),
            syntaxHighlighting(highlight),
            lintGutter(),
            theme,
            EditorView.lineWrapping,
            EditorView.contentAttributes.of({ 'aria-label': `${lang.toUpperCase()} code editor`, spellcheck: 'false', autocapitalize: 'off', autocorrect: 'off' }),
            EditorView.updateListener.of((u) => {
              if (u.docChanged) this.opts.onChange(lang, u.state.doc.toString());
            }),
          ],
        }),
      });
      this.views.set(lang, view);
    }
  }

  get activeLang(): Lang {
    return this.active;
  }

  show(lang: Lang): void {
    if (!this.views.has(lang)) return;
    this.active = lang;
    for (const [l, v] of this.views) (v.dom.parentElement as HTMLElement).hidden = l !== lang;
    this.views.get(lang)!.requestMeasure();
  }

  focus(): void {
    this.views.get(this.active)?.focus();
  }

  value(lang: Lang): string {
    return this.views.get(lang)?.state.doc.toString() ?? '';
  }

  setValue(lang: Lang, text: string): void {
    const v = this.views.get(lang);
    if (!v) return;
    v.dispatch({ changes: { from: 0, to: v.state.doc.length, insert: text } });
  }

  undo(): void {
    const v = this.views.get(this.active);
    if (v) undo(v);
  }

  redo(): void {
    const v = this.views.get(this.active);
    if (v) redo(v);
  }

  /** Show errors/warnings. Issues carry 1-based line numbers. */
  setIssues(lang: Lang, issues: LintIssue[]): void {
    const v = this.views.get(lang);
    if (!v) return;
    const doc = v.state.doc;
    const diags: Diagnostic[] = issues
      .filter((i) => i.line >= 1 && i.line <= doc.lines)
      .map((i) => {
        const line = doc.line(i.line);
        const text = line.text;
        const start = line.from + (text.length - text.trimStart().length);
        return { from: start, to: Math.max(start + 1, line.to), severity: i.severity, message: i.message, source: lang.toUpperCase() };
      });
    v.dispatch(setDiagnostics(v.state, diags));
  }

  goToLine(lang: Lang, lineNo: number): void {
    this.show(lang);
    const v = this.views.get(lang);
    if (!v) return;
    const line = v.state.doc.line(Math.min(Math.max(1, lineNo), v.state.doc.lines));
    v.dispatch({ selection: { anchor: line.from }, scrollIntoView: true });
    v.focus();
  }

  /** Prettier is ~300KB, so it's loaded only when the player first presses Format. */
  async format(): Promise<boolean> {
    const lang = this.active;
    const code = this.value(lang);
    const [prettier, parserPlugins] = await Promise.all([
      import('prettier/standalone'),
      lang === 'js'
        ? Promise.all([import('prettier/plugins/babel'), import('prettier/plugins/estree')])
        : lang === 'css'
          ? Promise.all([import('prettier/plugins/postcss')])
          : Promise.all([import('prettier/plugins/html'), import('prettier/plugins/postcss'), import('prettier/plugins/babel'), import('prettier/plugins/estree')]),
    ]);
    try {
      const out = await prettier.format(code, {
        parser: lang === 'js' ? 'babel' : lang === 'css' ? 'css' : 'html',
        plugins: parserPlugins as never,
        printWidth: 70,
        tabWidth: 2,
        htmlWhitespaceSensitivity: 'ignore',
      });
      if (out !== code) this.setValue(lang, out.trimEnd() + '\n');
      return true;
    } catch {
      return false; // Syntax errors: nothing to format. The linter already shows why.
    }
  }

  destroy(): void {
    for (const v of this.views.values()) v.destroy();
    this.views.clear();
    this.host.innerHTML = '';
  }
}
