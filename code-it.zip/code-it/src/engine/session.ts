/**
 * One play-through of one level. Owns the gameplay rules (phases, attempts, hints,
 * scoring) and knows nothing about the DOM.
 */
import type { Level, Requirement } from '../levels/types';
import type { PlayerCode } from '../sandbox/sandbox';
import { scoreLevel, type XpLine } from '../progression/scoring';
import { validate, type ValidationReport } from '../validation/engine';

export type RunOutcome =
  | { kind: 'fail'; report: ValidationReport }
  | { kind: 'event'; report: ValidationReport }
  | { kind: 'complete'; report: ValidationReport; xp: { lines: XpLine[]; total: number; stars: number }; durationMs: number }
  | { kind: 'cancelled' };

export class LevelSession {
  phase: 'base' | 'event' = 'base';
  runs = 0;
  failedRuns = 0;
  hintsRevealed = 0;
  sawErrors = false;
  completed = false;
  lastReport: ValidationReport | null = null;
  readonly startedAt = performance.now();
  private inflight: AbortController | null = null;

  constructor(readonly level: Level, private firstClear: boolean) {}

  requirements(): Requirement[] {
    return this.phase === 'event' && this.level.event
      ? [...this.level.requirements, ...this.level.event.requirements]
      : this.level.requirements;
  }

  /** Newer runs cancel older ones, so only the latest result is ever shown. */
  async run(code: PlayerCode): Promise<RunOutcome> {
    this.inflight?.abort();
    const ctrl = new AbortController();
    this.inflight = ctrl;
    this.runs++;
    const report = await validate(code, this.requirements(), ctrl.signal);
    if (ctrl.signal.aborted) return { kind: 'cancelled' };
    this.inflight = null;
    this.lastReport = report;
    const hadErrors = report.runtimeErrors.some((e) => e.kind === 'js') || report.timedOut;
    if (hadErrors) this.sawErrors = true;

    if (!report.passed) {
      this.failedRuns++;
      return { kind: 'fail', report };
    }
    if (this.level.event && this.phase === 'base') {
      this.phase = 'event';
      return { kind: 'event', report };
    }
    this.completed = true;
    const durationMs = performance.now() - this.startedAt;
    const xp = scoreLevel({
      runs: this.runs,
      failedRuns: this.failedRuns,
      hintsUsed: this.hintsRevealed,
      sawErrors: this.sawErrors,
      durationMs,
      parTimeSec: this.level.parTimeSec,
      bonusPassed: {
        accessibility: report.bonus.some((b) => b.bonus === 'accessibility' && b.pass),
        performance: report.timings.executionMs < 50 && !hadErrors,
        style: report.bonus.some((b) => b.bonus === 'style' && b.pass),
      },
      isDebug: !!this.level.isDebug,
      firstClear: this.firstClear,
    });
    return { kind: 'complete', report, xp, durationMs };
  }

  revealHint(): number | null {
    if (this.hintsRevealed >= this.level.hints.length) return null;
    return this.hintsRevealed++;
  }
}
