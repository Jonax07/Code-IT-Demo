/**
 * Inserts a budget check at the top of every braced loop body so an accidental
 * `while (true) {}` throws a friendly error instead of freezing the tab.
 *
 * This is a small scanner, not a parser: it skips strings, template literals,
 * comments and regex literals well enough for beginner code. Braceless loops are
 * left alone (the sandbox timeout still catches them).
 */
const GUARD = '__codeitLoop();';

export function loopProtect(src: string): string {
  let out = '';
  let i = 0;
  const n = src.length;
  let lastSignificant = '';

  const isIdent = (c: string) => /[A-Za-z0-9_$]/.test(c);

  while (i < n) {
    const c = src[i];
    const next = src[i + 1];

    // Comments
    if (c === '/' && next === '/') {
      const end = src.indexOf('\n', i);
      const stop = end === -1 ? n : end;
      out += src.slice(i, stop);
      i = stop;
      continue;
    }
    if (c === '/' && next === '*') {
      const end = src.indexOf('*/', i + 2);
      const stop = end === -1 ? n : end + 2;
      out += src.slice(i, stop);
      i = stop;
      continue;
    }
    // Strings and templates
    if (c === '"' || c === "'" || c === '`') {
      let j = i + 1;
      while (j < n && src[j] !== c) {
        if (src[j] === '\\') j++;
        if (src[j] === '\n' && c !== '`') break;
        j++;
      }
      out += src.slice(i, j + 1);
      i = j + 1;
      lastSignificant = c;
      continue;
    }
    // Regex literal (heuristic: '/' where an expression can start)
    if (c === '/' && (lastSignificant === '' || /[(,=:[!&|?{};+\-*%<>~^]/.test(lastSignificant))) {
      let j = i + 1;
      let inClass = false;
      while (j < n && src[j] !== '\n') {
        if (src[j] === '\\') { j += 2; continue; }
        if (src[j] === '[') inClass = true;
        else if (src[j] === ']') inClass = false;
        else if (src[j] === '/' && !inClass) break;
        j++;
      }
      if (src[j] === '/') {
        j++;
        while (j < n && /[a-z]/i.test(src[j])) j++;
        out += src.slice(i, j);
        i = j;
        lastSignificant = '/';
        continue;
      }
    }

    // Keywords: for / while / do
    if (isIdent(c) && (i === 0 || !isIdent(src[i - 1]))) {
      let j = i;
      while (j < n && isIdent(src[j])) j++;
      const word = src.slice(i, j);
      if (word === 'for' || word === 'while') {
        // Find the balanced (...) header, then an immediate '{'.
        let k = j;
        while (k < n && /\s/.test(src[k])) k++;
        if (src[k] === '(') {
          let depth = 0;
          let m = k;
          for (; m < n; m++) {
            const ch = src[m];
            if (ch === '"' || ch === "'" || ch === '`') {
              m++;
              while (m < n && src[m] !== ch) { if (src[m] === '\\') m++; m++; }
              continue;
            }
            if (ch === '(') depth++;
            else if (ch === ')') { depth--; if (depth === 0) break; }
          }
          let b = m + 1;
          while (b < n && /\s/.test(src[b])) b++;
          if (src[b] === '{') {
            out += src.slice(i, b + 1) + GUARD;
            i = b + 1;
            lastSignificant = '{';
            continue;
          }
        }
      } else if (word === 'do') {
        let b = j;
        while (b < n && /\s/.test(src[b])) b++;
        if (src[b] === '{') {
          out += src.slice(i, b + 1) + GUARD;
          i = b + 1;
          lastSignificant = '{';
          continue;
        }
      }
      out += word;
      i = j;
      lastSignificant = word[word.length - 1];
      continue;
    }

    out += c;
    if (!/\s/.test(c)) lastSignificant = c;
    i++;
  }
  return out;
}
