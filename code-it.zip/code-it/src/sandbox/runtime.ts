/**
 * Code that runs INSIDE the sandboxed iframe, before any player code.
 *
 * It is serialized with Function#toString, so it must be fully self-contained:
 * no imports, no references to module scope, ES2020 syntax only.
 *
 * Responsibilities:
 *  - capture console output, runtime errors, and alert() calls
 *  - evaluate DOM rules after the page has loaded (validation frames only)
 *  - report back to the game through postMessage, tagged with a secret token that
 *    player code cannot read (the runtime removes its own <script> node).
 */
export interface RuntimeConfig {
  token: string;
  runId: string;
  mode: 'preview' | 'validate';
  jsLineOffset: number;
  rules: { id: string; rule: unknown }[];
  loopBudgetMs: number;
}

export function sandboxRuntime(cfg: RuntimeConfig): void {
  const w = window as any;
  const doc = document;
  const parentWin = window.parent;
  const post = parentWin.postMessage.bind(parentWin);
  // Capture originals before player code can monkey-patch them.
  const qsa = Document.prototype.querySelectorAll;
  const elQsa = Element.prototype.querySelectorAll;
  const gcs = window.getComputedStyle.bind(window);
  const rect = Element.prototype.getBoundingClientRect;
  const now = performance.now.bind(performance);
  const setT = window.setTimeout.bind(window);
  const toStr = (v: any): string => {
    try {
      if (typeof v === 'string') return v;
      if (v instanceof Error) return v.name + ': ' + v.message;
      if (v instanceof Element) return '<' + v.tagName.toLowerCase() + '>';
      const s = JSON.stringify(v);
      return s === undefined ? String(v) : s;
    } catch (_e) {
      return String(v);
    }
  };
  const send = (type: string, payload: any) => {
    try {
      post({ __codeit: true, token: cfg.token, runId: cfg.runId, type: type, payload: payload }, '*');
    } catch (_e) {
      /* parent gone */
    }
  };

  const script = doc.currentScript;
  if (script && script.parentNode) script.parentNode.removeChild(script);

  const errors: { message: string; line: number | null; kind: string }[] = [];
  const logs: { level: string; text: string }[] = [];
  const startedAt = now();

  // Loop protection hook used by instrumented player JS (see loopProtect.ts).
  let loopStart = 0;
  w.__codeitLoop = function () {
    const t = now();
    if (!loopStart) loopStart = t;
    if (t - loopStart > cfg.loopBudgetMs) {
      throw new RangeError('This loop ran for too long and was stopped (infinite loop?)');
    }
  };
  // Reset budget each task so long-lived pages with short loops are fine.
  setInterval(function () {
    loopStart = 0;
  }, 50);

  (['log', 'info', 'warn', 'error'] as const).forEach(function (level) {
    const orig = (console as any)[level];
    (console as any)[level] = function () {
      const text = Array.prototype.map.call(arguments, toStr).join(' ');
      logs.push({ level: level, text: text });
      send('console', { level: level, text: text });
      try {
        orig.apply(console, arguments as any);
      } catch (_e) {
        /* ignore */
      }
    };
  });

  const toastBox = () => {
    let box = doc.getElementById('__codeit_toasts');
    if (!box) {
      box = doc.createElement('div');
      box.id = '__codeit_toasts';
      box.setAttribute(
        'style',
        'position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:2147483647;display:flex;flex-direction:column;gap:6px;font:600 14px/1.3 system-ui,sans-serif;pointer-events:none',
      );
      (doc.body || doc.documentElement).appendChild(box);
    }
    return box;
  };
  // alert() is blocked in the sandbox; show it inside the preview instead.
  w.alert = function (msg: any) {
    const text = toStr(msg);
    logs.push({ level: 'alert', text: text });
    send('console', { level: 'alert', text: text });
    if (cfg.mode !== 'preview') return;
    const t = doc.createElement('div');
    t.textContent = '💬 ' + text;
    t.setAttribute('style', 'background:#111;color:#fff;padding:10px 14px;border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,.35);max-width:80vw');
    toastBox().appendChild(t);
    setT(function () {
      t.remove();
    }, 2600);
  };
  w.confirm = function () {
    return true;
  };
  w.prompt = function () {
    return '';
  };

  // Links and forms would navigate the sandbox away from the player's page.
  doc.addEventListener('click', function (ev) {
    const a = ev.target instanceof Element ? ev.target.closest('a[href]') : null;
    if (!a) return;
    const href = a.getAttribute('href') || '';
    if (href.charAt(0) === '#') return;
    ev.preventDefault();
    if (cfg.mode === 'preview') w.alert('Link clicked: ' + href + ' (links stay put in the preview)');
  });
  doc.addEventListener('submit', function (ev) {
    ev.preventDefault();
  });

  const onError = function (message: string, line: number | null, kind: string) {
    // Scripts in srcdoc report document line numbers; convert to the JS tab.
    const mapped = line != null && kind === 'js' ? line - cfg.jsLineOffset : line;
    const e = { message: message, line: mapped != null && mapped > 0 ? mapped : null, kind: kind };
    errors.push(e);
    send('error', e);
  };
  window.addEventListener('error', function (ev: ErrorEvent) {
    if (ev.target && ev.target !== window && (ev.target as Element).tagName) {
      const t = ev.target as HTMLImageElement;
      onError('Could not load ' + t.tagName.toLowerCase() + ': ' + (t.getAttribute('src') || ''), null, 'resource');
      return;
    }
    onError(ev.message || 'Unknown error', ev.lineno || null, 'js');
  }, true);
  window.addEventListener('unhandledrejection', function (ev: PromiseRejectionEvent) {
    onError('Unhandled promise rejection: ' + toStr(ev.reason), null, 'js');
  });

  // ---------------------------------------------------------------- validation
  const $all = (sel: string): Element[] => {
    try {
      return Array.prototype.slice.call(qsa.call(doc, sel));
    } catch (_e) {
      return [];
    }
  };
  const visible = (el: Element) => {
    const r = rect.call(el);
    const cs = gcs(el);
    return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
  };
  const parseColor = (c: string): number[] | null => {
    const m = c.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const parts = m[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
    return parts.length >= 3 ? parts : null;
  };
  const hsl = (rgb: number[]) => {
    const r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2;
    let h = 0, s = 0;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return { h: h, s: s, l: l };
  };
  const norm = (v: string) => v.replace(/\s+/g, ' ').trim().toLowerCase();
  const checkStyle = (val: string, chk: any): boolean => {
    const v = norm(val);
    switch (chk.op) {
      case 'equals': return v === norm(chk.value);
      case 'oneOf': return chk.values.some((x: string) => norm(x) === v);
      case 'not': return v !== norm(chk.value);
      case 'notIn': return !chk.values.some((x: string) => norm(x) === v);
      case 'contains': return v.indexOf(norm(chk.value)) !== -1;
      case 'notContains': return v.indexOf(norm(chk.value)) === -1;
      case 'minPx': return parseFloat(v) >= chk.value;
      case 'hue': {
        const rgb = parseColor(v);
        if (!rgb || (rgb.length > 3 && rgb[3] === 0)) return false;
        const c = hsl(rgb);
        return c.h >= chk.min && c.h <= chk.max && c.s >= (chk.minSat == null ? 0.3 : chk.minSat) && c.l > 0.12 && c.l < 0.9;
      }
    }
    return false;
  };
  const describe = (val: string) => (val.length > 60 ? val.slice(0, 57) + '...' : val);

  type Result = { id: string; pass: boolean; detail?: string };
  const evalExpectation = (x: any): { pass: boolean; detail?: string } => {
    const els = $all(x.selector);
    if ('count' in x) return { pass: els.length === x.count, detail: 'found ' + els.length };
    if ('minCount' in x) return { pass: els.length >= x.minCount, detail: 'found ' + els.length };
    if (!els.length) return { pass: false, detail: 'nothing matches ' + x.selector };
    const el = els[0];
    if ('textContains' in x) {
      const txt = (el.textContent || '').toLowerCase();
      return { pass: txt.indexOf(x.textContains.toLowerCase()) !== -1, detail: 'text is "' + describe((el.textContent || '').trim()) + '"' };
    }
    if ('textNotContains' in x) {
      const txt = (el.textContent || '').toLowerCase();
      return { pass: txt.indexOf(x.textNotContains.toLowerCase()) === -1, detail: 'text is "' + describe((el.textContent || '').trim()) + '"' };
    }
    if ('hasClass' in x) return { pass: el.classList.contains(x.hasClass), detail: 'classes: ' + (el.className || '(none)') };
    if ('style' in x) {
      const val = gcs(el).getPropertyValue(x.style);
      return { pass: checkStyle(val, x.check), detail: x.style + ' is ' + describe(val) };
    }
    return { pass: false };
  };

  const runInteraction = (rule: any): Promise<{ pass: boolean; detail?: string }> => {
    return new Promise(function (resolve) {
      const steps = rule.steps.slice();
      const next = () => {
        const s = steps.shift();
        if (!s) {
          // Give event handlers and microtasks a moment to update the DOM.
          setT(function () {
            for (let i = 0; i < rule.expect.length; i++) {
              const r = evalExpectation(rule.expect[i]);
              if (!r.pass) return resolve(r);
            }
            resolve({ pass: true });
          }, 30);
          return;
        }
        if (s.do === 'wait') return void setT(next, s.ms);
        const el = $all(s.selector)[0] as HTMLElement | undefined;
        if (!el) return resolve({ pass: false, detail: 'could not find ' + s.selector + ' to ' + s.do });
        try {
          if (s.do === 'click') el.click();
          if (s.do === 'type') {
            (el as HTMLInputElement).value = s.value;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          }
        } catch (_e) {
          /* errors are captured by the error listener */
        }
        setT(next, 10);
      };
      next();
    });
  };

  const evalRule = (id: string, rule: any): Promise<Result> | Result => {
    switch (rule.type) {
      case 'element': {
        const n = $all(rule.selector).length;
        const min = rule.min || 1;
        return { id: id, pass: n >= min, detail: 'found ' + n + ' of ' + min };
      }
      case 'text': {
        const els = $all(rule.selector);
        if (!els.length) return { id: id, pass: false, detail: 'no ' + rule.selector + ' found' };
        const ok = els.some(function (el) {
          const t = (el.textContent || '').trim();
          if (rule.contains && t.toLowerCase().indexOf(rule.contains.toLowerCase()) === -1) return false;
          if (rule.minLength && t.length < rule.minLength) return false;
          return true;
        });
        return { id: id, pass: ok, detail: 'text is "' + describe((els[0].textContent || '').trim()) + '"' };
      }
      case 'attr': {
        const els = $all(rule.selector);
        if (!els.length) return { id: id, pass: false, detail: 'no ' + rule.selector + ' found' };
        const ok = els.every(function (el) {
          const v = el.getAttribute(rule.attr);
          if (v == null) return false;
          if (rule.nonEmpty && !v.trim()) return false;
          if (rule.contains && v.toLowerCase().indexOf(rule.contains.toLowerCase()) === -1) return false;
          return true;
        });
        return { id: id, pass: ok };
      }
      case 'style': {
        const els = $all(rule.selector);
        if (!els.length) return { id: id, pass: false, detail: 'no ' + rule.selector + ' found' };
        const val = gcs(els[0]).getPropertyValue(rule.prop);
        return { id: id, pass: checkStyle(val, rule.check), detail: rule.prop + ' is ' + describe(val || '(empty)') };
      }
      case 'sameRow':
      case 'stacked': {
        const els = $all(rule.selector).filter(visible);
        if (els.length < rule.min) return { id: id, pass: false, detail: 'found ' + els.length + ' visible, need ' + rule.min };
        const rs = els.map(function (e) { return rect.call(e); });
        if (rule.type === 'sameRow') {
          const top = rs[0].top;
          const ok = rs.every(function (r) { return Math.abs(r.top - top) < 8; });
          return { id: id, pass: ok, detail: ok ? 'in one row' : 'they wrap onto different rows' };
        }
        let ok = true;
        for (let i = 1; i < rs.length; i++) if (rs[i].top < rs[i - 1].bottom - 4) ok = false;
        return { id: id, pass: ok, detail: ok ? 'stacked' : 'side by side' };
      }
      case 'noOverflow': {
        const sw = doc.documentElement.scrollWidth;
        const iw = window.innerWidth;
        return { id: id, pass: sw <= iw + 1, detail: 'page is ' + sw + 'px wide on a ' + iw + 'px screen' };
      }
      case 'noRuntimeErrors':
        return {
          id: id,
          pass: errors.filter(function (e) { return e.kind === 'js'; }).length === 0,
          detail: errors.length ? errors[0].message : undefined,
        };
      case 'interact':
        return runInteraction(rule).then(function (r) { return { id: id, pass: r.pass, detail: r.detail }; });
    }
    return { id: id, pass: false, detail: 'unknown rule' };
  };

  const finish = () => {
    const execMs = now() - startedAt;
    if (cfg.mode === 'preview') {
      send('ready', { executionTimeMs: execMs, errors: errors, logs: logs.length });
      return;
    }
    const t0 = now();
    const results: Result[] = [];
    // Evaluate sequentially: interaction rules mutate the DOM.
    const queue = cfg.rules.slice();
    const step = () => {
      const item = queue.shift();
      if (!item) {
        send('validated', { results: results, errors: errors, executionTimeMs: execMs, validationTimeMs: now() - t0 });
        return;
      }
      let out: Promise<Result> | Result;
      try {
        out = evalRule(item.id, item.rule);
      } catch (e: any) {
        out = { id: item.id, pass: false, detail: String(e && e.message) };
      }
      Promise.resolve(out).then(function (r) {
        results.push(r);
        step();
      });
    };
    step();
  };

  const unmatched = () => {
    // Report CSS selectors that match nothing: a classic "why doesn't my CSS work" bug.
    const out: string[] = [];
    try {
      const sheets = doc.styleSheets;
      for (let i = 0; i < sheets.length; i++) {
        const rules = (sheets[i] as CSSStyleSheet).cssRules;
        for (let j = 0; j < rules.length; j++) {
          const r = rules[j] as CSSStyleRule;
          if (!r.selectorText) continue;
          r.selectorText.split(',').forEach(function (sel) {
            const s = sel.trim();
            if (!s || /:(hover|focus|active|visited|focus-visible|focus-within|checked|disabled|target)|::/.test(s)) return;
            try {
              if (elQsa.call(doc.documentElement, s).length === 0 && s !== 'html' && s !== ':root') out.push(s);
            } catch (_e) {
              /* invalid selector */
            }
          });
        }
      }
    } catch (_e) {
      /* ignore */
    }
    return out;
  };

  const onLoaded = () => {
    setT(function () {
      send('selectors', { unmatched: unmatched() });
      finish();
    }, 40);
  };
  if (doc.readyState === 'complete') onLoaded();
  else window.addEventListener('load', onLoaded);
}
