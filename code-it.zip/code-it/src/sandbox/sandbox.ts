/**
 * The only bridge between the game and player code.
 *
 * Player code runs in <iframe sandbox="allow-scripts"> WITHOUT allow-same-origin, so it
 * gets an opaque origin: it cannot touch the game's DOM, storage, or cookies. A CSP
 * blocks all network access except images/fonts. Messages coming back are accepted
 * only from the frame we created and only with the per-run secret token.
 */
import type { DomRule } from '../levels/types';
import { loopProtect } from './loopProtect';
import { sandboxRuntime, type RuntimeConfig } from './runtime';

export interface PlayerCode {
  html: string;
  css: string;
  js: string;
}

export interface ConsoleEntry {
  level: 'log' | 'info' | 'warn' | 'error' | 'alert';
  text: string;
}

export interface RuntimeError {
  message: string;
  line: number | null;
  kind: 'js' | 'resource';
}

export interface RuleResult {
  id: string;
  pass: boolean;
  detail?: string;
}

export interface ValidationRun {
  results: RuleResult[];
  errors: RuntimeError[];
  executionTimeMs: number;
  validationTimeMs: number;
  timedOut: boolean;
}

const RUNTIME_SRC = `(${sandboxRuntime.toString()})`;
const VALIDATION_TIMEOUT_MS = 2500;

let runCounter = 0;
const randomToken = () => {
  const a = new Uint32Array(4);
  crypto.getRandomValues(a);
  return Array.from(a, (x) => x.toString(36)).join('');
};

/** Escapes a closing script tag so player JS can't break out of its <script>. */
const safeScript = (s: string) => s.replace(/<\/script/gi, '<\\/script');

function extractBody(html: string): { head: string; body: string } {
  // Players may write a full document or just body content. Support both.
  const headMatch = html.match(/<head[^>]*>([\s\S]*?)<\/head>/i);
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)(<\/body>|$)/i);
  if (headMatch || bodyMatch) {
    return { head: headMatch ? headMatch[1] : '', body: bodyMatch ? bodyMatch[1] : html.replace(/<head[^>]*>[\s\S]*?<\/head>/i, '') };
  }
  return { head: '', body: html };
}

export function buildDocument(code: PlayerCode, cfg: RuntimeConfig): string {
  // Resolve against the page URL (not the domain root) so builds served from a sub-path still find assets.
  const assetBase = new URL('sandbox-assets/', location.href.split('#')[0]).href;
  const origin = new URL(assetBase).origin;
  const csp = [
    "default-src 'none'",
    `img-src data: blob: https: ${origin}`,
    `style-src 'unsafe-inline' https://fonts.googleapis.com`,
    `font-src data: https://fonts.gstatic.com ${origin}`,
    "script-src 'unsafe-inline'",
    "media-src data: https:",
  ].join('; ');
  const { head, body } = extractBody(code.html);
  const bodyAttrs = (code.html.match(/<body([^>]*)>/i) || ['', ''])[1];
  const pre = [
    '<!doctype html>',
    '<html><head>',
    '<meta charset="utf-8">',
    `<meta http-equiv="Content-Security-Policy" content="${csp}">`,
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    `<base href="${assetBase}">`,
    `<script>${RUNTIME_SRC}(${JSON.stringify({ ...cfg, jsLineOffset: 0 }).replace(/</g, '\\u003c').replace(/"jsLineOffset":0/, '"jsLineOffset":__OFFSET__')});</script>`,
    '<style>html{font-family:system-ui,-apple-system,"Segoe UI",sans-serif}</style>',
    head,
    `<style>${code.css.replace(/<\/style/gi, '')}</style>`,
    '</head>',
    `<body${bodyAttrs}>`,
    body,
    '<script>',
  ].join('\n');
  // Line number of the first line of player JS within the document.
  const offset = pre.split('\n').length;
  const docStr = pre.replace('__OFFSET__', String(offset)) + '\n' + safeScript(loopProtect(code.js)) + '\n</script>\n</body></html>';
  return docStr;
}

interface Handlers {
  onConsole?: (e: ConsoleEntry) => void;
  onError?: (e: RuntimeError) => void;
  onSelectors?: (unmatched: string[]) => void;
  onReady?: (info: { executionTimeMs: number }) => void;
  onValidated?: (run: Omit<ValidationRun, 'timedOut'>) => void;
}

function makeFrame(width?: number): HTMLIFrameElement {
  const f = document.createElement('iframe');
  f.setAttribute('sandbox', 'allow-scripts');
  f.setAttribute('referrerpolicy', 'no-referrer');
  f.setAttribute('loading', 'eager');
  if (width) {
    f.setAttribute('aria-hidden', 'true');
    f.tabIndex = -1;
    f.style.cssText = `position:fixed;left:-10000px;top:0;width:${width}px;height:800px;border:0;visibility:hidden;pointer-events:none`;
  }
  return f;
}

function listen(frame: HTMLIFrameElement, token: string, runId: string, h: Handlers): () => void {
  const onMsg = (ev: MessageEvent) => {
    if (ev.source !== frame.contentWindow) return;
    const d = ev.data;
    if (!d || d.__codeit !== true || d.token !== token || d.runId !== runId) return;
    switch (d.type) {
      case 'console': h.onConsole?.(d.payload); break;
      case 'error': h.onError?.(d.payload); break;
      case 'selectors': h.onSelectors?.(d.payload.unmatched); break;
      case 'ready': h.onReady?.(d.payload); break;
      case 'validated': h.onValidated?.(d.payload); break;
    }
  };
  window.addEventListener('message', onMsg);
  return () => window.removeEventListener('message', onMsg);
}

/** The visible, live preview. Recreated on each render so old timers and listeners die. */
export class PreviewSandbox {
  private frame: HTMLIFrameElement | null = null;
  private unlisten: (() => void) | null = null;

  constructor(private host: HTMLElement) {}

  render(code: PlayerCode, h: Handlers): void {
    this.dispose();
    const token = randomToken();
    const runId = `p${++runCounter}`;
    const frame = makeFrame();
    frame.title = 'Your website preview';
    frame.className = 'preview-frame';
    this.unlisten = listen(frame, token, runId, h);
    frame.srcdoc = buildDocument(code, { token, runId, mode: 'preview', jsLineOffset: 0, rules: [], loopBudgetMs: 300 });
    this.host.appendChild(frame);
    this.frame = frame;
  }

  dispose(): void {
    this.unlisten?.();
    this.frame?.remove();
    this.frame = null;
    this.unlisten = null;
  }
}

/**
 * Deterministic validation. Rules are grouped per viewport; each interaction rule gets
 * its own fresh frame so clicks in one check can't leak into another. Frames run in parallel.
 */
export async function validateInSandbox(
  code: PlayerCode,
  rules: { id: string; rule: DomRule; viewport?: number }[],
  signal?: AbortSignal,
): Promise<ValidationRun> {
  const groups = new Map<string, { width: number; rules: { id: string; rule: DomRule }[] }>();
  for (const r of rules) {
    const width = r.viewport ?? 1024;
    const key = r.rule.type === 'interact' ? `${width}:${r.id}` : `${width}`;
    if (!groups.has(key)) groups.set(key, { width, rules: [] });
    groups.get(key)!.rules.push({ id: r.id, rule: r.rule });
  }
  if (groups.size === 0) groups.set('1024', { width: 1024, rules: [] });

  const runs = await Promise.all([...groups.values()].map((g) => runValidationFrame(code, g.width, g.rules, signal)));
  const errors: RuntimeError[] = [];
  const seen = new Set<string>();
  for (const r of runs) for (const e of r.errors) {
    const k = `${e.message}:${e.line}`;
    if (!seen.has(k)) { seen.add(k); errors.push(e); }
  }
  return {
    results: runs.flatMap((r) => r.results),
    errors,
    executionTimeMs: Math.max(0, ...runs.map((r) => r.executionTimeMs)),
    validationTimeMs: Math.max(0, ...runs.map((r) => r.validationTimeMs)),
    timedOut: runs.some((r) => r.timedOut),
  };
}

function runValidationFrame(
  code: PlayerCode,
  width: number,
  rules: { id: string; rule: DomRule }[],
  signal?: AbortSignal,
): Promise<ValidationRun> {
  return new Promise((resolve) => {
    const token = randomToken();
    const runId = `v${++runCounter}`;
    const frame = makeFrame(width);
    const errors: RuntimeError[] = [];
    let done = false;
    const finish = (run: ValidationRun) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      unlisten();
      frame.remove();
      signal?.removeEventListener('abort', onAbort);
      resolve(run);
    };
    const timedOut = (): ValidationRun => ({
      results: rules.map((r) => ({ id: r.id, pass: false, detail: 'the page never finished loading' })),
      errors,
      executionTimeMs: VALIDATION_TIMEOUT_MS,
      validationTimeMs: 0,
      timedOut: true,
    });
    const onAbort = () => finish(timedOut());
    const unlisten = listen(frame, token, runId, {
      onError: (e) => errors.push(e),
      onValidated: (run) => finish({ ...run, timedOut: false }),
    });
    const timer = window.setTimeout(() => finish(timedOut()), VALIDATION_TIMEOUT_MS);
    signal?.addEventListener('abort', onAbort);
    frame.srcdoc = buildDocument(code, { token, runId, mode: 'validate', jsLineOffset: 0, rules, loopBudgetMs: 500 });
    document.body.appendChild(frame);
  });
}
