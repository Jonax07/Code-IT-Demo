/**
 * The single place the game talks to a server. UI code never calls fetch().
 *
 * - GETs are cached (TTL) and in-flight requests are de-duplicated.
 * - Every request has a timeout and can be cancelled with an AbortSignal.
 * - Writes that fail (offline, 5xx) go to a persistent queue and are retried later.
 * - With no VITE_API_BASE_URL the client is "offline-only": writes queue locally,
 *   reads throw ApiUnavailable so callers fall back to bundled data.
 */
export class ApiUnavailable extends Error {}

export interface ApiStats {
  requests: number;
  failures: number;
  cacheHits: number;
  deduped: number;
  retries: number;
  queued: number;
  latenciesMs: number[];
}

interface QueuedWrite {
  id: string;
  method: 'POST' | 'PUT' | 'DELETE';
  path: string;
  body: unknown;
  attempts: number;
}

const QUEUE_KEY = 'codeit.syncQueue.v1';
const TIMEOUT_MS = 8000;

class Client {
  /** null = no API (offline-only). '.' = same server that served the game (e.g. the Python server). */
  private baseUrl: string | null = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, '') || null;
  readonly stats: ApiStats = { requests: 0, failures: 0, cacheHits: 0, deduped: 0, retries: 0, queued: 0, latenciesMs: [] };
  private cache = new Map<string, { at: number; data: unknown }>();
  private inflight = new Map<string, Promise<unknown>>();
  private flushing = false;

  get online(): boolean {
    return this.baseUrl !== null;
  }

  /**
   * With no configured URL, check once whether the server that served the game also
   * serves the API. The bundled Python server marks the page with
   * <meta name="codeit-api">, so static hosts stay offline without a probe request.
   */
  async detect(): Promise<boolean> {
    if (this.baseUrl !== null) return true;
    if (!document.querySelector('meta[name="codeit-api"]')) return false;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 1500);
    try {
      const res = await fetch('./api/game/config', { signal: ctrl.signal, headers: { Accept: 'application/json' } });
      const body = res.ok && (res.headers.get('content-type') || '').includes('application/json') ? await res.json() : null;
      if (body && body.game === 'code-it') {
        this.baseUrl = '.';
        this.cache.set('/api/game/config', { at: performance.now(), data: body });
        return true;
      }
    } catch {
      /* no API here: stay offline */
    } finally {
      clearTimeout(timer);
    }
    return false;
  }

  async get<T>(path: string, opts: { ttlMs?: number; signal?: AbortSignal } = {}): Promise<T> {
    if (this.baseUrl === null) throw new ApiUnavailable('No API configured');
    const hit = this.cache.get(path);
    if (hit && opts.ttlMs && performance.now() - hit.at < opts.ttlMs) {
      this.stats.cacheHits++;
      return hit.data as T;
    }
    const pending = this.inflight.get(path);
    if (pending) {
      this.stats.deduped++;
      return pending as Promise<T>;
    }
    const p = this.request<T>('GET', path, undefined, opts.signal)
      .then((data) => {
        this.cache.set(path, { at: performance.now(), data });
        return data;
      })
      .finally(() => this.inflight.delete(path));
    this.inflight.set(path, p);
    return p;
  }

  post<T>(path: string, body: unknown, signal?: AbortSignal): Promise<T> {
    return this.request<T>('POST', path, body, signal);
  }

  put<T>(path: string, body: unknown, signal?: AbortSignal): Promise<T> {
    return this.request<T>('PUT', path, body, signal);
  }

  delete<T>(path: string, signal?: AbortSignal): Promise<T> {
    return this.request<T>('DELETE', path, undefined, signal);
  }

  /** Fire-and-forget write that survives offline periods and page reloads. */
  enqueue(method: QueuedWrite['method'], path: string, body: unknown, id: string): void {
    const q = this.readQueue();
    // Idempotency: an id already queued is replaced, never duplicated.
    const next = q.filter((w) => w.id !== id);
    next.push({ id, method, path, body, attempts: 0 });
    this.writeQueue(next.slice(-500));
    this.stats.queued = next.length;
    void this.flush();
  }

  async flush(): Promise<void> {
    if (this.baseUrl === null || this.flushing || !navigator.onLine) return;
    this.flushing = true;
    try {
      // Re-read storage every round: writes enqueued while a request is in flight must be
      // kept (and sent), not overwritten by a stale copy of the queue.
      for (let w = this.readQueue()[0]; w; w = this.readQueue()[0]) {
        try {
          await this.request(w.method, w.path, w.body, undefined, w.id);
        } catch (e) {
          // A 4xx means the server rejected it; retrying won't help, so drop it.
          if (!(e instanceof HttpError && e.status >= 400 && e.status < 500)) {
            this.writeQueue(this.readQueue().map((x) => (x.id === w!.id ? { ...x, attempts: x.attempts + 1 } : x)));
            this.stats.retries++;
            break;
          }
        }
        const sent = w;
        this.writeQueue(this.readQueue().filter((x) => x.id !== sent.id));
      }
      this.stats.queued = this.readQueue().length;
    } finally {
      this.flushing = false;
    }
  }

  private async request<T>(method: string, path: string, body?: unknown, signal?: AbortSignal, idempotencyKey?: string): Promise<T> {
    if (this.baseUrl === null) throw new ApiUnavailable('No API configured');
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    const onAbort = () => ctrl.abort();
    signal?.addEventListener('abort', onAbort);
    const t0 = performance.now();
    this.stats.requests++;
    try {
      const res = await fetch(this.baseUrl + path, {
        method,
        signal: ctrl.signal,
        credentials: 'include',
        headers: {
          Accept: 'application/json',
          ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
          ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}),
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) throw new HttpError(res.status);
      return (res.status === 204 ? undefined : await res.json()) as T;
    } catch (e) {
      this.stats.failures++;
      throw e;
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
      this.stats.latenciesMs.push(performance.now() - t0);
      if (this.stats.latenciesMs.length > 100) this.stats.latenciesMs.shift();
    }
  }

  private readQueue(): QueuedWrite[] {
    try {
      return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]');
    } catch {
      return [];
    }
  }

  private writeQueue(q: QueuedWrite[]): void {
    try {
      localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
    } catch {
      /* storage full or blocked: drop silently, gameplay must continue */
    }
  }
}

export class HttpError extends Error {
  constructor(readonly status: number) {
    super(`HTTP ${status}`);
  }
}

export const ApiClient = new Client();
if (typeof window !== 'undefined') window.addEventListener('online', () => void ApiClient.flush());
