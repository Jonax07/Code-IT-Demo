/**
 * All game audio goes through AudioManager.play(name). Sounds are synthesized with the
 * Web Audio API at runtime (original, no licensing, zero download). The AudioContext is
 * created lazily on the first user gesture, as browsers require.
 *
 * Every sound has a caption, so sound is never required to understand what happened.
 */
export type SoundName =
  | 'button'
  | 'run'
  | 'success'
  | 'failure'
  | 'error'
  | 'level_complete'
  | 'achievement'
  | 'hint'
  | 'event'
  | 'xp_tick';

export const CAPTIONS: Record<SoundName, string> = {
  button: '',
  run: '[whirr: code running]',
  success: '[triumphant ta-da]',
  failure: '[sad trombone: wah wah]',
  error: '[computer error beep-boop]',
  level_complete: '[fanfare + crowd cheering]',
  achievement: '[sparkly chime]',
  hint: '[lightbulb ding]',
  event: '[phone ringing urgently]',
  xp_tick: '',
};

interface Volumes {
  master: number;
  effects: number;
  music: number;
  effectsOn: boolean;
  musicOn: boolean;
  captions: boolean;
}

type Tone = { f: number; f2?: number; t: number; d: number; type?: OscillatorType; g?: number };

const SEQUENCES: Record<SoundName, Tone[]> = {
  button: [{ f: 660, t: 0, d: 0.04, type: 'square', g: 0.12 }],
  xp_tick: [{ f: 1320, t: 0, d: 0.025, type: 'square', g: 0.05 }],
  run: [{ f: 220, f2: 880, t: 0, d: 0.16, type: 'sawtooth', g: 0.12 }],
  hint: [
    { f: 880, t: 0, d: 0.1, type: 'sine', g: 0.3 },
    { f: 1318, t: 0.09, d: 0.22, type: 'sine', g: 0.25 },
  ],
  success: [
    { f: 523, t: 0, d: 0.1, type: 'square', g: 0.16 },
    { f: 659, t: 0.1, d: 0.1, type: 'square', g: 0.16 },
    { f: 784, t: 0.2, d: 0.1, type: 'square', g: 0.16 },
    { f: 1046, t: 0.3, d: 0.35, type: 'square', g: 0.18 },
  ],
  failure: [
    { f: 392, f2: 370, t: 0, d: 0.28, type: 'sawtooth', g: 0.12 },
    { f: 370, f2: 349, t: 0.3, d: 0.28, type: 'sawtooth', g: 0.12 },
    { f: 349, f2: 330, t: 0.6, d: 0.28, type: 'sawtooth', g: 0.12 },
    { f: 330, f2: 262, t: 0.9, d: 0.8, type: 'sawtooth', g: 0.13 },
  ],
  error: [
    { f: 880, t: 0, d: 0.09, type: 'square', g: 0.12 },
    { f: 440, t: 0.11, d: 0.16, type: 'square', g: 0.12 },
  ],
  level_complete: [
    { f: 392, t: 0, d: 0.12, type: 'triangle', g: 0.3 },
    { f: 523, t: 0.12, d: 0.12, type: 'triangle', g: 0.3 },
    { f: 659, t: 0.24, d: 0.12, type: 'triangle', g: 0.3 },
    { f: 784, t: 0.36, d: 0.2, type: 'triangle', g: 0.3 },
    { f: 659, t: 0.58, d: 0.1, type: 'triangle', g: 0.3 },
    { f: 784, t: 0.68, d: 0.6, type: 'triangle', g: 0.34 },
    { f: 1046, t: 0.68, d: 0.6, type: 'square', g: 0.08 },
  ],
  achievement: [
    { f: 1568, t: 0, d: 0.08, type: 'sine', g: 0.2 },
    { f: 2093, t: 0.07, d: 0.08, type: 'sine', g: 0.2 },
    { f: 2637, t: 0.14, d: 0.3, type: 'sine', g: 0.2 },
  ],
  event: [
    { f: 1200, t: 0, d: 0.06, type: 'square', g: 0.1 },
    { f: 1000, t: 0.07, d: 0.06, type: 'square', g: 0.1 },
    { f: 1200, t: 0.14, d: 0.06, type: 'square', g: 0.1 },
    { f: 1000, t: 0.21, d: 0.06, type: 'square', g: 0.1 },
    { f: 1200, t: 0.5, d: 0.06, type: 'square', g: 0.1 },
    { f: 1000, t: 0.57, d: 0.06, type: 'square', g: 0.1 },
    { f: 1200, t: 0.64, d: 0.06, type: 'square', g: 0.1 },
    { f: 1000, t: 0.71, d: 0.06, type: 'square', g: 0.1 },
  ],
};

class Manager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private fx: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private musicTimer: number | undefined;
  private vol: Volumes = { master: 0.8, effects: 0.9, music: 0.4, effectsOn: true, musicOn: false, captions: true };
  private captionListener: ((text: string) => void) | null = null;
  private lastPlayed = new Map<SoundName, number>();

  configure(v: Volumes): void {
    this.vol = v;
    if (this.master) this.master.gain.value = v.master;
    if (this.fx) this.fx.gain.value = v.effects;
    if (this.musicGain) this.musicGain.gain.value = v.music * 0.25;
    if (v.musicOn) this.startMusic();
    else this.stopMusic();
  }

  onCaption(fn: (text: string) => void): void {
    this.captionListener = fn;
  }

  /** Call from a user gesture (click/keydown) to unlock audio. */
  unlock(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    this.ctx = new Ctor();
    this.master = this.ctx.createGain();
    this.master.connect(this.ctx.destination);
    this.fx = this.ctx.createGain();
    this.fx.connect(this.master);
    this.musicGain = this.ctx.createGain();
    this.musicGain.connect(this.master);
    this.configure(this.vol);
  }

  play(name: SoundName): void {
    const caption = CAPTIONS[name];
    if (caption && this.vol.captions) this.captionListener?.(caption);
    if (!this.vol.effectsOn || this.vol.master === 0) return;
    // Rate-limit identical sounds so rapid clicks don't stack into noise.
    const now = performance.now();
    if (now - (this.lastPlayed.get(name) ?? 0) < 45) return;
    this.lastPlayed.set(name, now);
    this.unlock();
    const ctx = this.ctx;
    if (!ctx || !this.fx) return;
    const start = ctx.currentTime + 0.01;
    for (const tone of SEQUENCES[name]) this.tone(tone, start, this.fx);
  }

  private tone(t: Tone, start: number, dest: AudioNode): void {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = t.type ?? 'sine';
    osc.frequency.setValueAtTime(t.f, start + t.t);
    if (t.f2) osc.frequency.linearRampToValueAtTime(t.f2, start + t.t + t.d);
    const peak = t.g ?? 0.2;
    g.gain.setValueAtTime(0.0001, start + t.t);
    g.gain.exponentialRampToValueAtTime(peak, start + t.t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, start + t.t + t.d);
    osc.connect(g).connect(dest);
    osc.start(start + t.t);
    osc.stop(start + t.t + t.d + 0.05);
  }

  /** A tiny, calm procedural loop. Off by default. */
  private startMusic(): void {
    if (!this.ctx || !this.musicGain || this.musicTimer) return;
    const notes = [220, 277, 330, 277, 247, 294, 370, 294, 196, 247, 294, 247, 220, 277, 330, 415];
    let i = 0;
    const tick = () => {
      if (!this.ctx || !this.musicGain) return;
      const t = this.ctx.currentTime + 0.02;
      this.tone({ f: notes[i % notes.length], t: 0, d: 0.35, type: 'triangle', g: 0.25 }, t, this.musicGain);
      if (i % 4 === 0) this.tone({ f: notes[i % notes.length] / 2, t: 0, d: 0.9, type: 'sine', g: 0.3 }, t, this.musicGain);
      i++;
    };
    this.musicTimer = window.setInterval(tick, 300);
  }

  private stopMusic(): void {
    clearInterval(this.musicTimer);
    this.musicTimer = undefined;
  }
}

export const AudioManager = new Manager();
