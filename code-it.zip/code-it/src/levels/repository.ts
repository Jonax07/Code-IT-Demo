/**
 * Level source. Levels ship with the game (offline-first). When an API is configured,
 * GET /api/levels can override content; bundled levels remain the fallback.
 */
import { ApiClient, ApiUnavailable } from '../api/client';
import { LEVELS } from './data';
import type { Level } from './types';

export const CONTENT_VERSION = '2026.09.1';

let levels: Level[] = LEVELS;

export const LevelRepository = {
  all(): Level[] {
    return levels;
  },
  get(id: string): Level | undefined {
    return levels.find((l) => l.id === id);
  },
  next(id: string): Level | undefined {
    const i = levels.findIndex((l) => l.id === id);
    return i >= 0 ? levels[i + 1] : undefined;
  },
  isUnlocked(id: string, completed: (id: string) => boolean): boolean {
    const i = levels.findIndex((l) => l.id === id);
    return i === 0 || (i > 0 && completed(levels[i - 1].id));
  },
  /** Background refresh; never blocks gameplay. */
  async refresh(signal?: AbortSignal): Promise<void> {
    try {
      const remote = await ApiClient.get<{ version: string; levels: Level[] }>(`/api/levels?full=1&version=${CONTENT_VERSION}`, { ttlMs: 10 * 60_000, signal });
      if (Array.isArray(remote.levels) && remote.levels.length) levels = remote.levels;
    } catch (e) {
      if (!(e instanceof ApiUnavailable)) console.warn('[levels] using bundled levels', e);
    }
  },
};
