/**
 * Level + validation schema. Everything here is plain JSON-compatible data so levels
 * can later be served from GET /api/levels/:id without code changes.
 */

export type Lang = 'html' | 'css' | 'js';
export type CharacterId = 'byte' | 'dex' | 'tina' | 'client';

/** Style comparisons are evaluated against getComputedStyle values inside the sandbox. */
export type StyleCheck =
  | { op: 'equals'; value: string }
  | { op: 'oneOf'; values: string[] }
  | { op: 'not'; value: string }
  | { op: 'notIn'; values: string[] }
  | { op: 'contains'; value: string }
  | { op: 'notContains'; value: string }
  | { op: 'minPx'; value: number }
  | { op: 'hue'; min: number; max: number; minSat?: number };

export type InteractionStep =
  | { do: 'click'; selector: string }
  | { do: 'type'; selector: string; value: string }
  | { do: 'wait'; ms: number };

export type Expectation =
  | { selector: string; textContains: string }
  | { selector: string; textNotContains: string }
  | { selector: string; count: number }
  | { selector: string; minCount: number }
  | { selector: string; hasClass: string }
  | { selector: string; style: string; check: StyleCheck };

/** Rules evaluated in the sandbox against the rendered DOM. */
export type DomRule =
  | { type: 'element'; selector: string; min?: number }
  | { type: 'text'; selector: string; contains?: string; minLength?: number }
  | { type: 'attr'; selector: string; attr: string; contains?: string; nonEmpty?: boolean }
  | { type: 'style'; selector: string; prop: string; check: StyleCheck }
  | { type: 'sameRow'; selector: string; min: number }
  | { type: 'stacked'; selector: string; min: number }
  | { type: 'noOverflow' }
  | { type: 'noRuntimeErrors' }
  | { type: 'interact'; steps: InteractionStep[]; expect: Expectation[] };

/** Rules evaluated in the game (parent) against source text. Never executes code. */
export type SourceRule =
  | { type: 'source'; lang: Lang; pattern: string; flags?: string; negate?: boolean }
  | { type: 'htmlBalanced' };

export type RuleSpec = DomRule | SourceRule;

export interface Requirement {
  id: string;
  /** What the player sees in the checklist, phrased as a goal. */
  label: string;
  /** Why it failed, in plain words. Shown next to a ✕. */
  fail: string;
  /** A short nudge attached to the failure (not a full hint). */
  tip?: string;
  rule: RuleSpec;
  /** Viewport width the rule is evaluated at. Default 1024. */
  viewport?: number;
  /** Bonus checks award XP but are not required to pass. */
  bonus?: 'accessibility' | 'performance' | 'style';
}

export interface LevelEvent {
  /** Shown as a full-screen interrupt after the base requirements pass once. */
  title: string;
  from: CharacterId;
  message: string;
  requirements: Requirement[];
}

export interface Level {
  id: string;
  number: number;
  title: string;
  /** Short tagline on the job board. */
  tagline: string;
  category: 'html' | 'css' | 'layout' | 'js' | 'debug' | 'project';
  difficulty: 1 | 2 | 3;
  client: { name: string; role: string; avatarColor: string };
  /** The job ticket text, in the client's voice. */
  brief: string;
  objective: string;
  concepts: string[];
  expectedMistakes: string[];
  unlocks: string;
  tabs: Lang[];
  starter: Record<Lang, string>;
  requirements: Requirement[];
  /** Mid-level twist: the client changes their mind. */
  event?: LevelEvent;
  /** Progressive hints: concept → direction → near-solution → example. */
  hints: [string, string, string, string];
  isDebug?: boolean;
  parTimeSec: number;
}
