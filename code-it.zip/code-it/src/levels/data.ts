import type { Level } from './types';

/**
 * MVP campaign. Each level documents what it teaches, what it expects players to get
 * wrong, how success is detected, and what it unlocks.
 */
export const LEVELS: Level[] = [
  // ------------------------------------------------------------------ 1
  {
    id: 'html-001',
    number: 1,
    title: 'Pizza Panic',
    tagline: 'A pizza place with no website. A tragedy.',
    category: 'html',
    difficulty: 1,
    client: { name: 'Chef Rizzo', role: 'Owner, Rizzo’s Suspiciously Enthusiastic Pizza', avatarColor: '#ff7a45' },
    brief:
      'CIAO! My pizza is the best in the world and NOBODY KNOWS. I need a homepage. A big title with the word Pizza in it! A sentence about how amazing we are! A picture of pizza! A button so people can order! Please. I am begging. The dough is getting nervous.',
    objective: 'Structure a page with HTML elements: headings, paragraphs, images and buttons.',
    concepts: ['<h1> headings', '<p> paragraphs', '<img> images', '<button> buttons', 'alt text'],
    expectedMistakes: ['Forgetting the closing tag', 'Writing the text outside the tags', 'Using <img> without src'],
    unlocks: 'CSS styling',
    tabs: ['html'],
    starter: {
      html: `<!-- JOB #1: Build Chef Rizzo a homepage. -->
<!-- Tags wrap content like this:  <h1>Hello!</h1>  -->
<!-- There's a pizza picture ready at: pizza.svg -->

<h1>Welcome</h1>
`,
      css: '',
      js: '',
    },
    requirements: [
      { id: 'h1', label: 'Has a big <h1> title', fail: 'There is no <h1> on the page.', tip: 'Wrap your title in <h1> and </h1>.', rule: { type: 'element', selector: 'h1' } },
      { id: 'h1-pizza', label: 'The title mentions “Pizza”', fail: 'The <h1> doesn’t say “Pizza”. Chef Rizzo is weeping.', rule: { type: 'text', selector: 'h1', contains: 'pizza' } },
      { id: 'p', label: 'Has a <p> paragraph that brags a bit', fail: 'No paragraph with at least a few words.', tip: 'A paragraph is <p>Some words here</p>.', rule: { type: 'text', selector: 'p', minLength: 10 } },
      { id: 'img', label: 'Shows a picture with <img>', fail: 'There’s no <img> on the page.', tip: '<img src="pizza.svg"> shows the pizza picture.', rule: { type: 'element', selector: 'img' } },
      { id: 'button', label: 'Has an order <button>', fail: 'No <button> yet. How will people order?!', rule: { type: 'element', selector: 'button' } },
      { id: 'alt', label: 'Image has alt text for screen readers', fail: 'Your <img> has no alt text.', tip: 'Add alt="A delicious pizza" inside the <img> tag.', rule: { type: 'attr', selector: 'img', attr: 'alt', nonEmpty: true }, bonus: 'accessibility' },
    ],
    hints: [
      'HTML is made of tags. Most tags come in pairs: an opening tag like <p> and a closing tag like </p>. Whatever sits between them is the content.',
      'You need four more kinds of tag: a paragraph (<p>), an image (<img>), a button (<button>), and your <h1> needs the word Pizza in it.',
      'Images are special: they have no closing tag. The src attribute tells the browser which picture to load: <img src="pizza.svg">',
      'Example:\n<h1>Rizzo’s Pizza</h1>\n<p>The cheesiest pizza in town.</p>\n<img src="pizza.svg" alt="A pizza">\n<button>Order now</button>',
    ],
    parTimeSec: 180,
  },

  // ------------------------------------------------------------------ 2
  {
    id: 'css-001',
    number: 2,
    title: 'Make It Look Professional',
    tagline: 'Comic Sans. Yellow. Red. Wavy lines. Help.',
    category: 'css',
    difficulty: 1,
    client: { name: 'Mr. Bigsby', role: 'CEO, Bigsby & Sons Serious Consulting', avatarColor: '#6c7cff' },
    brief:
      'My nephew made our website. It looks like a birthday card from a clown. We are a SERIOUS consulting firm. Make it look professional. I don’t know what that means, but I will know it when I see it.',
    objective: 'Use CSS selectors and properties to control colour, typography, spacing and borders.',
    concepts: ['selectors', 'color & background-color', 'font-family', 'padding', 'border'],
    expectedMistakes: ['Missing semicolon between declarations', 'Typos in property names', 'Styling the wrong selector'],
    unlocks: 'Flexbox layout',
    tabs: ['css', 'html'],
    starter: {
      html: `<header>
  <h1>Bigsby &amp; Sons</h1>
  <p>Serious consulting for serious people.</p>
</header>
<div class="card">
  <h2>Our Services</h2>
  <p>We have meetings about meetings. Professionally.</p>
  <button class="cta">Book a consultation</button>
</div>
`,
      css: `/* JOB #2: Make this look professional. */
/* Change the values. Run it. See what happens. */

body {
  background-color: yellow;
  font-family: "Comic Sans MS", "Comic Neue", cursive;
  color: red;
}

h1 {
  font-size: 64px;
  text-decoration: underline wavy;
}

.card {
  border: 6px dashed lime;
  padding: 0px;
}

.cta {
  padding: 2px;
}
`,
      js: '',
    },
    requirements: [
      { id: 'bg', label: 'Page background is no longer yellow', fail: 'The body background is still yellow.', tip: 'Change background-color on body. Try #f4f1ea or white.', rule: { type: 'style', selector: 'body', prop: 'background-color', check: { op: 'notIn', values: ['rgb(255, 255, 0)'] } } },
      { id: 'font', label: 'No more Comic Sans', fail: 'The font is still Comic Sans.', tip: 'Try font-family: Georgia, serif; or Arial, sans-serif;', rule: { type: 'style', selector: 'body', prop: 'font-family', check: { op: 'notContains', value: 'comic' } } },
      { id: 'color', label: 'Text is not screaming red', fail: 'The text colour is still red.', rule: { type: 'style', selector: 'body', prop: 'color', check: { op: 'notIn', values: ['rgb(255, 0, 0)'] } } },
      { id: 'border', label: 'The card border isn’t dashed', fail: 'The .card border is still dashed.', tip: 'border: 1px solid #ccc; is calm and professional.', rule: { type: 'style', selector: '.card', prop: 'border-top-style', check: { op: 'not', value: 'dashed' } } },
      { id: 'padding', label: 'The card has breathing room (padding ≥ 16px)', fail: 'The .card padding is less than 16px, so text touches the border.', rule: { type: 'style', selector: '.card', prop: 'padding-top', check: { op: 'minPx', value: 16 } } },
      { id: 'cta-pad', label: 'The button is comfy to click (padding ≥ 10px)', fail: 'The .cta button padding is under 10px.', rule: { type: 'style', selector: '.cta', prop: 'padding-top', check: { op: 'minPx', value: 10 } } },
    ],
    event: {
      title: 'THE BOSS WANTS IT IN BLUE.',
      from: 'client',
      message: 'Looks great. Love it. One tiny thing: make the button BLUE. Blue is the colour of trust. And money. Mostly money.',
      requirements: [
        { id: 'cta-blue', label: 'The .cta button background is blue', fail: 'The .cta button isn’t blue yet.', tip: 'background-color: #2563eb; is a trustworthy blue.', rule: { type: 'style', selector: '.cta', prop: 'background-color', check: { op: 'hue', min: 190, max: 250 } } },
      ],
    },
    hints: [
      'CSS rules have a selector (what to style) and declarations (how to style it): selector { property: value; }',
      'Every requirement is one declaration to change. Look at body, .card and .cta. Change the values that look terrible.',
      'body needs a new background-color, font-family and color. .card needs a border that isn’t dashed and padding of at least 16px. .cta needs padding of at least 10px.',
      'Example:\nbody {\n  background-color: #f4f1ea;\n  font-family: Georgia, serif;\n  color: #222;\n}\n.card { border: 1px solid #ccc; padding: 24px; }\n.cta { padding: 12px 20px; }',
    ],
    parTimeSec: 240,
  },

  // ------------------------------------------------------------------ 3
  {
    id: 'layout-001',
    number: 3,
    title: 'Flexbox Food Truck',
    tagline: 'Everything is stacked like a sad pancake tower.',
    category: 'layout',
    difficulty: 2,
    client: { name: 'Taco Tanya', role: 'Owner, The Flexible Taco', avatarColor: '#2bb673' },
    brief:
      'My menu links are stacked on top of each other like a tower of tacos about to fall over. And my three dishes are in a long line going DOWN. I want them side by side! In a ROW! Like tacos on a plate!',
    objective: 'Use Flexbox to lay elements out in a row and space them with gap.',
    concepts: ['display: flex', 'gap', 'flex rows'],
    expectedMistakes: ['Putting display:flex on the children instead of the parent', 'Using margin instead of gap', 'Misspelling "flex"'],
    unlocks: 'JavaScript events',
    tabs: ['css', 'html'],
    starter: {
      html: `<nav class="menu">
  <a href="#">Tacos</a>
  <a href="#">Burritos</a>
  <a href="#">Nachos</a>
  <a href="#">Contact</a>
</nav>

<section class="dishes">
  <div class="dish">🌮 Classic Taco</div>
  <div class="dish">🌯 Mega Burrito</div>
  <div class="dish">🧀 Nacho Mountain</div>
</section>
`,
      css: `/* JOB #3: Put things in ROWS with flexbox. */

body { font-family: system-ui, sans-serif; margin: 24px; background: #fff8ec; }

.menu a {
  display: block;
  padding: 8px 12px;
  color: #1a1a1a;
}

.dish {
  background: white;
  border: 2px solid #1a1a1a;
  border-radius: 10px;
  padding: 20px;
  margin-top: 16px;
}
`,
      js: '',
    },
    requirements: [
      { id: 'menu-flex', label: '.menu uses display: flex', fail: '.menu isn’t a flex container yet.', tip: 'Flex goes on the PARENT: .menu { display: flex; }', rule: { type: 'style', selector: '.menu', prop: 'display', check: { op: 'equals', value: 'flex' } } },
      { id: 'menu-row', label: 'All 4 menu links sit in one row', fail: 'The menu links are still stacked.', rule: { type: 'sameRow', selector: '.menu a', min: 4 } },
      { id: 'dish-row', label: 'All 3 dishes sit side by side', fail: 'The dishes are still stacked vertically.', tip: 'Make .dishes a flex container too.', rule: { type: 'sameRow', selector: '.dish', min: 3 } },
      { id: 'gap', label: 'Dishes have a gap between them (≥ 12px)', fail: 'The dishes are touching. Tacos need personal space.', tip: 'gap: 16px; on the flex container adds space between children.', rule: { type: 'style', selector: '.dishes', prop: 'column-gap', check: { op: 'minPx', value: 12 } } },
    ],
    hints: [
      'Flexbox is turned on by the PARENT element. Its direct children then line up in a row automatically.',
      'The parents here are .menu (for the links) and .dishes (for the dishes). Give both of them display: flex.',
      'Once .dishes is a flex container, the gap property adds space between its children: gap: 16px;',
      'Example:\n.menu { display: flex; }\n.dishes { display: flex; gap: 16px; }',
    ],
    parTimeSec: 180,
  },

  // ------------------------------------------------------------------ 4
  {
    id: 'js-001',
    number: 4,
    title: 'Make The Button Do Something',
    tagline: 'The client pressed it 47 times. Nothing happened.',
    category: 'js',
    difficulty: 2,
    client: { name: 'Commander Pim', role: 'Head of Rocket Stuff, Probably-Safe Space Co.', avatarColor: '#ffb020' },
    brief:
      'We have a LAUNCH button. It is big. It is red. It does NOTHING. When someone clicks it, the status message must change to say LAUNCHED. Do it before the investors come back from lunch.',
    objective: 'Select elements with querySelector and react to clicks with addEventListener.',
    concepts: ['variables', 'functions', 'click events', 'textContent'],
    expectedMistakes: ['Calling the function instead of passing it', 'Wrong selector (missing #)', 'Spelling textContent wrong'],
    unlocks: 'Debugging',
    tabs: ['js', 'html', 'css'],
    starter: {
      html: `<h1>Rocket Launch Control</h1>
<div id="rocket">🚀</div>
<p id="status">Status: waiting...</p>
<button id="launch">LAUNCH</button>
`,
      css: `body { font-family: system-ui, sans-serif; text-align: center; padding: 24px; background: #0e1320; color: #e8ecf5; }
#rocket { font-size: 72px; transition: transform 1.2s cubic-bezier(.5,-0.3,.7,.2); }
#rocket.flying { transform: translateY(-400px) rotate(-10deg); }
#launch { font-size: 22px; font-weight: 800; padding: 14px 32px; border: 0; border-radius: 999px; background: #ff3b30; color: white; cursor: pointer; }
`,
      js: `// JOB #4: Make the LAUNCH button change the status text.

const launchButton = document.querySelector('#launch');
const statusText = document.querySelector('#status');

// When the button is clicked, run some code:
// launchButton.addEventListener('click', function () {
//   ...your code here...
// });
`,
    },
    requirements: [
      { id: 'listener', label: 'The button has a click listener', fail: 'Nothing is listening for clicks on the button.', tip: 'Uncomment the addEventListener lines (remove the //).', rule: { type: 'source', lang: 'js', pattern: String.raw`addEventListener\s*\(\s*['"]click['"]|\.onclick\s*=` } },
      { id: 'launched', label: 'Clicking LAUNCH makes the status say “LAUNCHED”', fail: 'After a click, the status text doesn’t say LAUNCHED.', tip: "Inside the listener: statusText.textContent = 'LAUNCHED!';", rule: { type: 'interact', steps: [{ do: 'click', selector: '#launch' }], expect: [{ selector: '#status', textContains: 'launched' }] } },
      { id: 'no-errors', label: 'No JavaScript errors', fail: 'Your JavaScript crashed. Check the console below.', rule: { type: 'noRuntimeErrors' } },
    ],
    event: {
      title: 'THE CLIENT CHANGED THE REQUIREMENTS.',
      from: 'client',
      message: 'Great, the text changes. But the ROCKET doesn’t move! When I click LAUNCH, the rocket should fly. Dex says the CSS already has a class called flying. Whatever that means.',
      requirements: [
        { id: 'flying', label: 'Clicking LAUNCH adds the class “flying” to #rocket', fail: '#rocket doesn’t get the flying class after a click.', tip: "Select the rocket, then rocket.classList.add('flying');", rule: { type: 'interact', steps: [{ do: 'click', selector: '#launch' }], expect: [{ selector: '#rocket', hasClass: 'flying' }] } },
      ],
    },
    hints: [
      'JavaScript can wait for something to happen (an event) and then run a function. A click is an event.',
      'addEventListener takes two things: the event name (\'click\') and a function to run. The starter code has one ready, it’s just commented out.',
      "Inside the function, change the text: statusText.textContent = 'LAUNCHED!';",
      "Example:\nlaunchButton.addEventListener('click', function () {\n  statusText.textContent = 'LAUNCHED!';\n});",
    ],
    parTimeSec: 180,
  },

  // ------------------------------------------------------------------ 5
  {
    id: 'debug-001',
    number: 5,
    title: 'The Previous Developer',
    tagline: 'He left one comment: // DO NOT TOUCH THIS',
    category: 'debug',
    difficulty: 2,
    client: { name: 'Dex', role: 'Senior Developer, tired', avatarColor: '#8b5cf6' },
    brief:
      'The last developer quit, moved to a farm, and left us this. The title should be orange, the button should be dark with white text, and clicking it should confirm the order. None of that works. There are bugs in the HTML, the CSS AND the JavaScript. Yes, you have to touch it.',
    objective: 'Find and fix bugs in HTML, CSS and JavaScript using error messages and the preview.',
    concepts: ['unclosed tags', 'selector typos', 'CSS syntax', 'JS reference errors'],
    expectedMistakes: ['Only fixing the first bug', 'Ignoring the console', 'Deleting code instead of fixing it'],
    unlocks: 'Mini projects',
    tabs: ['html', 'css', 'js'],
    isDebug: true,
    starter: {
      html: `<header>
  <h1 class="title">Snack Overflow</h1>
  <p>The <strong>#1 snack delivery for developers</p>
</header>

<main>
  <button id="order">Order snacks</button>
  <p id="result"></p>
</main>
`,
      css: `body { font-family: system-ui, sans-serif; padding: 24px; }

.titel {
  color: #ff5a36;
}

#order {
  background: #222 color: white;
  padding 12px 20px;
  border: 0;
  border-radius: 8px;
}
`,
      js: `// DO NOT TOUCH THIS
// (you are going to have to touch this)

const orderButton = documnet.querySelector('#order');
const result = document.querySelector('#result');

orderButton.addEventListener('click', function () {
  result.textContent = 'Snacks are on the way!';
});
`,
    },
    requirements: [
      { id: 'html-ok', label: 'Every HTML tag is closed', fail: 'An HTML tag is never closed, so it swallows everything after it.', tip: 'Look for red marks in the HTML tab.', rule: { type: 'htmlBalanced' } },
      { id: 'title-orange', label: 'The title is orange (#ff5a36)', fail: 'The .title isn’t orange. The CSS selector might not match anything.', tip: 'Compare the class in the HTML with the selector in the CSS. Letter by letter.', rule: { type: 'style', selector: '.title', prop: 'color', check: { op: 'equals', value: 'rgb(255, 90, 54)' } } },
      { id: 'btn-white', label: 'The button text is white', fail: 'The button text isn’t white. That CSS line is broken.', tip: 'Every declaration needs its own semicolon.', rule: { type: 'style', selector: '#order', prop: 'color', check: { op: 'equals', value: 'rgb(255, 255, 255)' } } },
      { id: 'btn-pad', label: 'The button has padding (≥ 12px)', fail: 'The button padding isn’t applied.', tip: 'Properties need a colon: padding: 12px;', rule: { type: 'style', selector: '#order', prop: 'padding-top', check: { op: 'minPx', value: 12 } } },
      { id: 'no-errors', label: 'No JavaScript errors', fail: 'The JavaScript crashes before it can do anything.', tip: 'Read the red error in the console. Which word is misspelled?', rule: { type: 'noRuntimeErrors' } },
      { id: 'click', label: 'Clicking the button confirms the order', fail: 'Clicking the button doesn’t show “Snacks are on the way!”.', rule: { type: 'interact', steps: [{ do: 'click', selector: '#order' }], expect: [{ selector: '#result', textContains: 'on the way' }] } },
    ],
    hints: [
      'Debugging tip: fix one bug at a time, run, repeat. Error messages tell you the line number. Red and yellow squiggles in the editor point at problems too.',
      'There are four bugs: one unclosed HTML tag, one misspelled CSS selector, one broken CSS rule block (two mistakes), and one misspelled word in the JavaScript.',
      'HTML: <strong> needs a </strong>. CSS: .titel should be .title; the #order block is missing a semicolon and a colon. JS: documnet is not a word the browser knows.',
      'Example fixes:\n<p>The <strong>#1 snack delivery</strong> for developers</p>\n.title { color: #ff5a36; }\nbackground: #222;\ncolor: white;\npadding: 12px 20px;\nconst orderButton = document.querySelector(\'#order\');',
    ],
    parTimeSec: 300,
  },

  // ------------------------------------------------------------------ 6
  {
    id: 'project-001',
    number: 6,
    title: 'Profile of a Legendary Cat',
    tagline: 'Sir Whiskerton demands an online presence.',
    category: 'project',
    difficulty: 2,
    client: { name: 'Sir Whiskerton', role: 'Cat. Influencer. Legend.', avatarColor: '#f59e0b' },
    brief:
      'Mrow. I require a profile card. It must show my portrait, my name in a heading, a list of at least three of my accomplishments, and a link to my fan club. Make it look expensive. I am, after all, a very expensive cat.',
    objective: 'Combine HTML structure and CSS styling to build a complete component.',
    concepts: ['containers', 'lists (<ul>, <li>)', 'links', 'padding & border-radius'],
    expectedMistakes: ['Putting elements outside the .profile container', 'Using <li> without <ul>', 'Links with no href'],
    unlocks: 'Product cards',
    tabs: ['html', 'css'],
    starter: {
      html: `<!-- JOB #6: A profile card for Sir Whiskerton. -->
<!-- Put EVERYTHING inside the .profile box. -->
<!-- A portrait is ready at: cat.svg -->

<div class="profile">

</div>
`,
      css: `body { font-family: system-ui, sans-serif; background: #efe7da; display: grid; place-items: center; min-height: 100vh; margin: 0; }

.profile {
  background: white;
  max-width: 320px;
}
`,
      js: '',
    },
    requirements: [
      { id: 'img', label: 'The card shows a portrait', fail: 'No <img> inside .profile.', rule: { type: 'element', selector: '.profile img' } },
      { id: 'name', label: 'A heading with the cat’s name', fail: 'No heading (h1, h2 or h3) with a name inside .profile.', rule: { type: 'text', selector: '.profile h1, .profile h2, .profile h3', minLength: 3 } },
      { id: 'list', label: 'A list of 3+ accomplishments', fail: 'Need a list with at least 3 <li> items inside .profile.', tip: 'A list is <ul> with <li> items inside it.', rule: { type: 'element', selector: '.profile ul li, .profile ol li', min: 3 } },
      { id: 'link', label: 'A link to the fan club', fail: 'No link with an href inside .profile.', tip: '<a href="https://example.com">Fan club</a>', rule: { type: 'attr', selector: '.profile a', attr: 'href', nonEmpty: true } },
      { id: 'padding', label: 'The card has padding (≥ 16px)', fail: '.profile needs at least 16px of padding.', rule: { type: 'style', selector: '.profile', prop: 'padding-top', check: { op: 'minPx', value: 16 } } },
      { id: 'radius', label: 'Rounded corners (≥ 8px). Expensive.', fail: '.profile needs a border-radius of at least 8px.', rule: { type: 'style', selector: '.profile', prop: 'border-top-left-radius', check: { op: 'minPx', value: 8 } } },
      { id: 'alt', label: 'Portrait has alt text', fail: 'The portrait has no alt text.', rule: { type: 'attr', selector: '.profile img', attr: 'alt', nonEmpty: true }, bonus: 'accessibility' },
    ],
    hints: [
      'A card is just a container element with other elements inside it. The .profile div is your container.',
      'Inside .profile you need: an <img>, a heading like <h2>, a <ul> with three <li>, and an <a href="...">. Then style .profile in the CSS.',
      'In the CSS, add padding: 24px; and border-radius: 16px; to the .profile rule.',
      'Example:\n<div class="profile">\n  <img src="cat.svg" alt="Sir Whiskerton">\n  <h2>Sir Whiskerton</h2>\n  <ul>\n    <li>Napped 20 hours</li>\n    <li>Knocked over a vase</li>\n    <li>Ignored a laser</li>\n  </ul>\n  <a href="https://example.com">Fan club</a>\n</div>',
    ],
    parTimeSec: 300,
  },

  // ------------------------------------------------------------------ 7
  {
    id: 'project-002',
    number: 7,
    title: 'The Sock 3000',
    tagline: 'A revolutionary sock needs a product card.',
    category: 'project',
    difficulty: 2,
    client: { name: 'Vera Vance', role: 'Founder, Sockify (disrupting feet)', avatarColor: '#ec4899' },
    brief:
      'The Sock 3000 is not a sock. It’s a lifestyle. I need a product card: price with a dollar sign, rounded corners, and an Add to cart button that actually counts how many socks are in the cart. Two clicks, two socks. That’s the business model.',
    objective: 'Combine HTML, CSS and JavaScript state: a variable that changes and updates the page.',
    concepts: ['state in a variable', 'incrementing numbers', 'updating the DOM', 'component styling'],
    expectedMistakes: ['Declaring the counter inside the click handler', 'Using = instead of += 1', 'Forgetting to update textContent'],
    unlocks: 'Responsive layout',
    tabs: ['html', 'css', 'js'],
    starter: {
      html: `<p class="cart">🛒 Cart: <span id="cart-count">0</span></p>

<div class="card">
  <img src="sock.svg" alt="The Sock 3000">
  <h2>The Sock 3000</h2>
  <!-- Add a price with class "price" here -->
  <button id="add">Add to cart</button>
</div>
`,
      css: `body { font-family: system-ui, sans-serif; background: #f6f3ff; padding: 24px; }
.card { background: white; max-width: 280px; padding: 20px; }
.card img { width: 100%; }
`,
      js: `// JOB #7: Count socks in the cart.
const addButton = document.querySelector('#add');
const cartCount = document.querySelector('#cart-count');

let count = 0;

// When #add is clicked: add 1 to count, then show it in #cart-count
`,
    },
    requirements: [
      { id: 'price', label: 'A .price that shows a $ amount', fail: 'No element with class "price" containing a $.', tip: '<p class="price">$30</p>', rule: { type: 'text', selector: '.card .price', contains: '$' } },
      { id: 'radius', label: 'The card has rounded corners (≥ 8px)', fail: '.card corners aren’t rounded.', rule: { type: 'style', selector: '.card', prop: 'border-top-left-radius', check: { op: 'minPx', value: 8 } } },
      { id: 'one', label: 'One click puts 1 sock in the cart', fail: 'After one click, the cart doesn’t show 1.', rule: { type: 'interact', steps: [{ do: 'click', selector: '#add' }], expect: [{ selector: '#cart-count', textContains: '1' }] } },
      { id: 'two', label: 'Two clicks put 2 socks in the cart', fail: 'After two clicks, the cart doesn’t show 2.', tip: 'Declare count OUTSIDE the click function so it remembers.', rule: { type: 'interact', steps: [{ do: 'click', selector: '#add' }, { do: 'click', selector: '#add' }], expect: [{ selector: '#cart-count', textContains: '2' }] } },
      { id: 'no-errors', label: 'No JavaScript errors', fail: 'Your JavaScript crashed. Check the console.', rule: { type: 'noRuntimeErrors' } },
    ],
    event: {
      title: 'THE CLIENT SAYS: MAKE IT POP.',
      from: 'client',
      message: 'It’s good. It’s fine. But it doesn’t POP. You know? It needs to POP. Like it’s floating off the page. Give it a shadow or something. Pop!',
      requirements: [
        { id: 'shadow', label: 'The card pops off the page (box-shadow)', fail: 'The .card has no box-shadow.', tip: 'box-shadow: 0 10px 30px rgba(0,0,0,.15);', rule: { type: 'style', selector: '.card', prop: 'box-shadow', check: { op: 'not', value: 'none' } } },
      ],
    },
    hints: [
      'State is information your page remembers, like how many socks are in the cart. It lives in a variable that changes over time.',
      'Listen for clicks on addButton. In the handler, increase count by 1, then put the new number into cartCount.textContent.',
      'count = count + 1; (or count++) increases it. cartCount.textContent = count; shows it.',
      "Example:\naddButton.addEventListener('click', function () {\n  count = count + 1;\n  cartCount.textContent = count;\n});\nAnd in HTML: <p class=\"price\">$30</p>. In CSS: .card { border-radius: 16px; }",
    ],
    parTimeSec: 300,
  },

  // ------------------------------------------------------------------ 8
  {
    id: 'layout-002',
    number: 8,
    title: 'Phone Emergency',
    tagline: 'The site explodes sideways on phones.',
    category: 'layout',
    difficulty: 3,
    client: { name: 'QA Tina', role: 'QA Tester. Has 14 phones.', avatarColor: '#14b8a6' },
    brief:
      'I opened the site on my phone and had to scroll SIDEWAYS. Sideways! Like a crab! On desktop the three features should stay side by side. On a phone (375px wide) they must stack and nothing should stick out. I will be testing on all 14 phones.',
    objective: 'Build a responsive layout with a media query that changes the layout on small screens.',
    concepts: ['@media queries', 'flex-direction', 'fixed vs flexible widths', 'viewport'],
    expectedMistakes: ['Media query with the wrong comparison (min vs max)', 'Forgetting the fixed width still applies', 'Missing braces around the media block'],
    unlocks: 'Advanced debugging',
    tabs: ['css', 'html'],
    starter: {
      html: `<header><h1>Crab-Free Websites Inc.</h1></header>
<section class="features">
  <div class="feature">⚡ Fast</div>
  <div class="feature">🔒 Secure</div>
  <div class="feature">🦀 Zero sideways scrolling</div>
</section>
`,
      css: `/* JOB #8: Make it work on a 375px wide phone. */
body { font-family: system-ui, sans-serif; margin: 0; padding: 16px; }

.features {
  display: flex;
  gap: 16px;
}

.feature {
  width: 300px;
  flex-shrink: 0;
  padding: 24px;
  background: #e7f7f4;
  border-radius: 12px;
  box-sizing: border-box;
}

/* Styles for phones go inside a media query: */
/* @media (max-width: 600px) { ... } */
`,
      js: '',
    },
    requirements: [
      { id: 'desktop-row', label: 'Desktop (1024px): features side by side', fail: 'On desktop the features aren’t in one row anymore.', rule: { type: 'sameRow', selector: '.feature', min: 3 }, viewport: 1024 },
      { id: 'phone-stack', label: 'Phone (375px): features stack vertically', fail: 'On a 375px phone the features are still side by side.', tip: 'In the media query: .features { flex-direction: column; }', rule: { type: 'stacked', selector: '.feature', min: 3 }, viewport: 375 },
      { id: 'phone-fit', label: 'Phone (375px): no sideways scrolling', fail: 'On a 375px phone the page is wider than the screen.', tip: 'A 300px feature + padding is fine, but check for anything with a fixed width.', rule: { type: 'noOverflow' }, viewport: 375 },
      { id: 'media', label: 'Uses a @media query', fail: 'There’s no @media query in the CSS.', rule: { type: 'source', lang: 'css', pattern: String.raw`@media[^{]*\(\s*max-width|@media[^{]*\(\s*min-width|@media[^{]*width\s*[<>]` } },
    ],
    hints: [
      'A media query is CSS that only applies when the screen matches a condition, like "narrower than 600px".',
      'Write @media (max-width: 600px) { ... } and put rules inside it that change the .features layout for phones.',
      'Inside the media query, set .features { flex-direction: column; } and make .feature { width: 100%; } so they fit.',
      'Example:\n@media (max-width: 600px) {\n  .features { flex-direction: column; }\n  .feature { width: 100%; }\n}',
    ],
    parTimeSec: 300,
  },

  // ------------------------------------------------------------------ 9
  {
    id: 'debug-002',
    number: 9,
    title: 'JavaScript Says: Absolutely Not',
    tagline: 'The to-do app does not do.',
    category: 'debug',
    difficulty: 3,
    client: { name: 'Dex', role: 'Senior Developer, even more tired', avatarColor: '#8b5cf6' },
    brief:
      'Our to-do app crashes on load. When it doesn’t crash, it adds a mystery “undefined” task. And it lets you add empty tasks. There are three bugs. They are all JavaScript. They are all classic. Find them.',
    objective: 'Debug JavaScript logic: comparisons, function references and loop boundaries.',
    concepts: ['= vs ===', 'passing vs calling functions', 'off-by-one loops', 'arrays'],
    expectedMistakes: ['Fixing the crash but not the logic', 'Changing const to let instead of fixing the comparison', 'Deleting the loop'],
    unlocks: 'The final project',
    tabs: ['js', 'html'],
    isDebug: true,
    starter: {
      html: `<h1>Get Stuff Done™</h1>
<input id="task" placeholder="New task">
<button id="add">Add</button>
<ul id="list"></ul>
<p id="count">0 tasks</p>
`,
      css: 'body { font-family: system-ui, sans-serif; padding: 24px; }',
      js: `const input = document.querySelector('#task');
const addButton = document.querySelector('#add');
const list = document.querySelector('#list');
const count = document.querySelector('#count');

let tasks = [];

function addTask() {
  const text = input.value.trim();
  if (text = '') {
    return;
  }
  tasks.push(text);
  render();
  input.value = '';
}

function render() {
  list.innerHTML = '';
  for (let i = 0; i <= tasks.length; i++) {
    const li = document.createElement('li');
    li.textContent = tasks[i];
    list.appendChild(li);
  }
  count.textContent = tasks.length + ' tasks';
}

addButton.addEventListener('click', addTask());
`,
    },
    requirements: [
      { id: 'no-errors', label: 'The app loads without crashing', fail: 'JavaScript throws an error as soon as the page loads.', tip: 'Does addEventListener get the function, or the result of calling it?', rule: { type: 'noRuntimeErrors' } },
      { id: 'adds', label: 'Adding “Feed the cat” shows exactly 1 task', fail: 'Adding one task doesn’t show exactly one item in the list.', tip: 'If you see "undefined", count your loop steps. How many items does an array of 1 have?', rule: { type: 'interact', steps: [{ do: 'type', selector: '#task', value: 'Feed the cat' }, { do: 'click', selector: '#add' }], expect: [{ selector: '#list li', count: 1 }, { selector: '#list', textContains: 'Feed the cat' }] } },
      { id: 'empty', label: 'Empty tasks are ignored', fail: 'Clicking Add with an empty box still adds something.', tip: '= assigns a value. === compares values.', rule: { type: 'interact', steps: [{ do: 'type', selector: '#task', value: '   ' }, { do: 'click', selector: '#add' }], expect: [{ selector: '#list li', count: 0 }] } },
      { id: 'two', label: 'Two tasks → counter says 2', fail: 'After adding two tasks the list or counter is wrong.', rule: { type: 'interact', steps: [{ do: 'type', selector: '#task', value: 'Nap' }, { do: 'click', selector: '#add' }, { do: 'type', selector: '#task', value: 'Snack' }, { do: 'click', selector: '#add' }], expect: [{ selector: '#list li', count: 2 }, { selector: '#count', textContains: '2' }] } },
    ],
    hints: [
      'Three classic bugs: a comparison that isn’t a comparison, a function that runs too early, and a loop that goes one step too far.',
      'Look at the if statement in addTask, the last line (addEventListener), and the for loop condition in render.',
      "if (text === '') compares. addEventListener('click', addTask) passes the function without calling it. i < tasks.length stops at the last item.",
      "Example fixes:\nif (text === '') {\nfor (let i = 0; i < tasks.length; i++) {\naddButton.addEventListener('click', addTask);",
    ],
    parTimeSec: 360,
  },

  // ------------------------------------------------------------------ 10
  {
    id: 'final-001',
    number: 10,
    title: 'Launch Day',
    tagline: 'Build a whole website. From scratch. Today.',
    category: 'project',
    difficulty: 3,
    client: { name: 'Mr. Bigsby', role: 'CEO, now also founder of NapPod Inc.', avatarColor: '#6c7cff' },
    brief:
      'I have a new startup: NapPod. Pods. For napping. The website launches TODAY. It needs: a nav with at least 3 links, a big headline, three feature cards that sit side by side on desktop and stack on phones, and a dark mode button because apparently everybody wants that now. No sideways scrolling. Tina will check.',
    objective: 'Combine semantic HTML, responsive CSS and JavaScript interaction in one finished page.',
    concepts: ['everything so far'],
    expectedMistakes: ['Toggling the class on the wrong element', 'Media query that also breaks desktop', 'Forgetting the id on the button'],
    unlocks: 'Free build mode (coming soon)',
    tabs: ['html', 'css', 'js'],
    starter: {
      html: `<!-- FINAL JOB: NapPod launch site. -->
<!-- You need: nav with 3+ links, an <h1>, 3 elements with class="card", -->
<!-- and a <button id="theme-toggle"> for dark mode. Image ready: nappod.svg -->

<header>
  <nav>

  </nav>
</header>

<main>

</main>
`,
      css: `body { font-family: system-ui, sans-serif; margin: 0; padding: 16px; }
body.dark { background: #111; color: #eee; }
`,
      js: `// Clicking #theme-toggle should toggle the class "dark" on <body>.
`,
    },
    requirements: [
      { id: 'nav', label: 'Nav with at least 3 links', fail: 'Need at least 3 <a> links inside <nav>.', rule: { type: 'element', selector: 'nav a', min: 3 } },
      { id: 'h1', label: 'A headline (<h1>)', fail: 'No <h1> with text.', rule: { type: 'text', selector: 'h1', minLength: 3 } },
      { id: 'cards', label: '3 feature cards (class="card")', fail: 'Need at least 3 elements with class "card".', rule: { type: 'element', selector: '.card', min: 3 } },
      { id: 'cards-row', label: 'Desktop: cards side by side', fail: 'On desktop (1024px) the cards aren’t in one row.', rule: { type: 'sameRow', selector: '.card', min: 3 }, viewport: 1024 },
      { id: 'cards-stack', label: 'Phone: cards stack', fail: 'On a phone (375px) the cards aren’t stacked.', rule: { type: 'stacked', selector: '.card', min: 3 }, viewport: 375 },
      { id: 'no-scroll', label: 'Phone: no sideways scrolling', fail: 'On a phone (375px) the page is wider than the screen.', rule: { type: 'noOverflow' }, viewport: 375 },
      { id: 'dark', label: 'Dark mode button toggles body.dark', fail: 'Clicking #theme-toggle doesn’t add the class "dark" to <body>.', tip: "document.body.classList.toggle('dark')", rule: { type: 'interact', steps: [{ do: 'click', selector: '#theme-toggle' }], expect: [{ selector: 'body', hasClass: 'dark' }] } },
      { id: 'no-errors', label: 'No JavaScript errors', fail: 'Your JavaScript crashed. Check the console.', rule: { type: 'noRuntimeErrors' } },
      { id: 'alt', label: 'All images have alt text', fail: 'An image is missing alt text.', rule: { type: 'attr', selector: 'img', attr: 'alt', nonEmpty: true }, bonus: 'accessibility' },
    ],
    hints: [
      'Break it into pieces and run after each one: nav, headline, cards, layout, then dark mode. The checklist shows what’s left.',
      'Cards: put 3 <div class="card"> inside a wrapper, make the wrapper display: flex, then use a media query to switch to flex-direction: column on small screens.',
      "Dark mode: select the button with document.querySelector('#theme-toggle') and in its click listener call document.body.classList.toggle('dark').",
      "Example skeleton:\n<nav><a href=\"#\">Home</a><a href=\"#\">Pods</a><a href=\"#\">Nap</a></nav>\n<h1>Nap anywhere.</h1>\n<div class=\"cards\"><div class=\"card\">Quiet</div><div class=\"card\">Comfy</div><div class=\"card\">Portable</div></div>\n<button id=\"theme-toggle\">Dark mode</button>\n\n.cards { display: flex; gap: 16px; }\n@media (max-width: 600px) { .cards { flex-direction: column; } }",
    ],
    parTimeSec: 600,
  },
];
