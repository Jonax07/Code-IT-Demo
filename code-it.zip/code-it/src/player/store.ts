/**
 * Player profile persistence. localStorage is the source of truth on this device;
 * the server (when configured) receives progress through the sync queue and must
 * re-validate it (never trust client-side progress for anything competitive).
 */
export interface LevelRecord {
  completed: boolean;
  bestXp: number;
  attempts: number;
  hintsUsed: number;
  bestTimeMs: number | null;
  stars: number;
  /** Player's latest code, so leaving a level never loses work. */
  draft?: { html: string; css: string; js: string };
}

export interface Settings {
  masterVolume: number;
  effectsVolume: number;
  musicVolume: number;
  music: boolean;
  soundEffects: boolean;
  reducedMotion: boolean;
  captions: boolean;
  theme: 'dark' | 'light';
}

export interface PlayerProfile {
  id: string;
  name: string;
  xp: number;
  levels: Record<string, LevelRecord>;
  achievements: string[];
  stats: { runs: number; errorsSeen: number; bugsFixed: number; resets: number };
  settings: Settings;
  version: 1;
}

const KEY = 'codeit.player.v1';

const prefersReducedMotion = () =>
  typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;
const prefersLight = () => typeof matchMedia !== 'undefined' && matchMedia('(prefers-color-scheme: light)').matches;

export function newProfile(): PlayerProfile {
  return {
    id: `player_${crypto.randomUUID ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10)}`,
    name: 'Junior Dev',
    xp: 0,
    levels: {},
    achievements: [],
    stats: { runs: 0, errorsSeen: 0, bugsFixed: 0, resets: 0 },
    settings: {
      masterVolume: 0.8,
      effectsVolume: 0.9,
      musicVolume: 0.4,
      music: false,
      soundEffects: true,
      reducedMotion: prefersReducedMotion(),
      captions: true,
      theme: prefersLight() ? 'light' : 'dark',
    },
    version: 1,
  };
}

export function emptyRecord(): LevelRecord {
  return { completed: false, bestXp: 0, attempts: 0, hintsUsed: 0, bestTimeMs: null, stars: 0 };
}

type Listener = (p: PlayerProfile) => void;

class Store {
  private profile: PlayerProfile;
  private listeners = new Set<Listener>();
  private saveTimer: number | undefined;

  constructor() {
    this.profile = this.load();
  }

  get(): PlayerProfile {
    return this.profile;
  }

  isNew(): boolean {
    return this.profile.xp === 0 && Object.keys(this.profile.levels).length === 0;
  }

  update(fn: (p: PlayerProfile) => void, immediate = false): void {
    fn(this.profile);
    this.listeners.forEach((l) => l(this.profile));
    // Debounce saves; drafts change on every keystroke.
    clearTimeout(this.saveTimer);
    if (immediate) this.save();
    else this.saveTimer = window.setTimeout(() => this.save(), 400);
  }

  level(id: string): LevelRecord {
    return this.profile.levels[id] ?? emptyRecord();
  }

  subscribe(l: Listener): () => void {
    this.listeners.add(l);
    return () => this.listeners.delete(l);
  }

  reset(): void {
    const settings = this.profile.settings;
    this.profile = newProfile();
    this.profile.settings = settings;
    this.save();
    this.listeners.forEach((l) => l(this.profile));
  }

  flush(): void {
    clearTimeout(this.saveTimer);
    this.save();
  }

  private load(): PlayerProfile {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return newProfile();
      const parsed = JSON.parse(raw) as PlayerProfile;
      const base = newProfile();
      // Merge so profiles saved by older builds gain new fields.
      return { ...base, ...parsed, settings: { ...base.settings, ...parsed.settings }, stats: { ...base.stats, ...parsed.stats } };
    } catch {
      return newProfile();
    }
  }

  private save(): void {
    try {
      localStorage.setItem(KEY, JSON.stringify(this.profile));
    } catch {
      /* private mode / quota: keep playing in memory */
    }
  }
}

export const PlayerStore = new Store();
if (typeof window !== 'undefined') window.addEventListener('pagehide', () => PlayerStore.flush());
