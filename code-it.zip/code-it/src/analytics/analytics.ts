/**
 * Learning-focused analytics. Events are batched, de-duplicated, and never include
 * player code. Without an API they stay in memory for the dev diagnostics panel.
 */
import { ApiClient } from '../api/client';
import { PlayerStore } from '../player/store';

export type AnalyticsEvent =
  | { event: 'level_started'; levelId: string }
  | { event: 'code_run'; levelId: string; passed: boolean; failedChecks: string[]; errorCount: number; validationMs: number }
  | { event: 'hint_used'; levelId: string; hintIndex: number }
  | { event: 'level_completed'; levelId: string; attempts: number; hintsUsed: number; durationMs: number; xp: number }
  | { event: 'requirement_changed'; levelId: string }
  | { event: 'code_reset'; levelId: string };

const FLUSH_MS = 10_000;
const recent: (AnalyticsEvent & { at: number })[] = [];
let batch: (AnalyticsEvent & { at: number; playerId: string })[] = [];
const sentKeys = new Set<string>();
let timer: number | undefined;

function flush(): void {
  timer = undefined;
  if (!batch.length) return;
  const events = batch;
  batch = [];
  ApiClient.enqueue('POST', '/api/analytics/events', { events }, `an:${events[0].at}:${events.length}`);
}

export const Analytics = {
  /** `onceKey` prevents duplicates for events that must be reported once (e.g. level_completed per run). */
  track(e: AnalyticsEvent, onceKey?: string): void {
    if (onceKey) {
      if (sentKeys.has(onceKey)) return;
      sentKeys.add(onceKey);
    }
    const stamped = { ...e, at: Date.now() };
    recent.push(stamped);
    if (recent.length > 200) recent.shift();
    if (!ApiClient.online) return;
    batch.push({ ...stamped, playerId: PlayerStore.get().id });
    if (!timer) timer = window.setTimeout(flush, FLUSH_MS);
  },
  recent(): readonly (AnalyticsEvent & { at: number })[] {
    return recent;
  },
  flush,
};

if (typeof window !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flush();
  });
}
