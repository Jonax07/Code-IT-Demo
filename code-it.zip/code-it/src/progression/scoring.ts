/**
 * XP is additive and never negative: hints and retries cost bonuses, not base XP.
 * Experimentation (lots of runs) is rewarded, not penalised.
 */
export interface AttemptStats {
  runs: number;
  failedRuns: number;
  hintsUsed: number;
  sawErrors: boolean;
  durationMs: number;
  parTimeSec: number;
  bonusPassed: { accessibility: boolean; performance: boolean; style: boolean };
  isDebug: boolean;
  firstClear: boolean;
}

export interface XpLine {
  key: string;
  label: string;
  xp: number;
}

export function scoreLevel(s: AttemptStats): { lines: XpLine[]; total: number; stars: number } {
  const lines: XpLine[] = [{ key: 'base', label: 'Job complete', xp: 100 }];
  if (s.failedRuns === 0) lines.push({ key: 'first', label: 'First-try bonus', xp: 50 });
  if (s.hintsUsed === 0) lines.push({ key: 'nohint', label: 'No-hint bonus', xp: 30 });
  if (s.isDebug || s.sawErrors) lines.push({ key: 'debug', label: s.isDebug ? 'Bug squasher bonus' : 'Broke it, fixed it', xp: 40 });
  if (s.runs >= 4) lines.push({ key: 'explore', label: 'Experimenter bonus', xp: 20 });
  if (s.durationMs <= s.parTimeSec * 1000) lines.push({ key: 'speed', label: 'Beat the deadline', xp: 25 });
  if (s.bonusPassed.accessibility) lines.push({ key: 'a11y', label: 'Accessibility bonus', xp: 30 });
  if (s.bonusPassed.performance) lines.push({ key: 'perf', label: 'Performance bonus', xp: 20 });
  if (!s.firstClear) {
    // Replays still feel good but give half XP so the ladder can't be farmed.
    for (const l of lines) l.xp = Math.round(l.xp / 2);
    lines.push({ key: 'replay', label: 'Replay (half XP)', xp: 0 });
  }
  const total = lines.reduce((a, l) => a + l.xp, 0);
  // Stars: completing = 1, first try or no hints = 2, both = 3.
  const stars = 1 + (s.failedRuns === 0 ? 1 : 0) + (s.hintsUsed === 0 ? 1 : 0);
  return { lines, total, stars };
}

const RANKS = ['Intern', 'Junior Dev', 'Bug Wrangler', 'Code Wizard', 'Senior Dev', 'Tech Lead', 'Legendary Dev'];
export const XP_PER_RANK = 350;

export function rankFor(xp: number): { rank: number; title: string; into: number; needed: number } {
  const rank = Math.floor(xp / XP_PER_RANK) + 1;
  return {
    rank,
    title: RANKS[Math.min(rank - 1, RANKS.length - 1)],
    into: xp % XP_PER_RANK,
    needed: XP_PER_RANK,
  };
}
