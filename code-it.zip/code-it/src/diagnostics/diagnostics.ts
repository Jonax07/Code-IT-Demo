/**
 * Developer diagnostics. Hidden from players; open with ?debug=1 or Ctrl+Shift+D.
 * Measures: load timing, validation/execution time, long frames, game JS errors,
 * memory (Chromium), API stats and recent analytics events.
 */
import { Analytics } from '../analytics/analytics';
import { ApiClient } from '../api/client';

type Sample = Record<string, number>;
const samples: Record<string, Sample[]> = {};
let longFrames = 0;
let gameErrors = 0;
let panel: HTMLElement | null = null;
let timer: number | undefined;

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const p95 = (xs: number[]) => {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(s.length * 0.95))];
};

export const Diagnostics = {
  init(): void {
    try {
      const po = new PerformanceObserver((list) => (longFrames += list.getEntries().length));
      po.observe({ type: 'longtask', buffered: true });
    } catch {
      /* unsupported */
    }
    window.addEventListener('error', () => gameErrors++);
    window.addEventListener('unhandledrejection', () => gameErrors++);
    window.addEventListener('keydown', (e) => {
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        this.toggle();
      }
    });
    if (new URLSearchParams(location.search).has('debug')) this.toggle();
  },

  record(kind: string, s: Sample): void {
    (samples[kind] ??= []).push(s);
    if (samples[kind].length > 50) samples[kind].shift();
  },

  snapshot() {
    const nav = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined;
    const v = samples.validation ?? [];
    const mem = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory;
    return {
      loadMs: nav ? Math.round(nav.loadEventEnd - nav.startTime) : null,
      domInteractiveMs: nav ? Math.round(nav.domInteractive - nav.startTime) : null,
      validationAvgMs: Math.round(avg(v.map((x) => x.totalMs))),
      validationP95Ms: Math.round(p95(v.map((x) => x.totalMs))),
      executionAvgMs: Math.round(avg(v.map((x) => x.executionMs))),
      previewAvgMs: Math.round(avg((samples.preview ?? []).map((x) => x.renderMs))),
      runs: v.length,
      longFrames,
      gameErrors,
      heapMb: mem ? Math.round(mem.usedJSHeapSize / 1e6) : null,
      api: { ...ApiClient.stats, latenciesMs: undefined, avgLatencyMs: Math.round(avg(ApiClient.stats.latenciesMs)), configured: ApiClient.online },
      recentEvents: Analytics.recent().slice(-6).map((e) => e.event),
    };
  },

  toggle(): void {
    if (panel) {
      panel.remove();
      panel = null;
      clearInterval(timer);
      return;
    }
    panel = document.createElement('pre');
    panel.className = 'diag-panel mono';
    panel.setAttribute('aria-label', 'Developer diagnostics');
    document.body.appendChild(panel);
    const paint = () => panel && (panel.textContent = 'DIAGNOSTICS (Ctrl+Shift+D)\n' + JSON.stringify(this.snapshot(), null, 1));
    paint();
    timer = window.setInterval(paint, 1000);
  },
};
