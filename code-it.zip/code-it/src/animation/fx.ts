/**
 * Animation engine. Everything is transform/opacity based (compositor-only) and
 * becomes a no-op when reduced motion is on.
 */
let reduced = false;

export const FX = {
  setReducedMotion(v: boolean): void {
    reduced = v;
    document.documentElement.toggleAttribute('data-reduced-motion', v);
  },

  get reduced(): boolean {
    return reduced;
  },

  shake(el: Element, strength: 'small' | 'big' = 'small'): void {
    if (reduced) return;
    const d = strength === 'big' ? 10 : 5;
    el.animate(
      [
        { transform: 'translate(0,0)' },
        { transform: `translate(${-d}px, ${d / 2}px)` },
        { transform: `translate(${d}px, ${-d / 2}px)` },
        { transform: `translate(${-d / 2}px, 0)` },
        { transform: `translate(${d / 2}px, 0)` },
        { transform: 'translate(0,0)' },
      ],
      { duration: 360, easing: 'ease-out' },
    );
  },

  bounce(el: Element): void {
    if (reduced) return;
    el.animate(
      [
        { transform: 'translateY(0) scale(1)' },
        { transform: 'translateY(-14px) scale(1.06)' },
        { transform: 'translateY(0) scale(0.98)' },
        { transform: 'translateY(-5px) scale(1.02)' },
        { transform: 'translateY(0) scale(1)' },
      ],
      { duration: 620, easing: 'cubic-bezier(.3,1.6,.5,1)' },
    );
  },

  pop(el: Element): void {
    if (reduced) return;
    el.animate([{ transform: 'scale(.6)', opacity: 0 }, { transform: 'scale(1.08)', opacity: 1 }, { transform: 'scale(1)' }], {
      duration: 380,
      easing: 'cubic-bezier(.2,1.4,.4,1)',
    });
  },

  countUp(el: HTMLElement, from: number, to: number, ms: number, onTick?: () => void): Promise<void> {
    return new Promise((resolve) => {
      if (reduced || to === from) {
        el.textContent = String(to);
        return resolve();
      }
      const t0 = performance.now();
      let last = from;
      const frame = (t: number) => {
        const k = Math.min(1, (t - t0) / ms);
        const eased = 1 - Math.pow(1 - k, 3);
        const v = Math.round(from + (to - from) * eased);
        if (v !== last && v % 10 === 0) onTick?.();
        last = v;
        el.textContent = String(v);
        if (k < 1) requestAnimationFrame(frame);
        else resolve();
      };
      requestAnimationFrame(frame);
    });
  },

  confetti(opts: { count?: number; origin?: { x: number; y: number } } = {}): void {
    if (reduced) return;
    const canvas = document.createElement('canvas');
    canvas.className = 'fx-canvas';
    canvas.setAttribute('aria-hidden', 'true');
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = innerWidth * dpr;
    canvas.height = innerHeight * dpr;
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d')!;
    ctx.scale(dpr, dpr);
    const colors = ['#ff5a36', '#3ddc84', '#ffc53d', '#4d9fff', '#f472b6', '#ffffff'];
    const glyphs = ['{', '}', '<', '>', '/', ';', '()'];
    const ox = opts.origin?.x ?? innerWidth / 2;
    const oy = opts.origin?.y ?? innerHeight / 3;
    const parts = Array.from({ length: opts.count ?? 140 }, (_, i) => ({
      x: ox,
      y: oy,
      vx: (Math.random() - 0.5) * 16,
      vy: Math.random() * -14 - 4,
      r: Math.random() * Math.PI,
      vr: (Math.random() - 0.5) * 0.4,
      s: 6 + Math.random() * 6,
      c: colors[i % colors.length],
      g: i % 5 === 0 ? glyphs[i % glyphs.length] : null,
    }));
    const t0 = performance.now();
    const step = (t: number) => {
      const age = t - t0;
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      for (const p of parts) {
        p.vy += 0.42;
        p.vx *= 0.99;
        p.x += p.vx;
        p.y += p.vy;
        p.r += p.vr;
        ctx.save();
        ctx.globalAlpha = Math.max(0, 1 - age / 2400);
        ctx.translate(p.x, p.y);
        ctx.rotate(p.r);
        ctx.fillStyle = p.c;
        if (p.g) {
          ctx.font = `700 ${p.s * 2.2}px "JetBrains Mono", monospace`;
          ctx.fillText(p.g, 0, 0);
        } else ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2);
        ctx.restore();
      }
      if (age < 2400) requestAnimationFrame(step);
      else canvas.remove();
    };
    requestAnimationFrame(step);
  },
};
