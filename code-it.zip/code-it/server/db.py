"""SQLite storage. One file, created on first run, safe to delete to start fresh."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

from .rules import ProgressReport

SCHEMA = """
CREATE TABLE IF NOT EXISTS players (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS progress (
  player_id TEXT NOT NULL REFERENCES players(id),
  level_id TEXT NOT NULL,
  attempts INTEGER NOT NULL,
  hints_used INTEGER NOT NULL,
  best_time_ms INTEGER NOT NULL,
  stars INTEGER NOT NULL,
  best_xp INTEGER NOT NULL,
  completions INTEGER NOT NULL DEFAULT 1,
  updated_at REAL NOT NULL,
  PRIMARY KEY (player_id, level_id)
);
CREATE TABLE IF NOT EXISTS achievements (
  player_id TEXT NOT NULL REFERENCES players(id),
  achievement_id TEXT NOT NULL,
  unlocked_at REAL NOT NULL,
  PRIMARY KEY (player_id, achievement_id)
);
CREATE TABLE IF NOT EXISTS analytics_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  player_id TEXT,
  event TEXT NOT NULL,
  payload TEXT NOT NULL,
  received_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS analytics_event_idx ON analytics_events(event);
CREATE TABLE IF NOT EXISTS idempotency (
  key TEXT PRIMARY KEY,
  status INTEGER NOT NULL,
  response TEXT NOT NULL,
  created_at REAL NOT NULL
);
"""


class Store:
    def __init__(self, path: str | Path):
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript(SCHEMA)
        self._lock = threading.Lock()

    def close(self) -> None:
        self._db.close()

    # -- idempotency ---------------------------------------------------------
    def replay(self, key: str) -> tuple[int, dict] | None:
        with self._lock:
            row = self._db.execute("SELECT status, response FROM idempotency WHERE key = ?", (key,)).fetchone()
        return (row["status"], json.loads(row["response"])) if row else None

    def remember(self, key: str, status: int, response: dict) -> None:
        with self._lock, self._db:
            self._db.execute(
                "INSERT OR IGNORE INTO idempotency (key, status, response, created_at) VALUES (?, ?, ?, ?)",
                (key, status, json.dumps(response), time.time()),
            )

    # -- players -------------------------------------------------------------
    def upsert_player(self, player_id: str, name: str) -> None:
        with self._lock, self._db:
            self._db.execute(
                "INSERT INTO players (id, name, created_at) VALUES (?, ?, ?) "
                "ON CONFLICT(id) DO UPDATE SET name = excluded.name",
                (player_id, name, time.time()),
            )

    def ensure_player(self, player_id: str) -> None:
        with self._lock, self._db:
            self._db.execute(
                "INSERT OR IGNORE INTO players (id, name, created_at) VALUES (?, 'Junior Dev', ?)",
                (player_id, time.time()),
            )

    def player(self, player_id: str) -> dict | None:
        with self._lock:
            p = self._db.execute("SELECT id, name FROM players WHERE id = ?", (player_id,)).fetchone()
            if not p:
                return None
            levels = self._db.execute(
                "SELECT level_id, attempts, hints_used, best_time_ms, stars, best_xp, completions FROM progress WHERE player_id = ?",
                (player_id,),
            ).fetchall()
            ach = self._db.execute(
                "SELECT achievement_id FROM achievements WHERE player_id = ? ORDER BY unlocked_at", (player_id,)
            ).fetchall()
        return {
            "id": p["id"],
            "name": p["name"],
            "xp": sum(r["best_xp"] for r in levels),
            "levels": {
                r["level_id"]: {
                    "completed": True,
                    "attempts": r["attempts"],
                    "hintsUsed": r["hints_used"],
                    "bestTimeMs": r["best_time_ms"],
                    "stars": r["stars"],
                    "bestXp": r["best_xp"],
                    "completions": r["completions"],
                }
                for r in levels
            },
            "achievements": [r["achievement_id"] for r in ach],
        }

    def completed_levels(self, player_id: str) -> set[str]:
        with self._lock:
            rows = self._db.execute("SELECT level_id FROM progress WHERE player_id = ?", (player_id,)).fetchall()
        return {r["level_id"] for r in rows}

    # -- progress ------------------------------------------------------------
    def record_progress(self, r: ProgressReport) -> None:
        """Keeps each player's best result per level."""
        with self._lock, self._db:
            self._db.execute(
                """INSERT INTO progress (player_id, level_id, attempts, hints_used, best_time_ms, stars, best_xp, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(player_id, level_id) DO UPDATE SET
                     attempts = attempts + excluded.attempts,
                     hints_used = MIN(hints_used, excluded.hints_used),
                     best_time_ms = MIN(best_time_ms, excluded.best_time_ms),
                     stars = MAX(stars, excluded.stars),
                     best_xp = MAX(best_xp, excluded.best_xp),
                     completions = completions + 1,
                     updated_at = excluded.updated_at""",
                (r.player_id, r.level_id, r.attempts, r.hints_used, r.time_ms, r.stars, r.xp, time.time()),
            )

    # -- achievements --------------------------------------------------------
    def unlock(self, player_id: str, achievement_id: str) -> bool:
        """Returns False when the player already had it (duplicates are impossible)."""
        with self._lock, self._db:
            cur = self._db.execute(
                "INSERT OR IGNORE INTO achievements (player_id, achievement_id, unlocked_at) VALUES (?, ?, ?)",
                (player_id, achievement_id, time.time()),
            )
            return cur.rowcount == 1

    # -- analytics -----------------------------------------------------------
    def add_events(self, player_id: str | None, events: list[dict]) -> int:
        now = time.time()
        with self._lock, self._db:
            self._db.executemany(
                "INSERT INTO analytics_events (player_id, event, payload, received_at) VALUES (?, ?, ?, ?)",
                [(player_id, e["event"], json.dumps(e), now) for e in events],
            )
        return len(events)

    def event_counts(self) -> dict[str, int]:
        with self._lock:
            rows = self._db.execute("SELECT event, COUNT(*) AS n FROM analytics_events GROUP BY event").fetchall()
        return {r["event"]: r["n"] for r in rows}

    # -- leaderboard ---------------------------------------------------------
    def leaderboard(self, limit: int = 10) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                """SELECT p.name, SUM(g.best_xp) AS xp, COUNT(g.level_id) AS levels
                   FROM players p JOIN progress g ON g.player_id = p.id
                   GROUP BY p.id ORDER BY xp DESC, levels DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [{"rank": i + 1, "name": r["name"], "xp": r["xp"], "levels": r["levels"]} for i, r in enumerate(rows)]
