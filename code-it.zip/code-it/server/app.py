"""CODE IT! game server: serves the built game and its small JSON API.

Standard library only (Python 3.10+), so it runs anywhere with `python run.py`.

API (all JSON):
  GET  /api/health
  GET  /api/game/config
  GET  /api/levels?page=1&pageSize=20&difficulty=1&category=css   (add full=1 for complete level data)
  GET  /api/levels/<id>
  POST /api/player            {playerId, name}
  GET  /api/player?playerId=
  POST /api/progress          {playerId, levelId, completed, attempts, hintsUsed, timeMs, score, xp}
  POST /api/achievements      {playerId, achievementId}
  POST /api/analytics/events  {events: [...]}
  GET  /api/leaderboard
"""
from __future__ import annotations

import json
import logging
import mimetypes
import sys
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from . import rules
from .db import Store

log = logging.getLogger("codeit")

API_VERSION = "1"
MAX_BODY_BYTES = 64 * 1024
WRITES_PER_MINUTE = 120  # per client IP

# The game builds player code into sandboxed srcdoc iframes, which inherit this policy,
# so inline scripts must stay allowed. The sandbox adds its own stricter policy on top.
CSP = "; ".join([
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' data: https://fonts.gstatic.com",
    "img-src 'self' data: blob: https:",
    "media-src 'self' data: https:",
    "connect-src 'self'",
    "frame-src 'self' about:",
    "frame-ancestors 'self'",
    "base-uri 'self'",
    "form-action 'none'",
])

mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/javascript", ".mjs")
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("image/svg+xml", ".svg")


@dataclass
class Game:
    web_root: Path
    store: Store
    content: dict
    level_ids: list[str] = field(init=False)
    achievement_ids: set[str] = field(init=False)
    _rate: dict = field(default_factory=lambda: defaultdict(deque))
    _rate_lock: threading.Lock = field(default_factory=threading.Lock)

    def __post_init__(self) -> None:
        self.level_ids = [lvl["id"] for lvl in self.content["levels"]]
        self.achievement_ids = {a["id"] for a in self.content.get("achievements", [])}

    def allow_write(self, ip: str) -> bool:
        now = time.monotonic()
        with self._rate_lock:
            q = self._rate[ip]
            while q and now - q[0] > 60:
                q.popleft()
            if len(q) >= WRITES_PER_MINUTE:
                return False
            q.append(now)
            return True


def level_summary(lvl: dict) -> dict:
    keys = ("id", "number", "title", "tagline", "category", "difficulty", "concepts", "parTimeSec")
    return {k: lvl[k] for k in keys if k in lvl} | {"client": lvl["client"]["name"]}


class Handler(BaseHTTPRequestHandler):
    server_version = "CodeIt/1"
    sys_version = ""
    game: Game  # set by make_server
    protocol_version = "HTTP/1.1"

    # -- plumbing -------------------------------------------------------------
    def log_message(self, fmt: str, *args) -> None:  # route through logging, never log bodies
        log.info("%s %s", self.address_string(), fmt % args)

    def _headers(self, status: int, ctype: str, length: int, extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()

    def _json(self, status: int, payload: dict, cache: str = "no-store") -> None:
        body = json.dumps(payload, separators=(",", ":")).encode()
        self._headers(status, "application/json; charset=utf-8", len(body), {"Cache-Control": cache, "X-API-Version": API_VERSION})
        if self.command != "HEAD":
            self.wfile.write(body)

    def _error(self, status: int, message: str) -> None:
        self._json(status, {"error": message})

    def _read_body(self) -> bytes:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise rules.Invalid("bad Content-Length") from None
        if length > MAX_BODY_BYTES or length < 0:
            raise rules.Invalid("request body too large")
        return self.rfile.read(length) if length else b""

    def _parse_json(self, raw: bytes) -> object:
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            raise rules.Invalid("Content-Type must be application/json")
        try:
            return json.loads(raw or b"null")
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise rules.Invalid("body is not valid JSON") from None

    # -- verbs ----------------------------------------------------------------
    def do_HEAD(self) -> None:
        self.do_GET()

    def do_GET(self) -> None:
        url = urlparse(self.path)
        if url.path.startswith("/api/"):
            return self._api_get(url.path, parse_qs(url.query))
        return self._static(url.path)

    def do_POST(self) -> None:
        url = urlparse(self.path)
        # Always consume the body first: on a kept-alive connection, unread bytes would be
        # parsed as the start of the next request.
        try:
            raw = self._read_body()
        except rules.Invalid as e:
            self.close_connection = True
            return self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, str(e))
        if not url.path.startswith("/api/"):
            return self._error(HTTPStatus.METHOD_NOT_ALLOWED, "method not allowed")
        if not self.game.allow_write(self.client_address[0]):
            return self._error(HTTPStatus.TOO_MANY_REQUESTS, "too many requests, slow down")
        key = self.headers.get("Idempotency-Key")
        if key:
            key = f"{url.path}:{key[:200]}"
            prior = self.game.store.replay(key)
            if prior:
                return self._json(prior[0], prior[1] | {"replayed": True})
        try:
            status, payload = self._api_post(url.path, self._parse_json(raw))
        except rules.Invalid as e:
            status, payload = HTTPStatus.UNPROCESSABLE_ENTITY, {"error": str(e)}
        except Exception:  # never leak internals to the client
            log.exception("POST %s failed", url.path)
            return self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "server error")
        if key and status < 500:
            self.game.store.remember(key, int(status), payload)
        self._json(status, payload)

    # -- API ------------------------------------------------------------------
    def _api_get(self, path: str, q: dict) -> None:
        g = self.game
        one = lambda k, d=None: (q.get(k) or [d])[0]  # noqa: E731
        if path == "/api/health":
            return self._json(200, {"ok": True})
        if path == "/api/game/config":
            return self._json(200, {
                "game": "code-it",
                "brand": "Web Development Services",
                "version": API_VERSION,
                "contentVersion": g.content["version"],
                "features": {"progressSync": True, "achievements": True, "analytics": True, "leaderboard": True, "serverValidation": False},
                "languages": ["en"],
                "audio": {"synthesized": True, "defaultMusic": False},
            }, cache="public, max-age=300")
        if path == "/api/levels":
            levels = g.content["levels"]
            if one("category"):
                levels = [lvl for lvl in levels if lvl["category"] == one("category")]
            if one("difficulty"):
                levels = [lvl for lvl in levels if str(lvl["difficulty"]) == one("difficulty")]
            if one("full") == "1":
                return self._json(200, {"version": g.content["version"], "levels": levels}, cache="public, max-age=300")
            try:
                page = max(1, int(one("page", "1")))
                size = min(50, max(1, int(one("pageSize", "20"))))
            except ValueError:
                return self._error(400, "page and pageSize must be numbers")
            chunk = levels[(page - 1) * size: page * size]
            return self._json(200, {
                "version": g.content["version"], "page": page, "pageSize": size, "total": len(levels),
                "levels": [level_summary(lvl) for lvl in chunk],
            }, cache="public, max-age=300")
        if path.startswith("/api/levels/"):
            lid = unquote(path.removeprefix("/api/levels/"))
            lvl = next((x for x in g.content["levels"] if x["id"] == lid), None)
            return self._json(200, lvl, cache="public, max-age=300") if lvl else self._error(404, "level not found")
        if path == "/api/player":
            try:
                pid = rules.player_id(one("playerId"))
            except rules.Invalid as e:
                return self._error(400, str(e))
            p = g.store.player(pid)
            return self._json(200, p) if p else self._error(404, "player not found")
        if path == "/api/leaderboard":
            return self._json(200, {"entries": g.store.leaderboard()}, cache="public, max-age=30")
        return self._error(404, "not found")

    def _api_post(self, path: str, body: object) -> tuple[int, dict]:
        g = self.game
        if path == "/api/player":
            if not isinstance(body, dict):
                raise rules.Invalid("body must be a JSON object")
            pid = rules.player_id(body.get("playerId"))
            g.store.upsert_player(pid, rules.display_name(body.get("name")))
            return 200, {"ok": True, "playerId": pid}
        if path == "/api/progress":
            pid = rules.player_id(body.get("playerId") if isinstance(body, dict) else None)
            g.store.ensure_player(pid)
            report = rules.progress(body, g.level_ids, g.store.completed_levels(pid))
            g.store.record_progress(report)
            return 200, {"ok": True, "player": g.store.player(pid)}
        if path == "/api/achievements":
            pid, aid = rules.achievement(body, g.achievement_ids)
            g.store.ensure_player(pid)
            return 200, {"ok": True, "unlocked": g.store.unlock(pid, aid)}
        if path == "/api/analytics/events":
            events = rules.analytics(body, g.level_ids)
            pid = None
            if events and isinstance(events[0].get("playerId"), str) and rules.PLAYER_ID.match(events[0]["playerId"]):
                pid = events[0]["playerId"]
            return 200, {"ok": True, "stored": g.store.add_events(pid, events)}
        return 404, {"error": "not found"}

    # -- static files ---------------------------------------------------------
    def _static(self, path: str) -> None:
        root = self.game.web_root
        rel = unquote(path).lstrip("/") or "index.html"
        target = (root / rel).resolve()
        if root.resolve() not in target.parents and target != root.resolve():
            return self._error(404, "not found")  # path traversal attempt
        if target.is_dir():
            target = target / "index.html"
        if not target.is_file():
            return self._error(404, "not found")
        data = target.read_bytes()
        if target.name == "index.html":
            # Tells the game this server also serves the API (see ApiClient.detect).
            data = data.replace(b"</head>", b'<meta name="codeit-api" content="same-origin" /></head>', 1)
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/json", "image/svg+xml"):
            ctype += "; charset=utf-8"
        # Hashed build assets never change; the HTML must always be fresh.
        cache = "public, max-age=31536000, immutable" if "/assets/" in f"/{rel}" else "no-cache"
        self._headers(200, ctype, len(data), {"Cache-Control": cache})
        if self.command != "HEAD":
            self.wfile.write(data)


class GameServer(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address) -> None:
        # Browsers drop connections all the time (tab closed, request aborted): not an error.
        if isinstance(sys.exc_info()[1], (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)):
            return
        super().handle_error(request, client_address)


def load_content(path: Path) -> dict:
    content = json.loads(path.read_text(encoding="utf-8"))
    if not content.get("levels"):
        raise SystemExit(f"{path} has no levels. Run `npm run build` to regenerate it.")
    return content


def make_server(host: str, port: int, web_root: Path, db_path: str, levels_path: Path) -> GameServer:
    if not (web_root / "index.html").is_file():
        raise SystemExit(f"No game build found in {web_root}. Run `npm run build` first (see README).")
    game = Game(web_root=web_root, store=Store(db_path), content=load_content(levels_path))
    handler = type("BoundHandler", (Handler,), {"game": game})
    server = GameServer((host, port), handler)
    server.game = game  # type: ignore[attr-defined]
    return server
