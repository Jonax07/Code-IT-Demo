"""Server-side checks for data the browser sends.

The browser is never trusted: these functions decide whether a progress report,
achievement or analytics batch is plausible before anything is stored.
Pure functions, no I/O, so they are easy to unit test.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

# Mirrors src/progression/scoring.ts: the most XP one level can award on a first clear.
MAX_LEVEL_XP = 100 + 50 + 30 + 40 + 20 + 25 + 30 + 20
MIN_LEVEL_TIME_MS = 1_000  # A run plus validation takes about a second; faster means a forged report.
MAX_HINTS = 4

PLAYER_ID = re.compile(r"^player_[A-Za-z0-9-]{4,40}$")
ANALYTICS_EVENTS = {
    "level_started",
    "code_run",
    "hint_used",
    "level_completed",
    "requirement_changed",
    "code_reset",
}
# Analytics must never carry player code or free text, only these fields.
ANALYTICS_FIELDS = {
    "event", "levelId", "passed", "failedChecks", "errorCount", "validationMs",
    "hintIndex", "attempts", "hintsUsed", "durationMs", "xp", "at", "playerId",
}


class Invalid(ValueError):
    """Raised with a message that is safe to show to the client."""


@dataclass(frozen=True)
class ProgressReport:
    player_id: str
    level_id: str
    attempts: int
    hints_used: int
    time_ms: int
    stars: int
    xp: int


def _int(body: dict, key: str, lo: int, hi: int) -> int:
    v = body.get(key)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
        raise Invalid(f"{key} must be a number")
    v = int(v)
    if not lo <= v <= hi:
        raise Invalid(f"{key} must be between {lo} and {hi}")
    return v


def player_id(value: Any) -> str:
    if not isinstance(value, str) or not PLAYER_ID.match(value):
        raise Invalid("playerId is missing or malformed")
    return value


def display_name(value: Any) -> str:
    if value is None:
        return "Junior Dev"
    if not isinstance(value, str):
        raise Invalid("name must be text")
    name = re.sub(r"[\x00-\x1f<>]", "", value).strip()[:40]
    return name or "Junior Dev"


def progress(body: Any, level_ids: list[str], completed_on_server: set[str]) -> ProgressReport:
    """Validates a level completion. Levels must be completed in order."""
    if not isinstance(body, dict):
        raise Invalid("body must be a JSON object")
    pid = player_id(body.get("playerId"))
    level_id = body.get("levelId")
    if level_id not in level_ids:
        raise Invalid("unknown levelId")
    if body.get("completed") is not True:
        raise Invalid("only completed levels are recorded")
    idx = level_ids.index(level_id)
    if idx > 0 and level_ids[idx - 1] not in completed_on_server:
        raise Invalid("previous level has not been completed")
    return ProgressReport(
        player_id=pid,
        level_id=level_id,
        attempts=_int(body, "attempts", 1, 10_000),
        hints_used=_int(body, "hintsUsed", 0, MAX_HINTS),
        time_ms=_int(body, "timeMs", MIN_LEVEL_TIME_MS, 7 * 24 * 3600 * 1000),
        stars=_int(body, "score", 1, 3),
        xp=_int(body, "xp", 0, MAX_LEVEL_XP),
    )


def achievement(body: Any, known: set[str]) -> tuple[str, str]:
    if not isinstance(body, dict):
        raise Invalid("body must be a JSON object")
    pid = player_id(body.get("playerId"))
    aid = body.get("achievementId")
    if aid not in known:
        raise Invalid("unknown achievementId")
    return pid, aid


def analytics(body: Any, level_ids: list[str]) -> list[dict]:
    """Keeps only known events and known fields; drops anything else silently."""
    if not isinstance(body, dict) or not isinstance(body.get("events"), list):
        raise Invalid("expected {events: [...]}")
    events = body["events"]
    if len(events) > 100:
        raise Invalid("too many events in one batch (max 100)")
    clean: list[dict] = []
    for e in events:
        if not isinstance(e, dict) or e.get("event") not in ANALYTICS_EVENTS:
            continue
        if "levelId" in e and e["levelId"] not in level_ids:
            continue
        item = {k: v for k, v in e.items() if k in ANALYTICS_FIELDS}
        if isinstance(item.get("failedChecks"), list):
            item["failedChecks"] = [str(x)[:40] for x in item["failedChecks"][:20]]
        clean.append(item)
    return clean
