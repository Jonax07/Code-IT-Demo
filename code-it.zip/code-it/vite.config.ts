import { defineConfig } from 'vite';

export default defineConfig({
  // Relative asset URLs so the build works from any sub-path (static hosts, previews).
  base: './',
  build: {
    // The Python server serves this folder; it is committed so Python-only teammates can play.
    outDir: 'web',
    emptyOutDir: true,
    // ES2020 keeps the sandbox runtime (serialized with Function#toString) free of injected helpers.
    target: 'es2020',
    rollupOptions: {
      output: {
        manualChunks: {
          editor: ['codemirror', '@codemirror/lang-html', '@codemirror/lang-css', '@codemirror/lang-javascript'],
        },
      },
    },
  },
  esbuild: { target: 'es2020' },
  test: { environment: 'node', include: ['tests/unit/**/*.test.ts'] },
});
