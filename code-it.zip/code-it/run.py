"""Start the CODE IT! game server.

    python run.py                 # http://127.0.0.1:8000
    python run.py --port 9000
    python run.py --host 0.0.0.0  # let coworkers on your network play

Needs only Python 3.10+. The game itself is prebuilt in web/ (rebuild with `npm run build`).
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from server.app import make_server  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the CODE IT! game server.")
    parser.add_argument("--host", default=os.environ.get("CODEIT_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("CODEIT_PORT", "8000")))
    parser.add_argument("--web", default=os.environ.get("CODEIT_WEB_ROOT", str(ROOT / "web")), help="folder with the built game")
    parser.add_argument("--db", default=os.environ.get("CODEIT_DB", str(ROOT / "server" / "data" / "codeit.sqlite3")))
    parser.add_argument("--open", action="store_true", help="open the game in your browser")
    parser.add_argument("--quiet", action="store_true", help="don't log every request")
    args = parser.parse_args()

    logging.basicConfig(level=logging.WARNING if args.quiet else logging.INFO, format="%(asctime)s %(message)s", datefmt="%H:%M:%S")
    server = make_server(args.host, args.port, Path(args.web), args.db, ROOT / "server" / "levels.json")
    url = f"http://{'localhost' if args.host in ('127.0.0.1', '0.0.0.0') else args.host}:{server.server_address[1]}/"
    print(f"CODE IT! by Web Development Services is running at {url}  (Ctrl+C to stop)", flush=True)
    if args.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
        server.game.store.close()


if __name__ == "__main__":
    main()
