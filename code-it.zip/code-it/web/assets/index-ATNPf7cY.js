const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./game-V1WZGzri.js","./editor-D35DPXQ7.js"])))=>i.map(i=>d[i]);
(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))n(a);new MutationObserver(a=>{for(const o of a)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&n(r)}).observe(document,{childList:!0,subtree:!0});function s(a){const o={};return a.integrity&&(o.integrity=a.integrity),a.referrerPolicy&&(o.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?o.credentials="include":a.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function n(a){if(a.ep)return;a.ep=!0;const o=s(a);fetch(a.href,o)}})();const he="modulepreload",pe=function(t,e){return new URL(t,e).href},_={},fe=function(e,s,n){let a=Promise.resolve();if(s&&s.length>0){let c=function(d){return Promise.all(d.map(p=>Promise.resolve(p).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};const r=document.getElementsByTagName("link"),i=document.querySelector("meta[property=csp-nonce]"),l=i?.nonce||i?.getAttribute("nonce");a=c(s.map(d=>{if(d=pe(d,n),d in _)return;_[d]=!0;const p=d.endsWith(".css"),f=p?'[rel="stylesheet"]':"";if(n)for(let M=r.length-1;M>=0;M--){const $=r[M];if($.href===d&&(!p||$.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${d}"]${f}`))return;const u=document.createElement("link");if(u.rel=p?"stylesheet":he,p||(u.as="script"),u.crossOrigin="",u.href=d,l&&u.setAttribute("nonce",l),document.head.appendChild(u),p)return new Promise((M,$)=>{u.addEventListener("load",M),u.addEventListener("error",()=>$(new Error(`Unable to preload CSS for ${d}`)))})}))}function o(r){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=r,window.dispatchEvent(i),!i.defaultPrevented)throw r}return a.then(r=>{for(const i of r||[])i.status==="rejected"&&o(i.reason);return e().catch(o)})};class W extends Error{}const K="codeit.syncQueue.v1",me=8e3;class ge{constructor(){this.baseUrl=null,this.stats={requests:0,failures:0,cacheHits:0,deduped:0,retries:0,queued:0,latenciesMs:[]},this.cache=new Map,this.inflight=new Map,this.flushing=!1}get online(){return this.baseUrl!==null}async detect(){if(this.baseUrl!==null)return!0;if(!document.querySelector('meta[name="codeit-api"]'))return!1;const e=new AbortController,s=setTimeout(()=>e.abort(),1500);try{const n=await fetch("./api/game/config",{signal:e.signal,headers:{Accept:"application/json"}}),a=n.ok&&(n.headers.get("content-type")||"").includes("application/json")?await n.json():null;if(a&&a.game==="code-it")return this.baseUrl=".",this.cache.set("/api/game/config",{at:performance.now(),data:a}),!0}catch{}finally{clearTimeout(s)}return!1}async get(e,s={}){if(this.baseUrl===null)throw new W("No API configured");const n=this.cache.get(e);if(n&&s.ttlMs&&performance.now()-n.at<s.ttlMs)return this.stats.cacheHits++,n.data;const a=this.inflight.get(e);if(a)return this.stats.deduped++,a;const o=this.request("GET",e,void 0,s.signal).then(r=>(this.cache.set(e,{at:performance.now(),data:r}),r)).finally(()=>this.inflight.delete(e));return this.inflight.set(e,o),o}post(e,s,n){return this.request("POST",e,s,n)}put(e,s,n){return this.request("PUT",e,s,n)}delete(e,s){return this.request("DELETE",e,void 0,s)}enqueue(e,s,n,a){const r=this.readQueue().filter(i=>i.id!==a);r.push({id:a,method:e,path:s,body:n,attempts:0}),this.writeQueue(r.slice(-500)),this.stats.queued=r.length,this.flush()}async flush(){if(!(this.baseUrl===null||this.flushing||!navigator.onLine)){this.flushing=!0;try{for(let e=this.readQueue()[0];e;e=this.readQueue()[0]){try{await this.request(e.method,e.path,e.body,void 0,e.id)}catch(n){if(!(n instanceof X&&n.status>=400&&n.status<500)){this.writeQueue(this.readQueue().map(a=>a.id===e.id?{...a,attempts:a.attempts+1}:a)),this.stats.retries++;break}}const s=e;this.writeQueue(this.readQueue().filter(n=>n.id!==s.id))}this.stats.queued=this.readQueue().length}finally{this.flushing=!1}}}async request(e,s,n,a,o){if(this.baseUrl===null)throw new W("No API configured");const r=new AbortController,i=setTimeout(()=>r.abort(),me),l=()=>r.abort();a?.addEventListener("abort",l);const c=performance.now();this.stats.requests++;try{const d=await fetch(this.baseUrl+s,{method:e,signal:r.signal,credentials:"include",headers:{Accept:"application/json",...n!==void 0?{"Content-Type":"application/json"}:{},...o?{"Idempotency-Key":o}:{}},body:n!==void 0?JSON.stringify(n):void 0});if(!d.ok)throw new X(d.status);return d.status===204?void 0:await d.json()}catch(d){throw this.stats.failures++,d}finally{clearTimeout(i),a?.removeEventListener("abort",l),this.stats.latenciesMs.push(performance.now()-c),this.stats.latenciesMs.length>100&&this.stats.latenciesMs.shift()}}readQueue(){try{return JSON.parse(localStorage.getItem(K)||"[]")}catch{return[]}}writeQueue(e){try{localStorage.setItem(K,JSON.stringify(e))}catch{}}}class X extends Error{constructor(e){super(`HTTP ${e}`),this.status=e}}const b=new ge;typeof window<"u"&&window.addEventListener("online",()=>{b.flush()});const Z="codeit.player.v1",be=()=>typeof matchMedia<"u"&&matchMedia("(prefers-reduced-motion: reduce)").matches,ye=()=>typeof matchMedia<"u"&&matchMedia("(prefers-color-scheme: light)").matches;function I(){return{id:`player_${crypto.randomUUID?crypto.randomUUID().slice(0,8):Math.random().toString(36).slice(2,10)}`,name:"Junior Dev",xp:0,levels:{},achievements:[],stats:{runs:0,errorsSeen:0,bugsFixed:0,resets:0},settings:{masterVolume:.8,effectsVolume:.9,musicVolume:.4,music:!1,soundEffects:!0,reducedMotion:be(),captions:!0,theme:ye()?"light":"dark"},version:1}}function ve(){return{completed:!1,bestXp:0,attempts:0,hintsUsed:0,bestTimeMs:null,stars:0}}class ke{constructor(){this.listeners=new Set,this.profile=this.load()}get(){return this.profile}isNew(){return this.profile.xp===0&&Object.keys(this.profile.levels).length===0}update(e,s=!1){e(this.profile),this.listeners.forEach(n=>n(this.profile)),clearTimeout(this.saveTimer),s?this.save():this.saveTimer=window.setTimeout(()=>this.save(),400)}level(e){return this.profile.levels[e]??ve()}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}reset(){const e=this.profile.settings;this.profile=I(),this.profile.settings=e,this.save(),this.listeners.forEach(s=>s(this.profile))}flush(){clearTimeout(this.saveTimer),this.save()}load(){try{const e=localStorage.getItem(Z);if(!e)return I();const s=JSON.parse(e),n=I();return{...n,...s,settings:{...n.settings,...s.settings},stats:{...n.stats,...s.stats}}}catch{return I()}}save(){try{localStorage.setItem(Z,JSON.stringify(this.profile))}catch{}}}const m=new ke;typeof window<"u"&&window.addEventListener("pagehide",()=>m.flush());const L=[{id:"hello-world",title:"Hello, World",description:"Run code for the first time.",icon:"▶"},{id:"new-bug",title:"You Invented a New Bug",description:"Cause your first JavaScript error. Breaking things is how you learn.",icon:"🐛"},{id:"bug-squasher",title:"Bug Squasher",description:"Fix code that was throwing errors.",icon:"🔨"},{id:"first-job",title:"Hired!",description:"Complete your first job.",icon:"💼"},{id:"no-hints",title:"Didn’t Need Help",description:"Complete a job without hints.",icon:"🧠"},{id:"first-try",title:"No Errors. Suspicious.",description:"Pass a job on the very first run.",icon:"🎯"},{id:"experimenter",title:"Mad Scientist",description:"Run your code 10 times in one job.",icon:"🧪"},{id:"speedrun",title:"Deployment Approved",description:"Beat a job’s deadline.",icon:"⚡"},{id:"a11y",title:"Accessibility Ally",description:"Earn an accessibility bonus.",icon:"♿"},{id:"change-request",title:"Survived the Client",description:"Handle a last-minute requirement change.",icon:"📞"},{id:"debugger",title:"Previous Developer Who?",description:"Complete every debugging job.",icon:"🕵"},{id:"launch-day",title:"Shipped It",description:"Complete the final job.",icon:"🚀"}],we=new Map(L.map(t=>[t.id,t])),U=new Set,ee={onUnlock(t){return U.add(t),()=>U.delete(t)},has(t,e){return t.achievements.includes(e)},quiet:!1,unlock(t){const e=we.get(t);return!e||m.get().achievements.includes(t)?!1:(m.update(s=>s.achievements.push(t),!0),b.enqueue("POST","/api/achievements",{playerId:m.get().id,achievementId:t},`ach:${t}`),U.forEach(s=>s(e)),!0)}};let S=!1;const D={setReducedMotion(t){S=t,document.documentElement.toggleAttribute("data-reduced-motion",t)},get reduced(){return S},shake(t,e="small"){if(S)return;const s=e==="big"?10:5;t.animate([{transform:"translate(0,0)"},{transform:`translate(${-s}px, ${s/2}px)`},{transform:`translate(${s}px, ${-s/2}px)`},{transform:`translate(${-s/2}px, 0)`},{transform:`translate(${s/2}px, 0)`},{transform:"translate(0,0)"}],{duration:360,easing:"ease-out"})},bounce(t){S||t.animate([{transform:"translateY(0) scale(1)"},{transform:"translateY(-14px) scale(1.06)"},{transform:"translateY(0) scale(0.98)"},{transform:"translateY(-5px) scale(1.02)"},{transform:"translateY(0) scale(1)"}],{duration:620,easing:"cubic-bezier(.3,1.6,.5,1)"})},pop(t){S||t.animate([{transform:"scale(.6)",opacity:0},{transform:"scale(1.08)",opacity:1},{transform:"scale(1)"}],{duration:380,easing:"cubic-bezier(.2,1.4,.4,1)"})},countUp(t,e,s,n,a){return new Promise(o=>{if(S||s===e)return t.textContent=String(s),o();const r=performance.now();let i=e;const l=c=>{const d=Math.min(1,(c-r)/n),p=1-Math.pow(1-d,3),f=Math.round(e+(s-e)*p);f!==i&&f%10===0&&a?.(),i=f,t.textContent=String(f),d<1?requestAnimationFrame(l):o()};requestAnimationFrame(l)})},confetti(t={}){if(S)return;const e=document.createElement("canvas");e.className="fx-canvas",e.setAttribute("aria-hidden","true");const s=Math.min(2,window.devicePixelRatio||1);e.width=innerWidth*s,e.height=innerHeight*s,document.body.appendChild(e);const n=e.getContext("2d");n.scale(s,s);const a=["#ff5a36","#3ddc84","#ffc53d","#4d9fff","#f472b6","#ffffff"],o=["{","}","<",">","/",";","()"],r=t.origin?.x??innerWidth/2,i=t.origin?.y??innerHeight/3,l=Array.from({length:t.count??140},(p,f)=>({x:r,y:i,vx:(Math.random()-.5)*16,vy:Math.random()*-14-4,r:Math.random()*Math.PI,vr:(Math.random()-.5)*.4,s:6+Math.random()*6,c:a[f%a.length],g:f%5===0?o[f%o.length]:null})),c=performance.now(),d=p=>{const f=p-c;n.clearRect(0,0,innerWidth,innerHeight);for(const u of l)u.vy+=.42,u.vx*=.99,u.x+=u.vx,u.y+=u.vy,u.r+=u.vr,n.save(),n.globalAlpha=Math.max(0,1-f/2400),n.translate(u.x,u.y),n.rotate(u.r),n.fillStyle=u.c,u.g?(n.font=`700 ${u.s*2.2}px "JetBrains Mono", monospace`,n.fillText(u.g,0,0)):n.fillRect(-u.s/2,-u.s/4,u.s,u.s/2),n.restore();f<2400?requestAnimationFrame(d):e.remove()};requestAnimationFrame(d)}},xe={button:"",run:"[whirr: code running]",success:"[triumphant ta-da]",failure:"[sad trombone: wah wah]",error:"[computer error beep-boop]",level_complete:"[fanfare + crowd cheering]",achievement:"[sparkly chime]",hint:"[lightbulb ding]",event:"[phone ringing urgently]",xp_tick:""},Se={button:[{f:660,t:0,d:.04,type:"square",g:.12}],xp_tick:[{f:1320,t:0,d:.025,type:"square",g:.05}],run:[{f:220,f2:880,t:0,d:.16,type:"sawtooth",g:.12}],hint:[{f:880,t:0,d:.1,type:"sine",g:.3},{f:1318,t:.09,d:.22,type:"sine",g:.25}],success:[{f:523,t:0,d:.1,type:"square",g:.16},{f:659,t:.1,d:.1,type:"square",g:.16},{f:784,t:.2,d:.1,type:"square",g:.16},{f:1046,t:.3,d:.35,type:"square",g:.18}],failure:[{f:392,f2:370,t:0,d:.28,type:"sawtooth",g:.12},{f:370,f2:349,t:.3,d:.28,type:"sawtooth",g:.12},{f:349,f2:330,t:.6,d:.28,type:"sawtooth",g:.12},{f:330,f2:262,t:.9,d:.8,type:"sawtooth",g:.13}],error:[{f:880,t:0,d:.09,type:"square",g:.12},{f:440,t:.11,d:.16,type:"square",g:.12}],level_complete:[{f:392,t:0,d:.12,type:"triangle",g:.3},{f:523,t:.12,d:.12,type:"triangle",g:.3},{f:659,t:.24,d:.12,type:"triangle",g:.3},{f:784,t:.36,d:.2,type:"triangle",g:.3},{f:659,t:.58,d:.1,type:"triangle",g:.3},{f:784,t:.68,d:.6,type:"triangle",g:.34},{f:1046,t:.68,d:.6,type:"square",g:.08}],achievement:[{f:1568,t:0,d:.08,type:"sine",g:.2},{f:2093,t:.07,d:.08,type:"sine",g:.2},{f:2637,t:.14,d:.3,type:"sine",g:.2}],event:[{f:1200,t:0,d:.06,type:"square",g:.1},{f:1e3,t:.07,d:.06,type:"square",g:.1},{f:1200,t:.14,d:.06,type:"square",g:.1},{f:1e3,t:.21,d:.06,type:"square",g:.1},{f:1200,t:.5,d:.06,type:"square",g:.1},{f:1e3,t:.57,d:.06,type:"square",g:.1},{f:1200,t:.64,d:.06,type:"square",g:.1},{f:1e3,t:.71,d:.06,type:"square",g:.1}]};class Te{constructor(){this.ctx=null,this.master=null,this.fx=null,this.musicGain=null,this.vol={master:.8,effects:.9,music:.4,effectsOn:!0,musicOn:!1,captions:!0},this.captionListener=null,this.lastPlayed=new Map}configure(e){this.vol=e,this.master&&(this.master.gain.value=e.master),this.fx&&(this.fx.gain.value=e.effects),this.musicGain&&(this.musicGain.gain.value=e.music*.25),e.musicOn?this.startMusic():this.stopMusic()}onCaption(e){this.captionListener=e}unlock(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}const e=window.AudioContext||window.webkitAudioContext;e&&(this.ctx=new e,this.master=this.ctx.createGain(),this.master.connect(this.ctx.destination),this.fx=this.ctx.createGain(),this.fx.connect(this.master),this.musicGain=this.ctx.createGain(),this.musicGain.connect(this.master),this.configure(this.vol))}play(e){const s=xe[e];if(s&&this.vol.captions&&this.captionListener?.(s),!this.vol.effectsOn||this.vol.master===0)return;const n=performance.now();if(n-(this.lastPlayed.get(e)??0)<45)return;this.lastPlayed.set(e,n),this.unlock();const a=this.ctx;if(!a||!this.fx)return;const o=a.currentTime+.01;for(const r of Se[e])this.tone(r,o,this.fx)}tone(e,s,n){const a=this.ctx,o=a.createOscillator(),r=a.createGain();o.type=e.type??"sine",o.frequency.setValueAtTime(e.f,s+e.t),e.f2&&o.frequency.linearRampToValueAtTime(e.f2,s+e.t+e.d);const i=e.g??.2;r.gain.setValueAtTime(1e-4,s+e.t),r.gain.exponentialRampToValueAtTime(i,s+e.t+.012),r.gain.exponentialRampToValueAtTime(1e-4,s+e.t+e.d),o.connect(r).connect(n),o.start(s+e.t),o.stop(s+e.t+e.d+.05)}startMusic(){if(!this.ctx||!this.musicGain||this.musicTimer)return;const e=[220,277,330,277,247,294,370,294,196,247,294,247,220,277,330,415];let s=0;const n=()=>{if(!this.ctx||!this.musicGain)return;const a=this.ctx.currentTime+.02;this.tone({f:e[s%e.length],t:0,d:.35,type:"triangle",g:.25},a,this.musicGain),s%4===0&&this.tone({f:e[s%e.length]/2,t:0,d:.9,type:"sine",g:.3},a,this.musicGain),s++};this.musicTimer=window.setInterval(n,300)}stopMusic(){clearInterval(this.musicTimer),this.musicTimer=void 0}}const g=new Te,Ee=1e4,q=[];let P=[];const te=new Set;let Y;function G(){if(Y=void 0,!P.length)return;const t=P;P=[],b.enqueue("POST","/api/analytics/events",{events:t},`an:${t[0].at}:${t.length}`)}const Ce={track(t,e){if(e){if(te.has(e))return;te.add(e)}const s={...t,at:Date.now()};q.push(s),q.length>200&&q.shift(),b.online&&(P.push({...s,playerId:m.get().id}),Y||(Y=window.setTimeout(G,Ee)))},recent(){return q},flush:G};typeof window<"u"&&document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"&&G()});const E={};let se=0,B=0,y=null,ne;const N=t=>t.length?t.reduce((e,s)=>e+s,0)/t.length:0,Me=t=>{if(!t.length)return 0;const e=[...t].sort((s,n)=>s-n);return e[Math.min(e.length-1,Math.floor(e.length*.95))]},Ae={init(){try{new PerformanceObserver(e=>se+=e.getEntries().length).observe({type:"longtask",buffered:!0})}catch{}window.addEventListener("error",()=>B++),window.addEventListener("unhandledrejection",()=>B++),window.addEventListener("keydown",t=>{t.ctrlKey&&t.shiftKey&&t.key.toLowerCase()==="d"&&(t.preventDefault(),this.toggle())}),new URLSearchParams(location.search).has("debug")&&this.toggle()},record(t,e){(E[t]??(E[t]=[])).push(e),E[t].length>50&&E[t].shift()},snapshot(){const t=performance.getEntriesByType("navigation")[0],e=E.validation??[],s=performance.memory;return{loadMs:t?Math.round(t.loadEventEnd-t.startTime):null,domInteractiveMs:t?Math.round(t.domInteractive-t.startTime):null,validationAvgMs:Math.round(N(e.map(n=>n.totalMs))),validationP95Ms:Math.round(Me(e.map(n=>n.totalMs))),executionAvgMs:Math.round(N(e.map(n=>n.executionMs))),previewAvgMs:Math.round(N((E.preview??[]).map(n=>n.renderMs))),runs:e.length,longFrames:se,gameErrors:B,heapMb:s?Math.round(s.usedJSHeapSize/1e6):null,api:{...b.stats,latenciesMs:void 0,avgLatencyMs:Math.round(N(b.stats.latenciesMs)),configured:b.online},recentEvents:Ce.recent().slice(-6).map(n=>n.event)}},toggle(){if(y){y.remove(),y=null,clearInterval(ne);return}y=document.createElement("pre"),y.className="diag-panel mono",y.setAttribute("aria-label","Developer diagnostics"),document.body.appendChild(y);const t=()=>y&&(y.textContent=`DIAGNOSTICS (Ctrl+Shift+D)
`+JSON.stringify(this.snapshot(),null,1));t(),ne=window.setInterval(t,1e3)}},Le=[{id:"html-001",number:1,title:"Pizza Panic",tagline:"A pizza place with no website. A tragedy.",category:"html",difficulty:1,client:{name:"Chef Rizzo",role:"Owner, Rizzo’s Suspiciously Enthusiastic Pizza",avatarColor:"#ff7a45"},brief:"CIAO! My pizza is the best in the world and NOBODY KNOWS. I need a homepage. A big title with the word Pizza in it! A sentence about how amazing we are! A picture of pizza! A button so people can order! Please. I am begging. The dough is getting nervous.",objective:"Structure a page with HTML elements: headings, paragraphs, images and buttons.",concepts:["<h1> headings","<p> paragraphs","<img> images","<button> buttons","alt text"],expectedMistakes:["Forgetting the closing tag","Writing the text outside the tags","Using <img> without src"],unlocks:"CSS styling",tabs:["html"],starter:{html:`<!-- JOB #1: Build Chef Rizzo a homepage. -->
<!-- Tags wrap content like this:  <h1>Hello!</h1>  -->
<!-- There's a pizza picture ready at: pizza.svg -->

<h1>Welcome</h1>
`,css:"",js:""},requirements:[{id:"h1",label:"Has a big <h1> title",fail:"There is no <h1> on the page.",tip:"Wrap your title in <h1> and </h1>.",rule:{type:"element",selector:"h1"}},{id:"h1-pizza",label:"The title mentions “Pizza”",fail:"The <h1> doesn’t say “Pizza”. Chef Rizzo is weeping.",rule:{type:"text",selector:"h1",contains:"pizza"}},{id:"p",label:"Has a <p> paragraph that brags a bit",fail:"No paragraph with at least a few words.",tip:"A paragraph is <p>Some words here</p>.",rule:{type:"text",selector:"p",minLength:10}},{id:"img",label:"Shows a picture with <img>",fail:"There’s no <img> on the page.",tip:'<img src="pizza.svg"> shows the pizza picture.',rule:{type:"element",selector:"img"}},{id:"button",label:"Has an order <button>",fail:"No <button> yet. How will people order?!",rule:{type:"element",selector:"button"}},{id:"alt",label:"Image has alt text for screen readers",fail:"Your <img> has no alt text.",tip:'Add alt="A delicious pizza" inside the <img> tag.',rule:{type:"attr",selector:"img",attr:"alt",nonEmpty:!0},bonus:"accessibility"}],hints:["HTML is made of tags. Most tags come in pairs: an opening tag like <p> and a closing tag like </p>. Whatever sits between them is the content.","You need four more kinds of tag: a paragraph (<p>), an image (<img>), a button (<button>), and your <h1> needs the word Pizza in it.",'Images are special: they have no closing tag. The src attribute tells the browser which picture to load: <img src="pizza.svg">',`Example:
<h1>Rizzo’s Pizza</h1>
<p>The cheesiest pizza in town.</p>
<img src="pizza.svg" alt="A pizza">
<button>Order now</button>`],parTimeSec:180},{id:"css-001",number:2,title:"Make It Look Professional",tagline:"Comic Sans. Yellow. Red. Wavy lines. Help.",category:"css",difficulty:1,client:{name:"Mr. Bigsby",role:"CEO, Bigsby & Sons Serious Consulting",avatarColor:"#6c7cff"},brief:"My nephew made our website. It looks like a birthday card from a clown. We are a SERIOUS consulting firm. Make it look professional. I don’t know what that means, but I will know it when I see it.",objective:"Use CSS selectors and properties to control colour, typography, spacing and borders.",concepts:["selectors","color & background-color","font-family","padding","border"],expectedMistakes:["Missing semicolon between declarations","Typos in property names","Styling the wrong selector"],unlocks:"Flexbox layout",tabs:["css","html"],starter:{html:`<header>
  <h1>Bigsby &amp; Sons</h1>
  <p>Serious consulting for serious people.</p>
</header>
<div class="card">
  <h2>Our Services</h2>
  <p>We have meetings about meetings. Professionally.</p>
  <button class="cta">Book a consultation</button>
</div>
`,css:`/* JOB #2: Make this look professional. */
/* Change the values. Run it. See what happens. */

body {
  background-color: yellow;
  font-family: "Comic Sans MS", "Comic Neue", cursive;
  color: red;
}

h1 {
  font-size: 64px;
  text-decoration: underline wavy;
}

.card {
  border: 6px dashed lime;
  padding: 0px;
}

.cta {
  padding: 2px;
}
`,js:""},requirements:[{id:"bg",label:"Page background is no longer yellow",fail:"The body background is still yellow.",tip:"Change background-color on body. Try #f4f1ea or white.",rule:{type:"style",selector:"body",prop:"background-color",check:{op:"notIn",values:["rgb(255, 255, 0)"]}}},{id:"font",label:"No more Comic Sans",fail:"The font is still Comic Sans.",tip:"Try font-family: Georgia, serif; or Arial, sans-serif;",rule:{type:"style",selector:"body",prop:"font-family",check:{op:"notContains",value:"comic"}}},{id:"color",label:"Text is not screaming red",fail:"The text colour is still red.",rule:{type:"style",selector:"body",prop:"color",check:{op:"notIn",values:["rgb(255, 0, 0)"]}}},{id:"border",label:"The card border isn’t dashed",fail:"The .card border is still dashed.",tip:"border: 1px solid #ccc; is calm and professional.",rule:{type:"style",selector:".card",prop:"border-top-style",check:{op:"not",value:"dashed"}}},{id:"padding",label:"The card has breathing room (padding ≥ 16px)",fail:"The .card padding is less than 16px, so text touches the border.",rule:{type:"style",selector:".card",prop:"padding-top",check:{op:"minPx",value:16}}},{id:"cta-pad",label:"The button is comfy to click (padding ≥ 10px)",fail:"The .cta button padding is under 10px.",rule:{type:"style",selector:".cta",prop:"padding-top",check:{op:"minPx",value:10}}}],event:{title:"THE BOSS WANTS IT IN BLUE.",from:"client",message:"Looks great. Love it. One tiny thing: make the button BLUE. Blue is the colour of trust. And money. Mostly money.",requirements:[{id:"cta-blue",label:"The .cta button background is blue",fail:"The .cta button isn’t blue yet.",tip:"background-color: #2563eb; is a trustworthy blue.",rule:{type:"style",selector:".cta",prop:"background-color",check:{op:"hue",min:190,max:250}}}]},hints:["CSS rules have a selector (what to style) and declarations (how to style it): selector { property: value; }","Every requirement is one declaration to change. Look at body, .card and .cta. Change the values that look terrible.","body needs a new background-color, font-family and color. .card needs a border that isn’t dashed and padding of at least 16px. .cta needs padding of at least 10px.",`Example:
body {
  background-color: #f4f1ea;
  font-family: Georgia, serif;
  color: #222;
}
.card { border: 1px solid #ccc; padding: 24px; }
.cta { padding: 12px 20px; }`],parTimeSec:240},{id:"layout-001",number:3,title:"Flexbox Food Truck",tagline:"Everything is stacked like a sad pancake tower.",category:"layout",difficulty:2,client:{name:"Taco Tanya",role:"Owner, The Flexible Taco",avatarColor:"#2bb673"},brief:"My menu links are stacked on top of each other like a tower of tacos about to fall over. And my three dishes are in a long line going DOWN. I want them side by side! In a ROW! Like tacos on a plate!",objective:"Use Flexbox to lay elements out in a row and space them with gap.",concepts:["display: flex","gap","flex rows"],expectedMistakes:["Putting display:flex on the children instead of the parent","Using margin instead of gap",'Misspelling "flex"'],unlocks:"JavaScript events",tabs:["css","html"],starter:{html:`<nav class="menu">
  <a href="#">Tacos</a>
  <a href="#">Burritos</a>
  <a href="#">Nachos</a>
  <a href="#">Contact</a>
</nav>

<section class="dishes">
  <div class="dish">🌮 Classic Taco</div>
  <div class="dish">🌯 Mega Burrito</div>
  <div class="dish">🧀 Nacho Mountain</div>
</section>
`,css:`/* JOB #3: Put things in ROWS with flexbox. */

body { font-family: system-ui, sans-serif; margin: 24px; background: #fff8ec; }

.menu a {
  display: block;
  padding: 8px 12px;
  color: #1a1a1a;
}

.dish {
  background: white;
  border: 2px solid #1a1a1a;
  border-radius: 10px;
  padding: 20px;
  margin-top: 16px;
}
`,js:""},requirements:[{id:"menu-flex",label:".menu uses display: flex",fail:".menu isn’t a flex container yet.",tip:"Flex goes on the PARENT: .menu { display: flex; }",rule:{type:"style",selector:".menu",prop:"display",check:{op:"equals",value:"flex"}}},{id:"menu-row",label:"All 4 menu links sit in one row",fail:"The menu links are still stacked.",rule:{type:"sameRow",selector:".menu a",min:4}},{id:"dish-row",label:"All 3 dishes sit side by side",fail:"The dishes are still stacked vertically.",tip:"Make .dishes a flex container too.",rule:{type:"sameRow",selector:".dish",min:3}},{id:"gap",label:"Dishes have a gap between them (≥ 12px)",fail:"The dishes are touching. Tacos need personal space.",tip:"gap: 16px; on the flex container adds space between children.",rule:{type:"style",selector:".dishes",prop:"column-gap",check:{op:"minPx",value:12}}}],hints:["Flexbox is turned on by the PARENT element. Its direct children then line up in a row automatically.","The parents here are .menu (for the links) and .dishes (for the dishes). Give both of them display: flex.","Once .dishes is a flex container, the gap property adds space between its children: gap: 16px;",`Example:
.menu { display: flex; }
.dishes { display: flex; gap: 16px; }`],parTimeSec:180},{id:"js-001",number:4,title:"Make The Button Do Something",tagline:"The client pressed it 47 times. Nothing happened.",category:"js",difficulty:2,client:{name:"Commander Pim",role:"Head of Rocket Stuff, Probably-Safe Space Co.",avatarColor:"#ffb020"},brief:"We have a LAUNCH button. It is big. It is red. It does NOTHING. When someone clicks it, the status message must change to say LAUNCHED. Do it before the investors come back from lunch.",objective:"Select elements with querySelector and react to clicks with addEventListener.",concepts:["variables","functions","click events","textContent"],expectedMistakes:["Calling the function instead of passing it","Wrong selector (missing #)","Spelling textContent wrong"],unlocks:"Debugging",tabs:["js","html","css"],starter:{html:`<h1>Rocket Launch Control</h1>
<div id="rocket">🚀</div>
<p id="status">Status: waiting...</p>
<button id="launch">LAUNCH</button>
`,css:`body { font-family: system-ui, sans-serif; text-align: center; padding: 24px; background: #0e1320; color: #e8ecf5; }
#rocket { font-size: 72px; transition: transform 1.2s cubic-bezier(.5,-0.3,.7,.2); }
#rocket.flying { transform: translateY(-400px) rotate(-10deg); }
#launch { font-size: 22px; font-weight: 800; padding: 14px 32px; border: 0; border-radius: 999px; background: #ff3b30; color: white; cursor: pointer; }
`,js:`// JOB #4: Make the LAUNCH button change the status text.

const launchButton = document.querySelector('#launch');
const statusText = document.querySelector('#status');

// When the button is clicked, run some code:
// launchButton.addEventListener('click', function () {
//   ...your code here...
// });
`},requirements:[{id:"listener",label:"The button has a click listener",fail:"Nothing is listening for clicks on the button.",tip:"Uncomment the addEventListener lines (remove the //).",rule:{type:"source",lang:"js",pattern:String.raw`addEventListener\s*\(\s*['"]click['"]|\.onclick\s*=`}},{id:"launched",label:"Clicking LAUNCH makes the status say “LAUNCHED”",fail:"After a click, the status text doesn’t say LAUNCHED.",tip:"Inside the listener: statusText.textContent = 'LAUNCHED!';",rule:{type:"interact",steps:[{do:"click",selector:"#launch"}],expect:[{selector:"#status",textContains:"launched"}]}},{id:"no-errors",label:"No JavaScript errors",fail:"Your JavaScript crashed. Check the console below.",rule:{type:"noRuntimeErrors"}}],event:{title:"THE CLIENT CHANGED THE REQUIREMENTS.",from:"client",message:"Great, the text changes. But the ROCKET doesn’t move! When I click LAUNCH, the rocket should fly. Dex says the CSS already has a class called flying. Whatever that means.",requirements:[{id:"flying",label:"Clicking LAUNCH adds the class “flying” to #rocket",fail:"#rocket doesn’t get the flying class after a click.",tip:"Select the rocket, then rocket.classList.add('flying');",rule:{type:"interact",steps:[{do:"click",selector:"#launch"}],expect:[{selector:"#rocket",hasClass:"flying"}]}}]},hints:["JavaScript can wait for something to happen (an event) and then run a function. A click is an event.","addEventListener takes two things: the event name ('click') and a function to run. The starter code has one ready, it’s just commented out.","Inside the function, change the text: statusText.textContent = 'LAUNCHED!';",`Example:
launchButton.addEventListener('click', function () {
  statusText.textContent = 'LAUNCHED!';
});`],parTimeSec:180},{id:"debug-001",number:5,title:"The Previous Developer",tagline:"He left one comment: // DO NOT TOUCH THIS",category:"debug",difficulty:2,client:{name:"Dex",role:"Senior Developer, tired",avatarColor:"#8b5cf6"},brief:"The last developer quit, moved to a farm, and left us this. The title should be orange, the button should be dark with white text, and clicking it should confirm the order. None of that works. There are bugs in the HTML, the CSS AND the JavaScript. Yes, you have to touch it.",objective:"Find and fix bugs in HTML, CSS and JavaScript using error messages and the preview.",concepts:["unclosed tags","selector typos","CSS syntax","JS reference errors"],expectedMistakes:["Only fixing the first bug","Ignoring the console","Deleting code instead of fixing it"],unlocks:"Mini projects",tabs:["html","css","js"],isDebug:!0,starter:{html:`<header>
  <h1 class="title">Snack Overflow</h1>
  <p>The <strong>#1 snack delivery for developers</p>
</header>

<main>
  <button id="order">Order snacks</button>
  <p id="result"></p>
</main>
`,css:`body { font-family: system-ui, sans-serif; padding: 24px; }

.titel {
  color: #ff5a36;
}

#order {
  background: #222 color: white;
  padding 12px 20px;
  border: 0;
  border-radius: 8px;
}
`,js:`// DO NOT TOUCH THIS
// (you are going to have to touch this)

const orderButton = documnet.querySelector('#order');
const result = document.querySelector('#result');

orderButton.addEventListener('click', function () {
  result.textContent = 'Snacks are on the way!';
});
`},requirements:[{id:"html-ok",label:"Every HTML tag is closed",fail:"An HTML tag is never closed, so it swallows everything after it.",tip:"Look for red marks in the HTML tab.",rule:{type:"htmlBalanced"}},{id:"title-orange",label:"The title is orange (#ff5a36)",fail:"The .title isn’t orange. The CSS selector might not match anything.",tip:"Compare the class in the HTML with the selector in the CSS. Letter by letter.",rule:{type:"style",selector:".title",prop:"color",check:{op:"equals",value:"rgb(255, 90, 54)"}}},{id:"btn-white",label:"The button text is white",fail:"The button text isn’t white. That CSS line is broken.",tip:"Every declaration needs its own semicolon.",rule:{type:"style",selector:"#order",prop:"color",check:{op:"equals",value:"rgb(255, 255, 255)"}}},{id:"btn-pad",label:"The button has padding (≥ 12px)",fail:"The button padding isn’t applied.",tip:"Properties need a colon: padding: 12px;",rule:{type:"style",selector:"#order",prop:"padding-top",check:{op:"minPx",value:12}}},{id:"no-errors",label:"No JavaScript errors",fail:"The JavaScript crashes before it can do anything.",tip:"Read the red error in the console. Which word is misspelled?",rule:{type:"noRuntimeErrors"}},{id:"click",label:"Clicking the button confirms the order",fail:"Clicking the button doesn’t show “Snacks are on the way!”.",rule:{type:"interact",steps:[{do:"click",selector:"#order"}],expect:[{selector:"#result",textContains:"on the way"}]}}],hints:["Debugging tip: fix one bug at a time, run, repeat. Error messages tell you the line number. Red and yellow squiggles in the editor point at problems too.","There are four bugs: one unclosed HTML tag, one misspelled CSS selector, one broken CSS rule block (two mistakes), and one misspelled word in the JavaScript.","HTML: <strong> needs a </strong>. CSS: .titel should be .title; the #order block is missing a semicolon and a colon. JS: documnet is not a word the browser knows.",`Example fixes:
<p>The <strong>#1 snack delivery</strong> for developers</p>
.title { color: #ff5a36; }
background: #222;
color: white;
padding: 12px 20px;
const orderButton = document.querySelector('#order');`],parTimeSec:300},{id:"project-001",number:6,title:"Profile of a Legendary Cat",tagline:"Sir Whiskerton demands an online presence.",category:"project",difficulty:2,client:{name:"Sir Whiskerton",role:"Cat. Influencer. Legend.",avatarColor:"#f59e0b"},brief:"Mrow. I require a profile card. It must show my portrait, my name in a heading, a list of at least three of my accomplishments, and a link to my fan club. Make it look expensive. I am, after all, a very expensive cat.",objective:"Combine HTML structure and CSS styling to build a complete component.",concepts:["containers","lists (<ul>, <li>)","links","padding & border-radius"],expectedMistakes:["Putting elements outside the .profile container","Using <li> without <ul>","Links with no href"],unlocks:"Product cards",tabs:["html","css"],starter:{html:`<!-- JOB #6: A profile card for Sir Whiskerton. -->
<!-- Put EVERYTHING inside the .profile box. -->
<!-- A portrait is ready at: cat.svg -->

<div class="profile">

</div>
`,css:`body { font-family: system-ui, sans-serif; background: #efe7da; display: grid; place-items: center; min-height: 100vh; margin: 0; }

.profile {
  background: white;
  max-width: 320px;
}
`,js:""},requirements:[{id:"img",label:"The card shows a portrait",fail:"No <img> inside .profile.",rule:{type:"element",selector:".profile img"}},{id:"name",label:"A heading with the cat’s name",fail:"No heading (h1, h2 or h3) with a name inside .profile.",rule:{type:"text",selector:".profile h1, .profile h2, .profile h3",minLength:3}},{id:"list",label:"A list of 3+ accomplishments",fail:"Need a list with at least 3 <li> items inside .profile.",tip:"A list is <ul> with <li> items inside it.",rule:{type:"element",selector:".profile ul li, .profile ol li",min:3}},{id:"link",label:"A link to the fan club",fail:"No link with an href inside .profile.",tip:'<a href="https://example.com">Fan club</a>',rule:{type:"attr",selector:".profile a",attr:"href",nonEmpty:!0}},{id:"padding",label:"The card has padding (≥ 16px)",fail:".profile needs at least 16px of padding.",rule:{type:"style",selector:".profile",prop:"padding-top",check:{op:"minPx",value:16}}},{id:"radius",label:"Rounded corners (≥ 8px). Expensive.",fail:".profile needs a border-radius of at least 8px.",rule:{type:"style",selector:".profile",prop:"border-top-left-radius",check:{op:"minPx",value:8}}},{id:"alt",label:"Portrait has alt text",fail:"The portrait has no alt text.",rule:{type:"attr",selector:".profile img",attr:"alt",nonEmpty:!0},bonus:"accessibility"}],hints:["A card is just a container element with other elements inside it. The .profile div is your container.",'Inside .profile you need: an <img>, a heading like <h2>, a <ul> with three <li>, and an <a href="...">. Then style .profile in the CSS.',"In the CSS, add padding: 24px; and border-radius: 16px; to the .profile rule.",`Example:
<div class="profile">
  <img src="cat.svg" alt="Sir Whiskerton">
  <h2>Sir Whiskerton</h2>
  <ul>
    <li>Napped 20 hours</li>
    <li>Knocked over a vase</li>
    <li>Ignored a laser</li>
  </ul>
  <a href="https://example.com">Fan club</a>
</div>`],parTimeSec:300},{id:"project-002",number:7,title:"The Sock 3000",tagline:"A revolutionary sock needs a product card.",category:"project",difficulty:2,client:{name:"Vera Vance",role:"Founder, Sockify (disrupting feet)",avatarColor:"#ec4899"},brief:"The Sock 3000 is not a sock. It’s a lifestyle. I need a product card: price with a dollar sign, rounded corners, and an Add to cart button that actually counts how many socks are in the cart. Two clicks, two socks. That’s the business model.",objective:"Combine HTML, CSS and JavaScript state: a variable that changes and updates the page.",concepts:["state in a variable","incrementing numbers","updating the DOM","component styling"],expectedMistakes:["Declaring the counter inside the click handler","Using = instead of += 1","Forgetting to update textContent"],unlocks:"Responsive layout",tabs:["html","css","js"],starter:{html:`<p class="cart">🛒 Cart: <span id="cart-count">0</span></p>

<div class="card">
  <img src="sock.svg" alt="The Sock 3000">
  <h2>The Sock 3000</h2>
  <!-- Add a price with class "price" here -->
  <button id="add">Add to cart</button>
</div>
`,css:`body { font-family: system-ui, sans-serif; background: #f6f3ff; padding: 24px; }
.card { background: white; max-width: 280px; padding: 20px; }
.card img { width: 100%; }
`,js:`// JOB #7: Count socks in the cart.
const addButton = document.querySelector('#add');
const cartCount = document.querySelector('#cart-count');

let count = 0;

// When #add is clicked: add 1 to count, then show it in #cart-count
`},requirements:[{id:"price",label:"A .price that shows a $ amount",fail:'No element with class "price" containing a $.',tip:'<p class="price">$30</p>',rule:{type:"text",selector:".card .price",contains:"$"}},{id:"radius",label:"The card has rounded corners (≥ 8px)",fail:".card corners aren’t rounded.",rule:{type:"style",selector:".card",prop:"border-top-left-radius",check:{op:"minPx",value:8}}},{id:"one",label:"One click puts 1 sock in the cart",fail:"After one click, the cart doesn’t show 1.",rule:{type:"interact",steps:[{do:"click",selector:"#add"}],expect:[{selector:"#cart-count",textContains:"1"}]}},{id:"two",label:"Two clicks put 2 socks in the cart",fail:"After two clicks, the cart doesn’t show 2.",tip:"Declare count OUTSIDE the click function so it remembers.",rule:{type:"interact",steps:[{do:"click",selector:"#add"},{do:"click",selector:"#add"}],expect:[{selector:"#cart-count",textContains:"2"}]}},{id:"no-errors",label:"No JavaScript errors",fail:"Your JavaScript crashed. Check the console.",rule:{type:"noRuntimeErrors"}}],event:{title:"THE CLIENT SAYS: MAKE IT POP.",from:"client",message:"It’s good. It’s fine. But it doesn’t POP. You know? It needs to POP. Like it’s floating off the page. Give it a shadow or something. Pop!",requirements:[{id:"shadow",label:"The card pops off the page (box-shadow)",fail:"The .card has no box-shadow.",tip:"box-shadow: 0 10px 30px rgba(0,0,0,.15);",rule:{type:"style",selector:".card",prop:"box-shadow",check:{op:"not",value:"none"}}}]},hints:["State is information your page remembers, like how many socks are in the cart. It lives in a variable that changes over time.","Listen for clicks on addButton. In the handler, increase count by 1, then put the new number into cartCount.textContent.","count = count + 1; (or count++) increases it. cartCount.textContent = count; shows it.",`Example:
addButton.addEventListener('click', function () {
  count = count + 1;
  cartCount.textContent = count;
});
And in HTML: <p class="price">$30</p>. In CSS: .card { border-radius: 16px; }`],parTimeSec:300},{id:"layout-002",number:8,title:"Phone Emergency",tagline:"The site explodes sideways on phones.",category:"layout",difficulty:3,client:{name:"QA Tina",role:"QA Tester. Has 14 phones.",avatarColor:"#14b8a6"},brief:"I opened the site on my phone and had to scroll SIDEWAYS. Sideways! Like a crab! On desktop the three features should stay side by side. On a phone (375px wide) they must stack and nothing should stick out. I will be testing on all 14 phones.",objective:"Build a responsive layout with a media query that changes the layout on small screens.",concepts:["@media queries","flex-direction","fixed vs flexible widths","viewport"],expectedMistakes:["Media query with the wrong comparison (min vs max)","Forgetting the fixed width still applies","Missing braces around the media block"],unlocks:"Advanced debugging",tabs:["css","html"],starter:{html:`<header><h1>Crab-Free Websites Inc.</h1></header>
<section class="features">
  <div class="feature">⚡ Fast</div>
  <div class="feature">🔒 Secure</div>
  <div class="feature">🦀 Zero sideways scrolling</div>
</section>
`,css:`/* JOB #8: Make it work on a 375px wide phone. */
body { font-family: system-ui, sans-serif; margin: 0; padding: 16px; }

.features {
  display: flex;
  gap: 16px;
}

.feature {
  width: 300px;
  flex-shrink: 0;
  padding: 24px;
  background: #e7f7f4;
  border-radius: 12px;
  box-sizing: border-box;
}

/* Styles for phones go inside a media query: */
/* @media (max-width: 600px) { ... } */
`,js:""},requirements:[{id:"desktop-row",label:"Desktop (1024px): features side by side",fail:"On desktop the features aren’t in one row anymore.",rule:{type:"sameRow",selector:".feature",min:3},viewport:1024},{id:"phone-stack",label:"Phone (375px): features stack vertically",fail:"On a 375px phone the features are still side by side.",tip:"In the media query: .features { flex-direction: column; }",rule:{type:"stacked",selector:".feature",min:3},viewport:375},{id:"phone-fit",label:"Phone (375px): no sideways scrolling",fail:"On a 375px phone the page is wider than the screen.",tip:"A 300px feature + padding is fine, but check for anything with a fixed width.",rule:{type:"noOverflow"},viewport:375},{id:"media",label:"Uses a @media query",fail:"There’s no @media query in the CSS.",rule:{type:"source",lang:"css",pattern:String.raw`@media[^{]*\(\s*max-width|@media[^{]*\(\s*min-width|@media[^{]*width\s*[<>]`}}],hints:['A media query is CSS that only applies when the screen matches a condition, like "narrower than 600px".',"Write @media (max-width: 600px) { ... } and put rules inside it that change the .features layout for phones.","Inside the media query, set .features { flex-direction: column; } and make .feature { width: 100%; } so they fit.",`Example:
@media (max-width: 600px) {
  .features { flex-direction: column; }
  .feature { width: 100%; }
}`],parTimeSec:300},{id:"debug-002",number:9,title:"JavaScript Says: Absolutely Not",tagline:"The to-do app does not do.",category:"debug",difficulty:3,client:{name:"Dex",role:"Senior Developer, even more tired",avatarColor:"#8b5cf6"},brief:"Our to-do app crashes on load. When it doesn’t crash, it adds a mystery “undefined” task. And it lets you add empty tasks. There are three bugs. They are all JavaScript. They are all classic. Find them.",objective:"Debug JavaScript logic: comparisons, function references and loop boundaries.",concepts:["= vs ===","passing vs calling functions","off-by-one loops","arrays"],expectedMistakes:["Fixing the crash but not the logic","Changing const to let instead of fixing the comparison","Deleting the loop"],unlocks:"The final project",tabs:["js","html"],isDebug:!0,starter:{html:`<h1>Get Stuff Done™</h1>
<input id="task" placeholder="New task">
<button id="add">Add</button>
<ul id="list"></ul>
<p id="count">0 tasks</p>
`,css:"body { font-family: system-ui, sans-serif; padding: 24px; }",js:`const input = document.querySelector('#task');
const addButton = document.querySelector('#add');
const list = document.querySelector('#list');
const count = document.querySelector('#count');

let tasks = [];

function addTask() {
  const text = input.value.trim();
  if (text = '') {
    return;
  }
  tasks.push(text);
  render();
  input.value = '';
}

function render() {
  list.innerHTML = '';
  for (let i = 0; i <= tasks.length; i++) {
    const li = document.createElement('li');
    li.textContent = tasks[i];
    list.appendChild(li);
  }
  count.textContent = tasks.length + ' tasks';
}

addButton.addEventListener('click', addTask());
`},requirements:[{id:"no-errors",label:"The app loads without crashing",fail:"JavaScript throws an error as soon as the page loads.",tip:"Does addEventListener get the function, or the result of calling it?",rule:{type:"noRuntimeErrors"}},{id:"adds",label:"Adding “Feed the cat” shows exactly 1 task",fail:"Adding one task doesn’t show exactly one item in the list.",tip:'If you see "undefined", count your loop steps. How many items does an array of 1 have?',rule:{type:"interact",steps:[{do:"type",selector:"#task",value:"Feed the cat"},{do:"click",selector:"#add"}],expect:[{selector:"#list li",count:1},{selector:"#list",textContains:"Feed the cat"}]}},{id:"empty",label:"Empty tasks are ignored",fail:"Clicking Add with an empty box still adds something.",tip:"= assigns a value. === compares values.",rule:{type:"interact",steps:[{do:"type",selector:"#task",value:"   "},{do:"click",selector:"#add"}],expect:[{selector:"#list li",count:0}]}},{id:"two",label:"Two tasks → counter says 2",fail:"After adding two tasks the list or counter is wrong.",rule:{type:"interact",steps:[{do:"type",selector:"#task",value:"Nap"},{do:"click",selector:"#add"},{do:"type",selector:"#task",value:"Snack"},{do:"click",selector:"#add"}],expect:[{selector:"#list li",count:2},{selector:"#count",textContains:"2"}]}}],hints:["Three classic bugs: a comparison that isn’t a comparison, a function that runs too early, and a loop that goes one step too far.","Look at the if statement in addTask, the last line (addEventListener), and the for loop condition in render.","if (text === '') compares. addEventListener('click', addTask) passes the function without calling it. i < tasks.length stops at the last item.",`Example fixes:
if (text === '') {
for (let i = 0; i < tasks.length; i++) {
addButton.addEventListener('click', addTask);`],parTimeSec:360},{id:"final-001",number:10,title:"Launch Day",tagline:"Build a whole website. From scratch. Today.",category:"project",difficulty:3,client:{name:"Mr. Bigsby",role:"CEO, now also founder of NapPod Inc.",avatarColor:"#6c7cff"},brief:"I have a new startup: NapPod. Pods. For napping. The website launches TODAY. It needs: a nav with at least 3 links, a big headline, three feature cards that sit side by side on desktop and stack on phones, and a dark mode button because apparently everybody wants that now. No sideways scrolling. Tina will check.",objective:"Combine semantic HTML, responsive CSS and JavaScript interaction in one finished page.",concepts:["everything so far"],expectedMistakes:["Toggling the class on the wrong element","Media query that also breaks desktop","Forgetting the id on the button"],unlocks:"Free build mode (coming soon)",tabs:["html","css","js"],starter:{html:`<!-- FINAL JOB: NapPod launch site. -->
<!-- You need: nav with 3+ links, an <h1>, 3 elements with class="card", -->
<!-- and a <button id="theme-toggle"> for dark mode. Image ready: nappod.svg -->

<header>
  <nav>

  </nav>
</header>

<main>

</main>
`,css:`body { font-family: system-ui, sans-serif; margin: 0; padding: 16px; }
body.dark { background: #111; color: #eee; }
`,js:`// Clicking #theme-toggle should toggle the class "dark" on <body>.
`},requirements:[{id:"nav",label:"Nav with at least 3 links",fail:"Need at least 3 <a> links inside <nav>.",rule:{type:"element",selector:"nav a",min:3}},{id:"h1",label:"A headline (<h1>)",fail:"No <h1> with text.",rule:{type:"text",selector:"h1",minLength:3}},{id:"cards",label:'3 feature cards (class="card")',fail:'Need at least 3 elements with class "card".',rule:{type:"element",selector:".card",min:3}},{id:"cards-row",label:"Desktop: cards side by side",fail:"On desktop (1024px) the cards aren’t in one row.",rule:{type:"sameRow",selector:".card",min:3},viewport:1024},{id:"cards-stack",label:"Phone: cards stack",fail:"On a phone (375px) the cards aren’t stacked.",rule:{type:"stacked",selector:".card",min:3},viewport:375},{id:"no-scroll",label:"Phone: no sideways scrolling",fail:"On a phone (375px) the page is wider than the screen.",rule:{type:"noOverflow"},viewport:375},{id:"dark",label:"Dark mode button toggles body.dark",fail:'Clicking #theme-toggle doesn’t add the class "dark" to <body>.',tip:"document.body.classList.toggle('dark')",rule:{type:"interact",steps:[{do:"click",selector:"#theme-toggle"}],expect:[{selector:"body",hasClass:"dark"}]}},{id:"no-errors",label:"No JavaScript errors",fail:"Your JavaScript crashed. Check the console.",rule:{type:"noRuntimeErrors"}},{id:"alt",label:"All images have alt text",fail:"An image is missing alt text.",rule:{type:"attr",selector:"img",attr:"alt",nonEmpty:!0},bonus:"accessibility"}],hints:["Break it into pieces and run after each one: nav, headline, cards, layout, then dark mode. The checklist shows what’s left.",'Cards: put 3 <div class="card"> inside a wrapper, make the wrapper display: flex, then use a media query to switch to flex-direction: column on small screens.',"Dark mode: select the button with document.querySelector('#theme-toggle') and in its click listener call document.body.classList.toggle('dark').",`Example skeleton:
<nav><a href="#">Home</a><a href="#">Pods</a><a href="#">Nap</a></nav>
<h1>Nap anywhere.</h1>
<div class="cards"><div class="card">Quiet</div><div class="card">Comfy</div><div class="card">Portable</div></div>
<button id="theme-toggle">Dark mode</button>

.cards { display: flex; gap: 16px; }
@media (max-width: 600px) { .cards { flex-direction: column; } }`],parTimeSec:600}],$e="2026.09.1";let T=Le;const w={all(){return T},get(t){return T.find(e=>e.id===t)},next(t){const e=T.findIndex(s=>s.id===t);return e>=0?T[e+1]:void 0},isUnlocked(t,e){const s=T.findIndex(n=>n.id===t);return s===0||s>0&&e(T[s-1].id)},async refresh(t){try{const e=await b.get(`/api/levels?full=1&version=${$e}`,{ttlMs:6e5,signal:t});Array.isArray(e.levels)&&e.levels.length&&(T=e.levels)}catch(e){e instanceof W||console.warn("[levels] using bundled levels",e)}}};function Qe(t){const e=[{key:"base",label:"Job complete",xp:100}];if(t.failedRuns===0&&e.push({key:"first",label:"First-try bonus",xp:50}),t.hintsUsed===0&&e.push({key:"nohint",label:"No-hint bonus",xp:30}),(t.isDebug||t.sawErrors)&&e.push({key:"debug",label:t.isDebug?"Bug squasher bonus":"Broke it, fixed it",xp:40}),t.runs>=4&&e.push({key:"explore",label:"Experimenter bonus",xp:20}),t.durationMs<=t.parTimeSec*1e3&&e.push({key:"speed",label:"Beat the deadline",xp:25}),t.bonusPassed.accessibility&&e.push({key:"a11y",label:"Accessibility bonus",xp:30}),t.bonusPassed.performance&&e.push({key:"perf",label:"Performance bonus",xp:20}),!t.firstClear){for(const a of e)a.xp=Math.round(a.xp/2);e.push({key:"replay",label:"Replay (half XP)",xp:0})}const s=e.reduce((a,o)=>a+o.xp,0),n=1+(t.failedRuns===0?1:0)+(t.hintsUsed===0?1:0);return{lines:e,total:s,stars:n}}const ae=["Intern","Junior Dev","Bug Wrangler","Code Wizard","Senior Dev","Tech Lead","Legendary Dev"],z=350;function V(t){const e=Math.floor(t/z)+1;return{rank:e,title:ae[Math.min(e-1,ae.length-1)],into:t%z,needed:z}}const Ie={byte:{id:"byte",name:"BYTE",role:"Your computer. Emotionally invested.",color:"#3ddc84"},dex:{id:"dex",name:"Dex",role:"Senior Developer. Has seen things.",color:"#8b5cf6"},tina:{id:"tina",name:"QA Tina",role:"QA Tester. Breaks everything.",color:"#14b8a6"}},qe=t=>({neutral:'<path d="M38 66 h24" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>',happy:'<path d="M34 62 q16 18 32 0" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>',sad:'<path d="M36 72 q14 -14 28 0" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>',shocked:'<ellipse cx="50" cy="68" rx="7" ry="9" fill="currentColor"/>',smug:'<path d="M38 66 q14 6 26 -6" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>'})[t],Ne=t=>t==="happy"?'<path d="M30 46 q6 -8 12 0 M58 46 q6 -8 12 0" stroke="currentColor" stroke-width="5" stroke-linecap="round" fill="none"/>':t==="sad"?'<path d="M30 42 l12 4 M70 42 l-12 4" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="36" cy="50" r="4" fill="currentColor"/><circle cx="64" cy="50" r="4" fill="currentColor"/>':t==="shocked"?'<circle cx="36" cy="46" r="7" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="64" cy="46" r="7" fill="none" stroke="currentColor" stroke-width="4"/>':t==="smug"?'<path d="M30 46 h12 M58 46 h12" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>':'<circle cx="36" cy="46" r="5" fill="currentColor"/><circle cx="64" cy="46" r="5" fill="currentColor"/>';function H(t,e,s){const n=s??(t==="client"?"#6c7cff":Ie[t].color),a=Ne(e)+qe(e);return t==="byte"?`<svg viewBox="0 0 100 100" aria-hidden="true" class="portrait" style="color:${n}">
      <rect x="8" y="12" width="84" height="68" rx="10" fill="#10141b" stroke="${n}" stroke-width="4"/>
      <rect x="16" y="20" width="68" height="52" rx="4" fill="#0b0f14"/>
      <g transform="translate(0,-4)"><g class="byte-face">${a}</g></g>
      <rect class="byte-scan" x="16" y="20" width="68" height="6" fill="${n}" opacity=".08"/>
      <rect x="38" y="80" width="24" height="8" fill="${n}"/><rect x="28" y="88" width="44" height="6" rx="3" fill="${n}"/>
    </svg>`:`<svg viewBox="0 0 100 100" aria-hidden="true" class="portrait" style="color:#1a1a1a">
    <circle cx="50" cy="54" r="38" fill="${n}"/>
    <circle cx="50" cy="52" r="30" fill="#ffe2c8"/>
    ${t==="dex"?'<path d="M22 36 q4 -26 30 -24 q26 0 28 26 q-10 -10 -28 -10 q-18 0 -30 8z" fill="#2a1f3d"/><rect x="26" y="40" width="20" height="13" rx="4" fill="none" stroke="#1a1a1a" stroke-width="3"/><rect x="54" y="40" width="20" height="13" rx="4" fill="none" stroke="#1a1a1a" stroke-width="3"/><path d="M46 46 h8" stroke="#1a1a1a" stroke-width="3"/>':t==="tina"?'<path d="M18 50 q0 -40 32 -40 q32 0 32 40 l-6 0 q0 -30 -26 -30 q-26 0 -26 30z" fill="#0f3d38"/><rect x="12" y="44" width="10" height="18" rx="4" fill="#1a1a1a"/><rect x="78" y="44" width="10" height="18" rx="4" fill="#1a1a1a"/><path d="M84 62 q0 16 -18 18" stroke="#1a1a1a" stroke-width="3" fill="none"/>':'<path d="M24 34 q26 -22 52 0 v-6 q-26 -18 -52 0z" fill="#1a1a1a"/>'}
    ${a}
  </svg>`}const Oe=t=>t[Math.floor(Math.random()*t.length)],Pe={success:["IT WORKS!","WHO GAVE YOU PERMISSION TO BE THIS GOOD?","THE WEBSITE LIVES!","NO ERRORS. SUSPICIOUS.","DEPLOYMENT APPROVED.","YOU ACTUALLY FIXED IT."],failure:["Well... the website has chosen violence.","Close! The browser disagrees on a few things.","404: Your idea was found. Your implementation was not.","Not yet. But you’re closer than you were.","The website says: “almost”."],jsError:["JavaScript says: absolutely not.","Congratulations. You invented a new bug.","The console is screaming. Let’s read what it says."],cssBroken:["CSS has entered another dimension.","Your CSS is having a little moment."],timeout:["Your code got stuck in a loop forever. I pulled the plug.","That code ran... and ran... and ran. Infinite loop?"],partial:["Getting there! Look at those green checks.","Progress! A few more to go."],hint:["Psst. Here’s a clue.","Okay, a little help. Don’t tell the client."],idle:["Try something. Run it. See what happens.","Breaking things is allowed. Encouraged, even.","Press RUN whenever you like. There’s no penalty."],dexStart:["Remember: read the error message. It’s trying to help.","Everyone breaks things. The pros just fix them faster."],tinaStart:["I’ll be testing this. On everything. Good luck."]},De=t=>Oe(Pe[t]),h=t=>t.replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function R(t,e={},s=""){const n=document.createElement(t);for(const[a,o]of Object.entries(e))n.setAttribute(a,o);return s&&(n.innerHTML=s),n}const x=(t,e=document)=>{const s=e.querySelector(t);if(!s)throw new Error(`Missing element: ${t}`);return s};function j(t,e){const s=document.activeElement;document.body.appendChild(t);const n=()=>Array.from(t.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')).filter(i=>!i.hasAttribute("disabled")),a=i=>{if(i.key==="Escape"&&t.dataset.dismissable!=="false"&&(i.preventDefault(),r()),i.key==="Tab"){const l=n();if(!l.length)return;const c=l[0],d=l[l.length-1];i.shiftKey&&document.activeElement===c?(i.preventDefault(),d.focus()):!i.shiftKey&&document.activeElement===d&&(i.preventDefault(),c.focus())}};t.addEventListener("keydown",a),requestAnimationFrame(()=>(t.querySelector("[autofocus]")??n()[0])?.focus());let o=!1;const r=()=>{o||(o=!0,t.removeEventListener("keydown",a),t.remove(),s?.focus?.(),e?.())};return r}function He(t){const e=V(t),s=Math.round(e.into/e.needed*100);return`<div class="rank" title="${t} XP total">
    <span class="rank-no mono" aria-hidden="true">LV${e.rank}</span>
    <div class="rank-text"><span class="rank-title">${e.title}</span>
      <span class="rank-track" role="progressbar" aria-label="XP to next rank" aria-valuemin="0" aria-valuemax="${e.needed}" aria-valuenow="${e.into}"><span class="rank-fill" style="width:${s}%"></span></span>
    </div>
    <span class="rank-xp mono">${t} XP</span>
  </div>`}const le=(t,e=3)=>`<span class="stars" aria-label="${t} of ${e} stars">${Array.from({length:e},(s,n)=>`<span class="star${n<t?" on":""}" aria-hidden="true">★</span>`).join("")}</span>`,ie=["It’s perfect. I’m crying a little.","You are hired. Again. Forever.","This is exactly what I imagined. Probably.","I will tell everyone about you. Everyone."];function _e(t,e){const s=t.event,n=R("div",{class:"overlay",role:"dialog","aria-modal":"true","aria-labelledby":"ev-title","data-dismissable":"false"});n.innerHTML=`
    <div class="modal event-modal">
      <div class="ringing mono" aria-hidden="true">📞 INCOMING CHANGE REQUEST</div>
      <h2 id="ev-title" class="event-title">${h(s.title)}</h2>
      <div class="event-from">
        <div class="avatar">${H("client","shocked",t.client.avatarColor)}</div>
        <blockquote><p>${h(s.message)}</p><cite>${h(t.client.name)}</cite></blockquote>
      </div>
      <div class="group-label mono">NEW REQUIREMENT</div>
      <ul class="checks">${s.requirements.map(o=>`<li class="check pending"><span class="mark" aria-hidden="true">+</span><span class="label">${h(o.label)}</span></li>`).join("")}</ul>
      <p class="fine">Real clients do this constantly. Your code still works. You just need to change it a little.</p>
      <div class="modal-actions"><button class="btn-primary" type="button" autofocus data-ok>Ugh. Fine. On it.</button></div>
    </div>`;const a=j(n,e);D.shake(x(".modal",n),"big"),x("[data-ok]",n).addEventListener("click",()=>{g.play("button"),a()})}function Ke(t){const e=Math.floor(t.durationMs/6e4),s=Math.round(t.durationMs%6e4/1e3),n=m.get().xp,a=V(t.prevXp),o=V(n),r=L.filter(c=>t.achievements.includes(c.id)),i=R("div",{class:"overlay",role:"dialog","aria-modal":"true","aria-labelledby":"res-title"});i.innerHTML=`
    <div class="modal results-modal">
      <div class="stamp mono" aria-hidden="true">${h(De("success"))}</div>
      <h2 id="res-title">Job #${String(t.level.number).padStart(2,"0")} complete</h2>
      <div class="res-client">
        <div class="avatar">${H("client","happy",t.level.client.avatarColor)}</div>
        <blockquote><p>${h(ie[t.level.number%ie.length])}</p><cite>${h(t.level.client.name)}</cite></blockquote>
      </div>
      <div class="res-grid">
        <div class="res-stars">${le(t.xp.stars)}<span class="mono muted">${e}:${String(s).padStart(2,"0")}</span></div>
        <ul class="xp-lines">${t.xp.lines.map((c,d)=>`<li style="--i:${d}"><span>${h(c.label)}</span><span class="mono">+${c.xp}</span></li>`).join("")}</ul>
        <div class="xp-total"><span class="mono muted">TOTAL</span><span class="mono big">+<span data-count>0</span> XP</span></div>
      </div>
      ${o.rank>a.rank?`<div class="rank-up"><span class="mono">RANK UP</span> You are now a <strong>${h(o.title)}</strong>.</div>`:""}
      ${r.length?`<div class="group-label mono">ACHIEVEMENTS UNLOCKED</div><ul class="ach-row">${r.map(c=>`<li class="ach on"><span class="ach-icon" aria-hidden="true">${c.icon}</span><span><strong>${h(c.title)}</strong><small>${h(c.description)}</small></span></li>`).join("")}</ul>`:""}
      <div class="learned"><span class="mono muted">YOU PRACTISED</span> ${t.level.concepts.map(c=>`<span class="chip">${h(c)}</span>`).join("")}</div>
      <div class="modal-actions">
        ${t.next?`<button class="btn-primary" type="button" data-next autofocus>Next job: ${h(t.next.title)} <span aria-hidden="true">→</span></button><p class="next-teaser">Unlocked: ${h(t.level.unlocks)}</p>`:'<button class="btn-primary" type="button" data-board autofocus>Back to the job board</button><p class="next-teaser">That was the last job. You built, broke, and fixed a whole website.</p>'}
        <div class="secondary-actions"><button class="btn-ghost" type="button" data-stay>Keep tinkering</button>${t.next?'<button class="btn-ghost" type="button" data-board>Job board</button>':""}</div>
      </div>
    </div>`;const l=j(i);D.pop(x(".modal",i)),D.countUp(x("[data-count]",i),0,t.xp.total,1100,()=>g.play("xp_tick")),r.length&&window.setTimeout(()=>g.play("achievement"),1200),i.querySelector("[data-next]")?.addEventListener("click",()=>{l(),t.onNext(t.next)}),i.querySelectorAll("[data-board]").forEach(c=>c.addEventListener("click",()=>{l(),t.onBoard()})),x("[data-stay]",i).addEventListener("click",()=>{l(),t.onStay()})}function Re(t,e){const s=m.get().settings,n=R("div",{class:"overlay",role:"dialog","aria-modal":"true","aria-labelledby":"set-title"}),a=(i,l)=>`<label class="field"><span>${l}</span><input type="range" min="0" max="100" step="5" data-key="${i}" value="${Math.round(s[i]*100)}" aria-label="${l}"></label>`,o=(i,l,c="")=>`<label class="toggle"><input type="checkbox" data-key="${i}" ${s[i]?"checked":""}><span class="switch" aria-hidden="true"></span><span class="t-label">${l}${c?`<small>${c}</small>`:""}</span></label>`;n.innerHTML=`
    <div class="modal settings-modal">
      <div class="modal-head"><h2 id="set-title">Settings</h2><button class="icon-btn" type="button" data-close aria-label="Close settings">✕</button></div>
      <div class="group-label mono">SOUND</div>
      ${o("soundEffects","Sound effects")}
      ${o("music","Background music","A quiet little loop.")}
      ${a("masterVolume","Master volume")}
      ${a("effectsVolume","Effects volume")}
      ${a("musicVolume","Music volume")}
      ${o("captions","Sound captions","Shows text like [sad trombone] for every sound.")}
      <div class="group-label mono">DISPLAY</div>
      ${o("reducedMotion","Reduce motion","No confetti, shaking or bouncing.")}
      <label class="field"><span>Theme</span>
        <select data-key="theme"><option value="dark" ${s.theme==="dark"?"selected":""}>Dark</option><option value="light" ${s.theme==="light"?"selected":""}>Light</option></select>
      </label>
      <div class="group-label mono">PROGRESS</div>
      <button class="btn-danger" type="button" data-reset>Reset all progress</button>
    </div>`;const r=j(n);n.addEventListener("input",i=>{const l=i.target,c=l.dataset.key;c&&(m.update(d=>{const p=d.settings;l instanceof HTMLInputElement&&l.type==="checkbox"?p[c]=l.checked:l instanceof HTMLInputElement&&l.type==="range"?p[c]=Number(l.value)/100:p[c]=l.value},!0),t(m.get().settings),l instanceof HTMLInputElement&&l.type==="checkbox"&&g.play("button"))}),x("[data-close]",n).addEventListener("click",r),n.addEventListener("click",i=>{i.target===n&&r()}),x("[data-reset]",n).addEventListener("click",i=>{const l=i.currentTarget;if(l.dataset.armed!=="1"){l.dataset.armed="1",l.textContent="Really? Click again to erase everything.";return}r(),e()})}function je(){const t=new Set(m.get().achievements),e=R("div",{class:"overlay",role:"dialog","aria-modal":"true","aria-labelledby":"ach-title"});e.innerHTML=`
    <div class="modal ach-modal">
      <div class="modal-head"><h2 id="ach-title">Achievements <span class="mono muted">${t.size}/${L.length}</span></h2><button class="icon-btn" type="button" data-close aria-label="Close">✕</button></div>
      <ul class="ach-grid">${L.map(n=>`<li class="ach ${t.has(n.id)?"on":"off"}"><span class="ach-icon" aria-hidden="true">${t.has(n.id)?n.icon:"?"}</span><span><strong>${h(n.title)}</strong><small>${h(n.description)}</small></span><span class="sr-only">${t.has(n.id)?"unlocked":"locked"}</span></li>`).join("")}</ul>
    </div>`;const s=j(e);x("[data-close]",e).addEventListener("click",s),e.addEventListener("click",n=>{n.target===e&&s()})}const Ue={html:"HTML",css:"CSS",layout:"LAYOUT",js:"JAVASCRIPT",debug:"DEBUG",project:"PROJECT"};function Be(t,e){const s=m.get(),n=w.all(),a=i=>m.level(i).completed,o=n.find(i=>!a(i.id)&&w.isUnlocked(i.id,a)),r=n.filter(i=>a(i.id)).length;return t.innerHTML=`
  <div class="board">
    <header class="topbar">
      <button class="btn-ghost brand" type="button" data-title aria-label="Title screen">CODE<span>IT!</span><small class="brand-by mono">by Web Development Services</small></button>
      <div class="topbar-right">
        ${He(s.xp)}
        <button class="btn-ghost" type="button" data-ach>Achievements <span class="mono muted">${s.achievements.length}/${L.length}</span></button>
        <button class="btn-ghost" type="button" data-settings>Settings</button>
      </div>
    </header>
    <main class="board-main">
      <div class="board-head">
        <div>
          <p class="kicker mono">JOB BOARD · ${r}/${n.length} SHIPPED</p>
          <h1>${r===0?"Your first client is waiting.":r===n.length?"Every job shipped. Legend.":"Pick your next job."}</h1>
        </div>
        <div class="board-dex">
          <div class="avatar">${H("dex",r?"smug":"neutral")}</div>
          <p class="bubble">${r===0?"I’m Dex, senior dev. Start with Chef Rizzo. And press RUN a lot. It’s free.":o?`Next up: ${h(o.client.name)}. Good luck. You won’t need it. Probably.`:"You did all of them. I’m... actually impressed."}</p>
        </div>
      </div>
      <ol class="tickets">
        ${n.map((i,l)=>{const c=m.level(i.id),d=w.isUnlocked(i.id,a),p=o?.id===i.id,f=c.completed?"shipped":d?c.draft?"in progress":"open":"locked";return`<li style="--i:${l}">
              <button class="ticket-card cat-${i.category}${p?" next":""}${c.completed?" done":""}" type="button" data-level="${i.id}" ${d?"":'disabled aria-disabled="true"'}
                aria-label="Job ${i.number}: ${h(i.title)}. ${f}.${d?"":` Finish job ${i.number-1} to unlock.`}">
                <span class="tc-top"><span class="tc-no mono">#${String(i.number).padStart(2,"0")}</span><span class="tc-cat mono">${Ue[i.category]}</span></span>
                <span class="tc-title">${h(i.title)}</span>
                <span class="tc-tag">${h(i.tagline)}</span>
                <span class="tc-foot">
                  <span class="tc-client">${h(i.client.name)}</span>
                  ${c.completed?`<span class="tc-done"><span class="tc-stamp mono" aria-hidden="true">SHIPPED</span>${le(c.stars)}</span>`:d?`<span class="tc-status mono">${p?"START →":c.draft?"CONTINUE":"OPEN"}</span>`:'<span class="tc-status mono locked">🔒 LOCKED</span>'}
                </span>
              </button>
            </li>`}).join("")}
      </ol>
    </main>
    <footer class="site-foot mono">CODE IT! · © ${new Date().getFullYear()} Web Development Services</footer>
  </div>`,t.querySelectorAll("[data-level]").forEach(i=>i.addEventListener("click",()=>{g.play("button"),e.onPlay(w.get(i.dataset.level))})),t.querySelector("[data-settings]").addEventListener("click",e.onSettings),t.querySelector("[data-ach]").addEventListener("click",e.onAchievements),t.querySelector("[data-title]").addEventListener("click",e.onTitle),requestAnimationFrame(()=>(t.querySelector(".ticket-card.next")??t.querySelector(".ticket-card:not([disabled])"))?.focus()),()=>{}}const ze=[["cmd","$ build website"],["ok","✓ added a button"],["cmd","$ run"],["bad","✕ TypeError: button has chosen violence"],["cmd","$ fix it"],["ok","✓ IT WORKS!"]],Fe=["&lt;/&gt;","{ }","&lt;div&gt;","#fff",";","=&gt;","&lt;h1&gt;",".css","()","[ ]"],oe=(t,e)=>[...t].map((s,n)=>`<span class="logo-l" aria-hidden="true" style="--n:${e+n}">${s}</span>`).join("");function Je(t,e){const s=m.isNew();t.innerHTML=`
  <main class="title-screen">
    <div class="title-grid" aria-hidden="true"></div>
    <div class="title-glyphs mono" aria-hidden="true">${Fe.map((a,o)=>`<span style="--i:${o}">${a}</span>`).join("")}</div>
    <div class="title-inner">
      <div class="title-left">
        <p class="kicker mono"><span class="kicker-brand">WEB DEVELOPMENT SERVICES</span> PRESENTS</p>
        <h1 class="logo" aria-label="CODE IT!">${oe("CODE",0)}<span class="logo-bang">&nbsp;${oe("IT!",4)}</span><span class="caret" aria-hidden="true"></span></h1>
        <p class="tagline"><span>Build it.</span> <span class="break">Break it.</span> <span class="fix">Fix it.</span></p>
        <p class="pitch">You’re the new junior web developer. The clients are ridiculous. The previous developer is gone. Write real HTML, CSS and JavaScript to get the jobs done.</p>
        <div class="title-actions">
          <button class="btn-primary big shine" type="button" data-start autofocus>${s?"Start your first job":"Continue"} <span aria-hidden="true">→</span></button>
          <button class="btn-ghost" type="button" data-settings>Settings</button>
        </div>
        <p class="fine">No sign-up. Progress saves on this device. Works offline.</p>
      </div>
      <div class="title-right" aria-hidden="true">
        <div class="terminal">
          <div class="term-bar"><i></i><i></i><i></i><span class="mono">byte@junior-dev ~</span></div>
          <ol class="term-lines mono">${ze.map(([a,o],r)=>`<li class="t-${a}" style="--d:${r*.55+.3}s">${o}</li>`).join("")}</ol>
        </div>
        <div class="title-byte">${H("byte","happy")}</div>
      </div>
    </div>
    <footer class="title-foot mono">© ${new Date().getFullYear()} Web Development Services</footer>
  </main>`;const n=()=>{g.unlock(),g.play("button"),e.onStart()};return t.querySelector("[data-start]").addEventListener("click",n),t.querySelector("[data-settings]").addEventListener("click",()=>{g.unlock(),e.onSettings()}),()=>{}}let v=null,k=null,re;function We(){return v||(v=document.createElement("div"),v.className="toasts",v.setAttribute("role","status"),v.setAttribute("aria-live","polite"),document.body.appendChild(v),v)}function ce(t,e={}){const s=document.createElement("div");s.className=`toast toast-${e.kind??"info"}`,s.innerHTML=t,We().appendChild(s),window.setTimeout(()=>{s.classList.add("out"),window.setTimeout(()=>s.remove(),300)},e.ms??3200)}function Ye(t){k||(k=document.createElement("div"),k.className="caption",k.setAttribute("aria-hidden","true"),document.body.appendChild(k)),k.innerHTML=h(t),k.classList.add("show"),clearTimeout(re),re=window.setTimeout(()=>k?.classList.remove("show"),1800)}function Xe(t){let e=document.getElementById("sr-live");e||(e=document.createElement("div"),e.id="sr-live",e.className="sr-only",e.setAttribute("aria-live","assertive"),document.body.appendChild(e)),e.textContent="",window.setTimeout(()=>e.textContent=t,30)}const O=document.getElementById("app");let A=()=>{};function de(t){document.documentElement.dataset.theme=t.theme,D.setReducedMotion(t.reducedMotion),g.configure({master:t.masterVolume,effects:t.effectsVolume,music:t.musicVolume,effectsOn:t.soundEffects,musicOn:t.music,captions:t.captions})}function Ge(){const t=location.hash.replace(/^#\/?/,"");if(t.startsWith("job/")){const e=t.slice(4),s=n=>m.level(n).completed;return w.get(e)&&w.isUnlocked(e,s)?{screen:"level",id:e}:{screen:"board"}}return t==="jobs"?{screen:"board"}:{screen:"title"}}function C(t){location.hash===t?Q():location.hash=t}const F=()=>Re(de,()=>{m.reset(),ce("Progress reset. Fresh start!"),C("#/")});let J=0;const ue=()=>fe(()=>import("./game-V1WZGzri.js"),__vite__mapDeps([0,1]),import.meta.url);function Q(){J++,A(),window.scrollTo(0,0);const t=Ge();if(document.body.dataset.screen=t.screen,t.screen==="title")document.title="CODE IT! Build it. Break it. Fix it.",A=Je(O,{onStart:()=>C("#/jobs"),onSettings:F});else if(t.screen==="board")document.title="Job board · CODE IT!",A=Be(O,{onPlay:e=>C(`#/job/${e.id}`),onSettings:F,onAchievements:je,onTitle:()=>C("#/")});else{const e=w.get(t.id);document.title=`#${e.number} ${e.title} · CODE IT!`;const s=++J;O.innerHTML='<div class="loading mono" role="status">Booting editor…</div>',A=()=>{},ue().then(({mountGame:n})=>{s===J&&(A=n(O,e,{onExit:()=>C("#/jobs"),onNext:a=>C(`#/job/${a.id}`),onSettings:F}))})}}de(m.get().settings);g.onCaption(Ye);ee.onUnlock(t=>{ee.quiet||(g.play("achievement"),ce(`<span class="ach-icon" aria-hidden="true">${t.icon}</span><span><small class="mono">ACHIEVEMENT UNLOCKED</small><strong>${h(t.title)}</strong></span>`,{kind:"achievement",ms:4e3}))});window.addEventListener("pointerdown",()=>g.unlock(),{once:!0});window.addEventListener("keydown",()=>g.unlock(),{once:!0});window.addEventListener("hashchange",Q);Ae.init();Q();const Ve=window.requestIdleCallback??(t=>window.setTimeout(t,200));Ve(async()=>{if(ue(),await b.detect()){const t=m.get();b.enqueue("POST","/api/player",{playerId:t.id,name:t.name},`player:${t.id}`),w.refresh()}b.flush()});export{x as $,g as A,Ae as D,D as F,w as L,m as P,fe as _,De as a,ee as b,Ce as c,Xe as d,h as e,_e as f,b as g,Ke as h,H as p,He as r,Qe as s,ce as t};
