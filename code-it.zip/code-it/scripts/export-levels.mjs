// Exports the TypeScript level data to server/levels.json so the Python server
// serves exactly the levels the game ships with. Runs as part of `npm run build`.
import { build } from 'esbuild';
import { mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const out = 'node_modules/.cache/levels.mjs';
mkdirSync('node_modules/.cache', { recursive: true });
await build({ stdin: { contents: "export * from './src/levels/repository'; export { ACHIEVEMENTS } from './src/achievements/achievements';", resolveDir: '.', loader: 'ts' }, bundle: true, format: 'esm', platform: 'neutral', outfile: out, logLevel: 'silent', external: [] , define: { 'import.meta.env.VITE_API_BASE_URL': 'undefined' } });
const mod = await import(pathToFileURL(out).href + '?t=' + Date.now());
const levels = mod.LevelRepository.all();
const achievements = mod.ACHIEVEMENTS.map((a) => ({ id: a.id, title: a.title }));
writeFileSync('server/levels.json', JSON.stringify({ version: mod.CONTENT_VERSION, levels, achievements }, null, 1) + '\n');
rmSync(out);
console.log(`server/levels.json: ${levels.length} levels, content ${mod.CONTENT_VERSION}`);
