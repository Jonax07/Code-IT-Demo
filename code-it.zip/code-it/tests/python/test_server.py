"""Tests for the Python game server. Run: python -m unittest discover -s tests/python -t .
(or the Testing panel in VS Code)."""
from __future__ import annotations

import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from server import rules
from server.app import make_server

ROOT = Path(__file__).resolve().parents[2]
LEVELS = ROOT / "server" / "levels.json"
CONTENT = json.loads(LEVELS.read_text())
IDS = [lvl["id"] for lvl in CONTENT["levels"]]
PID = "player_test1234"


def progress_body(level_id: str, **over) -> dict:
    body = {"playerId": PID, "levelId": level_id, "completed": True, "attempts": 3, "hintsUsed": 1, "timeMs": 60_000, "score": 2, "xp": 155}
    body.update(over)
    return body


class RulesTest(unittest.TestCase):
    def test_accepts_a_plausible_first_level(self):
        r = rules.progress(progress_body(IDS[0]), IDS, set())
        self.assertEqual((r.level_id, r.xp, r.stars), (IDS[0], 155, 2))

    def test_levels_must_be_completed_in_order(self):
        with self.assertRaisesRegex(rules.Invalid, "previous level"):
            rules.progress(progress_body(IDS[2]), IDS, {IDS[0]})
        rules.progress(progress_body(IDS[1]), IDS, {IDS[0]})

    def test_rejects_impossible_numbers(self):
        for bad in ({"xp": rules.MAX_LEVEL_XP + 1}, {"timeMs": 500}, {"hintsUsed": 9}, {"score": 4}, {"attempts": 0}, {"xp": "lots"}, {"xp": True}):
            with self.subTest(bad=bad), self.assertRaises(rules.Invalid):
                rules.progress(progress_body(IDS[0], **bad), IDS, set())

    def test_rejects_unknown_level_and_bad_player(self):
        with self.assertRaises(rules.Invalid):
            rules.progress(progress_body("nope"), IDS, set())
        with self.assertRaises(rules.Invalid):
            rules.progress(progress_body(IDS[0], playerId="<script>"), IDS, set())

    def test_analytics_keeps_only_known_events_and_fields(self):
        events = rules.analytics({"events": [
            {"event": "code_run", "levelId": IDS[0], "passed": False, "code": "<h1>secret</h1>"},
            {"event": "made_up"},
            {"event": "hint_used", "levelId": "not-a-level"},
        ]}, IDS)
        self.assertEqual(len(events), 1)
        self.assertNotIn("code", events[0])

    def test_display_name_is_sanitised(self):
        self.assertEqual(rules.display_name("<b>Ada</b>"), "bAda/b")
        self.assertEqual(rules.display_name("   "), "Junior Dev")
        self.assertEqual(len(rules.display_name("x" * 200)), 40)


class ServerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        web = Path(cls.tmp.name) / "web"
        (web / "assets").mkdir(parents=True)
        (web / "index.html").write_text("<!doctype html><head><title>CODE IT!</title></head>")
        (web / "assets" / "app-abc.js").write_text("console.log(1)")
        (Path(cls.tmp.name) / "secret.txt").write_text("nope")
        cls.server = make_server("127.0.0.1", 0, web, ":memory:", LEVELS)
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.tmp.cleanup()

    def call(self, method: str, path: str, body: dict | None = None, headers: dict | None = None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method)
        if data is not None:
            req.add_header("Content-Type", "application/json")
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        try:
            with urllib.request.urlopen(req, timeout=5) as res:
                raw = res.read()
                return res.status, dict(res.headers), (json.loads(raw) if "json" in res.headers.get("Content-Type", "") else raw)
        except urllib.error.HTTPError as e:
            return e.code, dict(e.headers), json.loads(e.read() or b"{}")

    def test_serves_game_with_security_headers(self):
        status, headers, body = self.call("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"CODE IT!", body)
        self.assertIn(b'name="codeit-api"', body)
        self.assertIn("default-src 'self'", headers["Content-Security-Policy"])
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(headers["Cache-Control"], "no-cache")
        _, h, _ = self.call("GET", "/assets/app-abc.js")
        self.assertIn("immutable", h["Cache-Control"])
        self.assertTrue(h["Content-Type"].startswith("text/javascript"))

    def test_blocks_path_traversal(self):
        status, _, _ = self.call("GET", "/../secret.txt")
        self.assertEqual(status, 404)
        status, _, _ = self.call("GET", "/%2e%2e/secret.txt")
        self.assertEqual(status, 404)

    def test_config_identifies_the_game(self):
        status, _, body = self.call("GET", "/api/game/config")
        self.assertEqual(status, 200)
        self.assertEqual(body["game"], "code-it")
        self.assertEqual(body["brand"], "Web Development Services")

    def test_levels_list_pagination_filters_and_detail(self):
        _, _, page = self.call("GET", "/api/levels?page=2&pageSize=3")
        self.assertEqual((page["page"], page["total"], len(page["levels"])), (2, len(IDS), 3))
        self.assertNotIn("starter", page["levels"][0])
        _, _, css = self.call("GET", "/api/levels?category=css")
        self.assertTrue(all(lvl["category"] == "css" for lvl in css["levels"]))
        _, _, full = self.call("GET", "/api/levels?full=1")
        self.assertIn("starter", full["levels"][0])
        status, _, one = self.call("GET", f"/api/levels/{IDS[0]}")
        self.assertEqual((status, len(one["hints"])), (200, 4))
        self.assertEqual(self.call("GET", "/api/levels/nope")[0], 404)

    def test_progress_flow_and_idempotency(self):
        pid = "player_flow0001"
        self.assertEqual(self.call("POST", "/api/player", {"playerId": pid, "name": "Ada"})[0], 200)
        # Skipping ahead is refused.
        status, _, body = self.call("POST", "/api/progress", progress_body(IDS[1], playerId=pid))
        self.assertEqual(status, 422)
        self.assertIn("previous level", body["error"])
        # The same completion sent twice (a retry) is stored once.
        for _ in range(2):
            status, _, body = self.call("POST", "/api/progress", progress_body(IDS[0], playerId=pid), {"Idempotency-Key": "progress:x:3"})
            self.assertEqual(status, 200)
        self.assertTrue(body.get("replayed"))
        _, _, player = self.call("GET", f"/api/player?playerId={pid}")
        self.assertEqual(player["name"], "Ada")
        self.assertEqual(player["levels"][IDS[0]]["completions"], 1)
        self.assertEqual(player["xp"], 155)
        _, _, board = self.call("GET", "/api/leaderboard")
        self.assertEqual(board["entries"][0]["name"], "Ada")

    def test_achievements_cannot_be_duplicated(self):
        body = {"playerId": "player_ach00001", "achievementId": "first-job"}
        self.assertTrue(self.call("POST", "/api/achievements", body)[2]["unlocked"])
        self.assertFalse(self.call("POST", "/api/achievements", body)[2]["unlocked"])
        self.assertEqual(self.call("POST", "/api/achievements", body | {"achievementId": "fake"})[0], 422)

    def test_analytics_stores_clean_events(self):
        status, _, body = self.call("POST", "/api/analytics/events", {"events": [{"event": "level_started", "levelId": IDS[0], "playerId": PID}, {"event": "bogus"}]})
        self.assertEqual((status, body["stored"]), (200, 1))

    def test_keep_alive_survives_replayed_and_rejected_posts(self):
        """Regression: a replayed POST must still consume its body, or the next request on the
        same connection is corrupted."""
        import http.client
        conn = http.client.HTTPConnection("127.0.0.1", self.server.server_address[1], timeout=5)
        body = json.dumps({"playerId": "player_keep0001", "name": "K"})
        headers = {"Content-Type": "application/json", "Idempotency-Key": "player:keep"}
        for _ in range(3):
            conn.request("POST", "/api/player", body, headers)
            self.assertEqual(conn.getresponse().read() and 200, 200)
        conn.request("GET", "/api/health")
        res = conn.getresponse()
        self.assertEqual((res.status, json.loads(res.read())), (200, {"ok": True}))
        conn.close()

    def test_rejects_bad_requests(self):
        req = urllib.request.Request(self.base + "/api/player", data=b"{not json", method="POST", headers={"Content-Type": "application/json"})
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 422)
        self.assertEqual(self.call("GET", "/api/player?playerId=bad")[0], 400)
        self.assertEqual(self.call("GET", "/api/nope")[0], 404)


if __name__ == "__main__":
    unittest.main()
