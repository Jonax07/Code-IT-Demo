// End-to-end gameplay tests in real Chromium.
// Usage: npm run build && npm run e2e   (serves dist/ with `vite preview`)
import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { chromium } from 'playwright-core';
import { SOLUTIONS } from './solutions.mjs';

const PORT = 4178;
const BASE = `http://localhost:${PORT}/`;
const SHOTS = new URL('./screenshots/', import.meta.url).pathname;
const EXEC = process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
mkdirSync(SHOTS, { recursive: true });

// E2E_SERVER=python plays the game through the Python server (run.py) instead of `vite preview`.
const PY = process.env.E2E_SERVER === 'python';
const DB = `${process.env.TMPDIR || '/tmp'}/codeit-e2e-${process.pid}.sqlite3`;
const server = PY
  ? spawn(process.env.PYTHON || 'python3', ['run.py', '--port', String(PORT), '--db', DB, '--quiet'], { stdio: 'pipe' })
  : spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--port', String(PORT), '--strictPort'], { stdio: 'pipe' });
server.stderr.on('data', (d) => PY && process.stderr.write(d));
process.on('exit', () => server.kill());
await new Promise((resolve, reject) => {
  const t = setTimeout(() => reject(new Error('preview server did not start')), 20000);
  server.stdout.on('data', (d) => String(d).includes(String(PORT)) && (clearTimeout(t), resolve()));
});

const browser = await chromium.launch({ executablePath: EXEC });
let failures = 0;
const results = [];
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    results.push(`✓ ${name} (${Date.now() - t0}ms)`);
  } catch (e) {
    failures++;
    results.push(`✕ ${name}\n    ${String(e && e.stack || e).split('\n').slice(0, 4).join('\n    ')}`);
  }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };

async function newPage({ width = 1440, height = 900, unlockAll = false, reducedMotion = true } = {}) {
  const ctx = await browser.newContext({ viewport: { width, height }, reducedMotion: reducedMotion ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => !String(e.stack).includes('about:srcdoc') && errors.push(e.message));
  // Player-code errors inside the sandbox are expected gameplay; only the game's own errors count.
  // Tests that pre-seed local progress the server never saw get a (correct) 422 when that
  // progress syncs; the server refusing out-of-order progress is expected, not a game error.
  page.on('console', (m) => m.type() === 'error' && !String(m.location().url).startsWith('about:srcdoc') && !(unlockAll && /status of 422/.test(m.text())) && errors.push(m.text()));
  if (unlockAll) {
    await page.addInitScript(() => {
      if (window !== window.top) return; // Don't run inside the sandboxed preview frames.
      if (localStorage.getItem('codeit.player.v1')) return;
      const ids = ['html-001', 'css-001', 'layout-001', 'js-001', 'debug-001', 'project-001', 'project-002', 'layout-002', 'debug-002', 'final-001'];
      const levels = {};
      for (const id of ids) levels[id] = { completed: true, bestXp: 100, attempts: 1, hintsUsed: 0, bestTimeMs: 1000, stars: 1 };
      localStorage.setItem('codeit.player.v1', JSON.stringify({ id: 'player_test', name: 'T', xp: 0, levels, achievements: ['hello-world'], stats: { runs: 5, errorsSeen: 0, bugsFixed: 0, resets: 0 }, settings: { reducedMotion: true, soundEffects: false, captions: true, theme: 'dark', masterVolume: 0.8, effectsVolume: 0.9, musicVolume: 0.4, music: false }, version: 1 }));
    });
  }
  return { page, ctx, errors };
}

/** Replace a file's contents in the editor like a player would (select all + type). */
async function setCode(page, lang, text) {
  await page.click(`.file-tab[data-lang="${lang}"]`);
  const content = page.locator(`#editor-pane-${lang} .cm-content`);
  await content.click();
  await page.keyboard.press('ControlOrMeta+a');
  await page.keyboard.press('Delete');
  await page.keyboard.insertText(text);
}

async function run(page) {
  await page.click('[data-action="run"]');
  await page.waitForFunction(() => {
    const b = document.querySelector('[data-action="run"]');
    return b && !b.classList.contains('running') && document.querySelector('.result-word, .overlay');
  }, null, { timeout: 8000 });
  // A passing run opens a dialog (change request or results) shortly after.
  if ((await page.textContent('.result-word').catch(() => '')) === 'SUCCESS') {
    await page.waitForSelector('.overlay', { timeout: 3000 }).catch(() => {});
  }
  await page.waitForTimeout(150);
}

async function openLevel(page, id) {
  await page.goto(`${BASE}#/job/${id}`);
  await page.waitForSelector('.cm-content', { timeout: 10000 });
}

// ---------------------------------------------------------------- tests
await test('title screen loads fast with no errors', async () => {
  const { page, ctx, errors } = await newPage({ reducedMotion: false });
  const t0 = Date.now();
  await page.goto(BASE);
  await page.waitForSelector('[data-start]');
  const ms = Date.now() - t0;
  const nav = await page.evaluate(() => {
    const n = performance.getEntriesByType('navigation')[0];
    return { domInteractive: Math.round(n.domInteractive), load: Math.round(n.loadEventEnd) };
  });
  results.push(`    title visible in ${ms}ms, domInteractive ${nav.domInteractive}ms, load ${nav.load}ms (local server)`);
  await page.waitForTimeout(3600);
  await page.screenshot({ path: SHOTS + 'title-1440.png' });
  assert(errors.length === 0, 'errors: ' + errors.join(' | '));
  await ctx.close();
});

await test('new player: title → board → level 1 fails, then passes with feedback + results', async () => {
  const { page, ctx, errors } = await newPage();
  await page.goto(BASE);
  await page.click('[data-start]');
  await page.waitForSelector('.tickets');
  const locked = await page.locator('.ticket-card[disabled]').count();
  assert(locked === 9, `expected 9 locked tickets, got ${locked}`);
  await page.screenshot({ path: SHOTS + 'board-1440.png' });
  await page.click('.ticket-card.next');
  await page.waitForSelector('.cm-content');
  await page.waitForTimeout(700);
  await page.screenshot({ path: SHOTS + 'game-start-1440.png' });
  await run(page);
  const word = await page.textContent('.result-word');
  assert(word === 'FAILED', 'starter code should fail, got ' + word);
  const fails = await page.locator('.check.fail').count();
  assert(fails >= 3, 'expected several failing checks');
  await page.screenshot({ path: SHOTS + 'game-fail-1440.png' });
  // Hints are progressive.
  await page.click('.hint-btn');
  await page.click('.hint-btn');
  assert((await page.locator('.hint').count()) === 2, 'two hints shown');
  await setCode(page, 'html', SOLUTIONS['html-001'].html);
  await page.waitForTimeout(600);
  await run(page);
  await page.waitForSelector('.results-modal', { timeout: 5000 });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: SHOTS + 'game-results-1440.png' });
  const xp = await page.textContent('.xp-total .big');
  assert(/\+\d+ XP/.test(xp), 'xp total shown: ' + xp);
  // Next job is unlocked and loads.
  await page.click('[data-next]');
  await page.waitForFunction(() => location.hash.includes('css-001'));
  await page.waitForSelector('.cm-content');
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('codeit.player.v1')));
  assert(saved.levels['html-001'].completed && saved.xp > 0, 'progress saved');
  assert(saved.achievements.includes('first-job'), 'first-job achievement');
  if (PY) {
    // Progress syncs to the Python server in the background.
    let onServer = null;
    for (let i = 0; i < 30 && !onServer; i++) {
      onServer = await page.evaluate(async (pid) => {
        const r = await fetch(`./api/player?playerId=${pid}`);
        if (!r.ok) return null;
        const p = await r.json();
        return p.levels['html-001'] && p.achievements.includes('first-job') ? p : null;
      }, saved.id);
      if (!onServer) await page.waitForTimeout(300);
    }
    assert(onServer, 'progress never reached the Python server');
    results.push(`    server recorded html-001 for ${saved.id}: ${onServer.xp} XP, ${onServer.achievements.length} achievements`);
  }
  assert(errors.length === 0, 'errors: ' + errors.join(' | '));
  await ctx.close();
});

for (const [id, sol] of Object.entries(SOLUTIONS)) {
  await test(`level ${id}: starter fails, reference solution completes`, async () => {
    const { page, ctx, errors } = await newPage({ unlockAll: true });
    await openLevel(page, id);
    await run(page);
    assert((await page.textContent('.result-word')) === 'FAILED', 'starter should fail');
    for (const [lang, text] of Object.entries(sol)) await setCode(page, lang, text);
    await page.waitForTimeout(500);
    await run(page);
    if (await page.locator('.event-modal').count()) {
      await page.click('.event-modal [data-ok]');
      await page.waitForTimeout(200);
      await run(page);
    }
    const ok = await page.locator('.results-modal').count();
    if (!ok) {
      const fails = await page.$$eval('.check.fail', (els) => els.map((e) => e.textContent.replace(/\s+/g, ' ').trim()));
      const errs = await page.$$eval('.errors li', (els) => els.map((e) => e.textContent.trim()));
      throw new Error('did not complete: ' + JSON.stringify({ fails, errs }));
    }
    assert(errors.length === 0, 'errors: ' + errors.join(' | '));
    await ctx.close();
  });
}

await test('debug level shows error diagnostics that point at lines', async () => {
  const { page, ctx } = await newPage({ unlockAll: true });
  await openLevel(page, 'debug-001');
  await run(page);
  const problems = await page.$$eval('.errors li', (els) => els.map((e) => e.textContent.trim()));
  assert(problems.some((p) => /documnet/.test(p)), 'JS error mentions documnet: ' + problems.join(' | '));
  assert(problems.some((p) => /strong/.test(p)), 'HTML error about <strong>');
  // Clicking an error jumps to the file.
  await page.click('.errors .goto >> nth=0');
  await page.waitForTimeout(200);
  await page.click('.file-tab[data-lang="css"]');
  await page.waitForTimeout(300);
  const cssDiag = await page.locator('#editor-pane-css .cm-lintRange-warning, #editor-pane-css .cm-lintRange-error').count();
  assert(cssDiag >= 2, 'css diagnostics shown in editor: ' + cssDiag);
  await page.screenshot({ path: SHOTS + 'debug-level-1440.png' });
  await ctx.close();
});

await test('infinite loop is stopped and the game stays responsive', async () => {
  const { page, ctx } = await newPage({ unlockAll: true });
  await openLevel(page, 'js-001');
  await setCode(page, 'js', 'let n = 0;\nwhile (true) { n++; }\n');
  await page.waitForTimeout(700);
  const t0 = Date.now();
  await run(page);
  const took = Date.now() - t0;
  const ms = await page.evaluate(() => document.querySelector('.feedback-head .muted').textContent);
  results.push(`    infinite loop run: ${took}ms wall clock, validation reported: ${ms}`);
  const text = await page.textContent('.check-area');
  assert(/loop/i.test(text), 'mentions loop: ' + text.slice(0, 200));
  assert(took < 5000, 'returned in ' + took + 'ms');
  // UI still responds.
  await page.click('.file-tab[data-lang="html"]');
  assert((await page.getAttribute('.file-tab[data-lang="html"]', 'aria-selected')) === 'true', 'tabs still work');
  await ctx.close();
});

await test('sandbox isolation: player code cannot touch the game or forge results', async () => {
  const { page, ctx } = await newPage({ unlockAll: true });
  await openLevel(page, 'js-001');
  await setCode(page, 'js', `try { parent.document.body.innerHTML = 'HACKED'; } catch (e) { console.log('blocked: ' + e.name); }
try { localStorage.setItem('x', '1'); } catch (e) { console.log('storage blocked'); }
parent.postMessage({ __codeit: true, token: 'guess', runId: 'v1', type: 'validated', payload: { results: [{ id: 'launched', pass: true }], errors: [], executionTimeMs: 0, validationTimeMs: 0 } }, '*');
fetch('https://example.com').catch(() => console.log('network blocked'));`);
  await page.waitForTimeout(700);
  await run(page);
  assert(await page.evaluate(() => document.body.innerHTML !== 'HACKED' && !!document.querySelector('.game')), 'game DOM untouched');
  assert((await page.textContent('.result-word')) === 'FAILED', 'forged result ignored');
  await page.click('[data-status-tab="console"]');
  const log = await page.textContent('.console-list');
  assert(/blocked: SecurityError/.test(log), 'parent access blocked: ' + log);
  assert(/storage blocked/.test(log), 'storage blocked');
  await ctx.close();
});

await test('draft code survives a reload', async () => {
  const { page, ctx } = await newPage({ unlockAll: true });
  await openLevel(page, 'html-001');
  await setCode(page, 'html', '<h1>Draft Pizza 123</h1>');
  await page.waitForTimeout(700);
  await page.reload();
  await page.waitForSelector('.cm-content');
  const text = await page.textContent('#editor-pane-html .cm-content');
  assert(text.includes('Draft Pizza 123'), 'draft restored');
  await ctx.close();
});

await test('keyboard: Ctrl+Enter runs, dialogs trap focus and Escape closes settings', async () => {
  const { page, ctx } = await newPage({ unlockAll: true });
  await openLevel(page, 'html-001');
  await page.locator('#editor-pane-html .cm-content').click();
  await page.keyboard.press('Control+Enter');
  await page.waitForSelector('.result-word');
  await page.click('[data-action="settings"]');
  await page.waitForSelector('.settings-modal');
  await page.keyboard.press('Escape');
  assert((await page.locator('.settings-modal').count()) === 0, 'settings closed');
  await ctx.close();
});

const VIEWPORTS = [
  ['1440', 1440, 900], ['1280', 1280, 800], ['1024', 1024, 768], ['ipad', 820, 1180], ['tablet-768', 768, 1024], ['mobile', 390, 844],
];
for (const [name, w, h] of VIEWPORTS) {
  await test(`responsive ${name}: no horizontal overflow, run works`, async () => {
    const { page, ctx, errors } = await newPage({ width: w, height: h, unlockAll: true });
    await page.goto(BASE + '#/jobs');
    await page.waitForSelector('.tickets');
    let overflow = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    assert(overflow <= 0, `board overflows by ${overflow}px`);
    await page.screenshot({ path: SHOTS + `board-${name}.png`, fullPage: false });
    await openLevel(page, 'debug-001');
    await page.waitForTimeout(600);
    overflow = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    assert(overflow <= 0, `game overflows by ${overflow}px`);
    const runVisible = await page.locator('[data-action="run"]').isVisible();
    assert(runVisible, 'RUN visible');
    await page.screenshot({ path: SHOTS + `game-${name}.png` });
    await run(page);
    await page.waitForTimeout(300);
    await page.screenshot({ path: SHOTS + `game-${name}-after-run.png` });
    if (w < 820) {
      await page.click('.mobile-tabs [data-tab="preview"]');
      await page.waitForTimeout(200);
      await page.screenshot({ path: SHOTS + `game-${name}-preview.png` });
      await page.click('.mobile-tabs [data-tab="job"]');
      await page.waitForTimeout(200);
      await page.screenshot({ path: SHOTS + `game-${name}-ticket.png` });
    }
    assert(errors.length === 0, 'errors: ' + errors.join(' | '));
    await ctx.close();
  });
}

await test('light theme renders', async () => {
  const { page, ctx } = await newPage({ unlockAll: true });
  await page.addInitScript(() => {
    if (window !== window.top) return;
    const p = JSON.parse(localStorage.getItem('codeit.player.v1'));
    p.settings.theme = 'light';
    localStorage.setItem('codeit.player.v1', JSON.stringify(p));
  });
  await openLevel(page, 'project-002');
  await page.waitForTimeout(600);
  await page.screenshot({ path: SHOTS + 'game-light-1440.png' });
  await ctx.close();
});

await browser.close();
server.kill();
console.log(results.join('\n'));
console.log(failures ? `\n${failures} FAILED` : '\nALL PASSED');
process.exit(failures ? 1 : 0);
