// Reference solutions used by the e2e suite to prove every level is completable.
// Each satisfies the base requirements AND the mid-level change request.
export const SOLUTIONS = {
  'html-001': {
    html: `<h1>Rizzo's Pizza</h1>
<p>The cheesiest, most enthusiastic pizza in town.</p>
<img src="pizza.svg" alt="A delicious pizza">
<button>Order now</button>`,
  },
  'css-001': {
    css: `body { background-color: #f4f1ea; font-family: Georgia, serif; color: #222; }
h1 { font-size: 40px; }
.card { border: 1px solid #ccc; padding: 24px; }
.cta { padding: 12px 20px; background-color: #2563eb; color: white; border: 0; }`,
  },
  'layout-001': {
    css: `body { font-family: system-ui, sans-serif; margin: 24px; }
.menu { display: flex; }
.menu a { padding: 8px 12px; }
.dishes { display: flex; gap: 16px; }
.dish { padding: 20px; border: 2px solid #111; }`,
  },
  'js-001': {
    js: `const launchButton = document.querySelector('#launch');
const statusText = document.querySelector('#status');
const rocket = document.querySelector('#rocket');
launchButton.addEventListener('click', function () {
  statusText.textContent = 'LAUNCHED!';
  rocket.classList.add('flying');
});`,
  },
  'debug-001': {
    html: `<header>
  <h1 class="title">Snack Overflow</h1>
  <p>The <strong>#1 snack delivery</strong> for developers</p>
</header>
<main>
  <button id="order">Order snacks</button>
  <p id="result"></p>
</main>`,
    css: `.title { color: #ff5a36; }
#order { background: #222; color: white; padding: 12px 20px; border: 0; }`,
    js: `const orderButton = document.querySelector('#order');
const result = document.querySelector('#result');
orderButton.addEventListener('click', function () {
  result.textContent = 'Snacks are on the way!';
});`,
  },
  'project-001': {
    html: `<div class="profile">
  <img src="cat.svg" alt="Sir Whiskerton">
  <h2>Sir Whiskerton</h2>
  <ul><li>Napped 20 hours</li><li>Knocked over a vase</li><li>Ignored a laser</li></ul>
  <a href="https://example.com">Fan club</a>
</div>`,
    css: `.profile { background: white; padding: 24px; border-radius: 16px; max-width: 320px; }
.profile img { width: 100%; }`,
  },
  'project-002': {
    html: `<p class="cart">Cart: <span id="cart-count">0</span></p>
<div class="card">
  <img src="sock.svg" alt="The Sock 3000">
  <h2>The Sock 3000</h2>
  <p class="price">$30</p>
  <button id="add">Add to cart</button>
</div>`,
    css: `.card { max-width: 280px; padding: 20px; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.15); }
.card img { width: 100%; }`,
    js: `const addButton = document.querySelector('#add');
const cartCount = document.querySelector('#cart-count');
let count = 0;
addButton.addEventListener('click', function () {
  count = count + 1;
  cartCount.textContent = count;
});`,
  },
  'layout-002': {
    css: `body { font-family: system-ui, sans-serif; margin: 0; padding: 16px; }
.features { display: flex; gap: 16px; }
.feature { width: 300px; flex-shrink: 0; padding: 24px; box-sizing: border-box; }
@media (max-width: 600px) {
  .features { flex-direction: column; }
  .feature { width: 100%; }
}`,
  },
  'debug-002': {
    js: `const input = document.querySelector('#task');
const addButton = document.querySelector('#add');
const list = document.querySelector('#list');
const count = document.querySelector('#count');
let tasks = [];
function addTask() {
  const text = input.value.trim();
  if (text === '') {
    return;
  }
  tasks.push(text);
  render();
  input.value = '';
}
function render() {
  list.innerHTML = '';
  for (let i = 0; i < tasks.length; i++) {
    const li = document.createElement('li');
    li.textContent = tasks[i];
    list.appendChild(li);
  }
  count.textContent = tasks.length + ' tasks';
}
addButton.addEventListener('click', addTask);`,
  },
  'final-001': {
    html: `<header>
  <nav><a href="#">Home</a><a href="#">Pods</a><a href="#">Nap</a></nav>
  <button id="theme-toggle">Dark mode</button>
</header>
<main>
  <h1>Nap anywhere.</h1>
  <img src="nappod.svg" alt="A NapPod" width="120">
  <div class="cards">
    <div class="card">Quiet</div>
    <div class="card">Comfy</div>
    <div class="card">Portable</div>
  </div>
</main>`,
    css: `body { font-family: system-ui, sans-serif; margin: 0; padding: 16px; }
body.dark { background: #111; color: #eee; }
nav { display: flex; gap: 12px; }
.cards { display: flex; gap: 16px; }
.card { flex: 1; padding: 20px; border: 1px solid #ccc; border-radius: 12px; }
@media (max-width: 600px) { .cards { flex-direction: column; } }`,
    js: `document.querySelector('#theme-toggle').addEventListener('click', function () {
  document.body.classList.toggle('dark');
});`,
  },
};
