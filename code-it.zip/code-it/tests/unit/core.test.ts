import { describe, expect, it } from 'vitest';
import { LEVELS } from '../../src/levels/data';
import { rankFor, scoreLevel } from '../../src/progression/scoring';
import { loopProtect } from '../../src/sandbox/loopProtect';
import { findSelectorLine, lintCss, lintHtml } from '../../src/validation/lint';

describe('lintHtml', () => {
  it('accepts valid markup, void elements and optional closers', () => {
    expect(lintHtml('<h1>Hi</h1>\n<img src="a.svg" alt="x">\n<ul><li>a<li>b</ul>\n<p>one\n<p>two')).toEqual([]);
  });
  it('points at an unclosed tag', () => {
    const issues = lintHtml('<header>\n  <p>The <strong>best</p>\n</header>');
    expect(issues).toHaveLength(1);
    expect(issues[0]).toMatchObject({ line: 2, severity: 'error' });
    expect(issues[0].message).toContain('strong');
  });
  it('reports stray closing tags and missing ">"', () => {
    expect(lintHtml('<div></span></div>')[0].message).toContain('never opened');
    expect(lintHtml('<h1 class="x"\n<p>hi</p>')[0].message).toContain('missing its closing ">"');
  });
  it('ignores tags inside comments and scripts', () => {
    expect(lintHtml('<!-- <div> -->\n<script>if (a < b) { x = "<div>"; }</script>')).toEqual([]);
  });
});

describe('lintCss', () => {
  const supports = (p: string, v: string) => !(p === 'colr' || v.includes(':'));
  it('finds missing colon and ignored declarations', () => {
    const css = '#order {\n  background: #222 color: white;\n  padding 12px;\n}';
    const issues = lintCss(css, supports);
    expect(issues.map((i) => i.line)).toEqual([2, 3]);
    expect(issues[1].severity).toBe('error');
  });
  it('finds a missing semicolon between lines', () => {
    const issues = lintCss('a {\n  color: red\n  padding: 4px;\n}');
    expect(issues[0].message).toContain('Missing ";"');
  });
  it('finds unbalanced braces', () => {
    expect(lintCss('a { color: red;').some((i) => i.message.includes('never closed'))).toBe(true);
    expect(lintCss('a { color: red; } }').some((i) => i.message.includes('Extra'))).toBe(true);
  });
  it('locates selectors by line', () => {
    expect(findSelectorLine('body {}\n.titel { color: red; }', '.titel')).toBe(2);
    expect(findSelectorLine('.title-big {}', '.title')).toBeNull();
  });
});

describe('loopProtect', () => {
  it('guards braced loops', () => {
    expect(loopProtect('while (true) { x++; }')).toBe('while (true) {__codeitLoop(); x++; }');
    expect(loopProtect('for (let i = 0; i < 3; i++) {}')).toContain('{__codeitLoop();}');
    expect(loopProtect('do { a() } while (b)')).toContain('do {__codeitLoop();');
  });
  it('leaves strings, comments, regexes and identifiers alone', () => {
    const src = `const s = "while (x) {"; // for (;;) {\nconst r = /for\\(/g; const forEach = 1; /* while(1){} */`;
    expect(loopProtect(src)).toBe(src);
  });
  it('produces code that still runs correctly', () => {
    const src = 'let t = 0; for (let i = 0; i < 5; i++) { t += i; } let n = 0; while (n < 3) { n++; } return t + n;';
    const fn = new Function('__codeitLoop', loopProtect(src));
    expect(fn(() => {})).toBe(13);
  });
});

describe('scoring', () => {
  const base = {
    runs: 1, failedRuns: 0, hintsUsed: 0, sawErrors: false, durationMs: 60_000, parTimeSec: 180,
    bonusPassed: { accessibility: false, performance: false, style: false }, isDebug: false, firstClear: true,
  };
  it('rewards a clean first try with 3 stars', () => {
    const r = scoreLevel(base);
    expect(r.stars).toBe(3);
    expect(r.total).toBe(100 + 50 + 30 + 25);
  });
  it('never goes below base XP and rewards experimenting', () => {
    const r = scoreLevel({ ...base, runs: 12, failedRuns: 11, hintsUsed: 4, durationMs: 9e9 });
    expect(r.total).toBeGreaterThanOrEqual(100);
    expect(r.lines.some((l) => l.key === 'explore')).toBe(true);
    expect(r.stars).toBe(1);
  });
  it('halves replays', () => {
    expect(scoreLevel({ ...base, firstClear: false }).total).toBe(Math.round(100 / 2) + 25 + 15 + 13);
  });
  it('computes ranks', () => {
    expect(rankFor(0)).toMatchObject({ rank: 1, title: 'Intern' });
    expect(rankFor(700).rank).toBe(3);
  });
});

describe('level data', () => {
  it('has unique ids, 4 hints each, and ids for every requirement', () => {
    const ids = new Set(LEVELS.map((l) => l.id));
    expect(ids.size).toBe(LEVELS.length);
    expect(LEVELS.length).toBeGreaterThanOrEqual(5);
    for (const l of LEVELS) {
      expect(l.hints).toHaveLength(4);
      const reqIds = [...l.requirements, ...(l.event?.requirements ?? [])].map((r) => r.id);
      expect(new Set(reqIds).size).toBe(reqIds.length);
      for (const t of l.tabs) expect(typeof l.starter[t]).toBe('string');
      expect(l.requirements.some((r) => !r.bonus)).toBe(true);
    }
  });
});
